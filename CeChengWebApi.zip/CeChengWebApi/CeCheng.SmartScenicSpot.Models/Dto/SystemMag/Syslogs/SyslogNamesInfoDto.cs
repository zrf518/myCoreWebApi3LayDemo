﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class SyslogNamesInfoDto
    {
        /// <summary>
        /// 分店名称
        /// </summary>
        public string branch_name { get; set; }
        /// <summary>
        /// 营业点名称
        /// </summary>
        public string outlet_name { get; set; }
        /// <summary>
        /// 用户名称
        /// </summary>
        public string user_name { get; set; }


        /*

         
         */
    }
}

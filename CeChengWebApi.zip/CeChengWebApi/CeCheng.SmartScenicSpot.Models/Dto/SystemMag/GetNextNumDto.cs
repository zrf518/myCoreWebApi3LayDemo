﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Models
{
    /// <summary>
    /// 流水号
    /// </summary>
    public class GetNextNumDto
    {
        /// <summary>
        /// 流水号标识
        /// </summary>
        public string sNextNumMark { get; set; }
    }
}

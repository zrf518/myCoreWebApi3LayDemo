﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Models.Dto.TicketMag
{
    /// <summary>
    /// 
    /// </summary>
    public class TickInfoDto
    {

    }
}

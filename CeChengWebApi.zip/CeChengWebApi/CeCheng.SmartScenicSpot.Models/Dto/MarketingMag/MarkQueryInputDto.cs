﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class MarkQueryInputDto:BasePageDto
    {
        /// <summary>
        /// 市场名称
        /// </summary>
        public string MarkName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Models
{
    /// <summary>
    /// 
    /// </summary>
    public static class RedisConstConn
    {
        /// <summary>
        /// 
        /// </summary>
        public static string ConnectionRedisStr { get; set; }
    }
}

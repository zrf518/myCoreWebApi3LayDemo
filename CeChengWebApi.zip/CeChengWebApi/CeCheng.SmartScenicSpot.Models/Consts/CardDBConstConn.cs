﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Models.Consts
{
    /// <summary>
    /// 会员卡的数据库连接
    /// </summary>
    public static class CardDBConstConn
    {
        /// <summary>
        /// 会员卡的数据库连接
        /// </summary>
        public static string ConnectionCardDBStr { get; set; }
    }
}

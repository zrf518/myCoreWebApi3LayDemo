﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class StringRsaFromartConst
    {
        /// <summary>
        /// utf-8
        /// </summary>
        public const string UTF8 = "utf-8";
        /// <summary>
        /// RAS
        /// </summary>
        public const string RAS = "RSA";

    }
}

﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 团体类型维护设置接口定义
    /// </summary>
    public interface ITeamTypeInterface
    {
        /// <summary>
        /// 新增团体类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddTeamTypeAsync(TeamTypeDto dto);
        /// <summary>
        /// 编辑团体类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditTeamTypeAsync(TeamTypeDto dto);
        /// <summary>
        /// 查询团体类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<TeamTypeSearchResultDto>>> QueryTeamTypeAsync(TeamTypeSearchParamDto dto);
        /// <summary>
        /// 删除团体类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveTeamTypeAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除团体类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveTeamTypeAsync(string sUserWorkNo, List<int> ids);
    }
}

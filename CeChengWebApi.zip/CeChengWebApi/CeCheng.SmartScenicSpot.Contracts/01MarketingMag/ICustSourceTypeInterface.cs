﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 客源类型设置接口定义
    /// </summary>
    public interface ICustSourceTypeInterface
    {
        /// <summary>
        /// 新增客源类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddCustSourceTypeAsync(CustSourceTypeDto dto);
        /// <summary>
        /// 编辑客源类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditCustSourceTypeAsync(CustSourceTypeDto dto);
        /// <summary>
        /// 查询客源类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CustSourceTypeSearchResultDto>>> QueryCustSourceTypeAsync(CustSourceTypeSearchParamDto dto);
        /// <summary>
        /// 删除客源类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCustSourceTypeAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除客源类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCustSourceTypeAsync(string sUserWorkNo, List<int> ids);
    }
}

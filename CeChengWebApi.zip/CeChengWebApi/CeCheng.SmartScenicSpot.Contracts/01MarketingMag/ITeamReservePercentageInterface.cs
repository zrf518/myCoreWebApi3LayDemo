﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 团体预定提成接口定义
    /// </summary>
    public interface ITeamReservePercentageInterface
    {
        /// <summary>
        /// 新增团体预定提成
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddTeamReservePercentageAsync(TeamReservePercentageDto dto);
        /// <summary>
        /// 编辑团体预定提成
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditTeamReservePercentageAsync(TeamReservePercentageDto dto);
        /// <summary>
        /// 查询团体预定提成
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<TeamReservePercentageSearchResultDto>>> QueryTeamReservePercentageAsync(TeamReservePercentageSearchParamDto dto);
        /// <summary>
        /// 删除团体预定提成
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveTeamReservePercentageAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除团体预定提成
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveTeamReservePercentageAsync(string sUserWorkNo, List<int> ids);
    }
}

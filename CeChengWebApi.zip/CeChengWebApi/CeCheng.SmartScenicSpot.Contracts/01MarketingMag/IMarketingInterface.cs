﻿using CeCheng.SmartScenicSpot.Models;
using CeCheng.SmartScenicSpot.Models.Dto.MarketingMag;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 
    /// </summary>
    public interface IMarketingInterface
    {
        /// <summary>
        ///测试接口
        /// </summary>
        /// <param name="listdto"></param>
        /// <returns></returns>
        public Task<string> DoTest001(List<MarkAddOrEditDto>listdto);
        /// <summary>
        /// 接口案例 分页强类型
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<LoginUserInfo>>> DoTest004(MarkQueryInputDto dto);
    }
}

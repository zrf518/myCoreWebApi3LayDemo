﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 营业点售卖项目接口定义
    /// </summary>
    public interface IOutletsConsumeItemSetInterface
    {
        /// <summary>
        /// 新增营业点售卖项目
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddOutletsConsumeItemSetAsync(OutletsConsumeItemSetDto dto);
        /// <summary>
        /// 编辑营业点售卖项目
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditOutletsConsumeItemSetAsync(OutletsConsumeItemSetDto dto);
        /// <summary>
        /// 查询营业点售卖项目
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<OutletsConsumeItemSetSearchResultDto>>> QueryOutletsConsumeItemSetAsync(OutletsConsumeItemSetSearchParamDto dto);
        /// <summary>
        /// 删除营业点售卖项目
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveOutletsConsumeItemSetAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除营业点售卖项目
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveOutletsConsumeItemSetAsync(string sUserWorkNo, List<int> ids);
    }
}

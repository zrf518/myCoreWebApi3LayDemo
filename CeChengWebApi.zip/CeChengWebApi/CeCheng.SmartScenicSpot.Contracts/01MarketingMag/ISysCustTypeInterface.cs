﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 客类设置接口定义
    /// </summary>
    public interface ISysCustTypeInterface
    {
        /// <summary>
        /// 新增客类设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddSysCustTypeAsync(SysCustTypeDto dto);
        /// <summary>
        /// 编辑客类设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditSysCustTypeAsync(SysCustTypeDto dto);
        /// <summary>
        /// 查询客类设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<SysCustTypeSearchResultDto>>> QuerySysCustTypeAsync(SysCustTypeSearchParamDto dto);
        /// <summary>
        /// 删除客类设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveSysCustTypeAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除客类设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveSysCustTypeAsync(string sUserWorkNo, List<int> ids);
    }
}

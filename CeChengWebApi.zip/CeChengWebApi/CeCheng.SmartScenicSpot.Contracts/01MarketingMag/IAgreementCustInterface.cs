﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 协议客户设置接口定义
    /// </summary>
    public interface IAgreementCustInterface
    {
        /// <summary>
        /// 新增协议客户设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddAgreementCustAsync(AgreementCustDto dto);
        /// <summary>
        /// 编辑协议客户设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditAgreementCustAsync(AgreementCustDto dto);
        /// <summary>
        /// 查询协议客户设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<AgreementCustSearchResultDto>>> QueryAgreementCustAsync(AgreementCustSearchParamDto dto);
        /// <summary>
        /// 删除协议客户设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveAgreementCustAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除协议客户设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveAgreementCustAsync(string sUserWorkNo, List<int> ids);
    }
}

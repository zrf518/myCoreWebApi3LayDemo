﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 协议类型维护设置接口定义
    /// </summary>
    public interface IAgreementTypeInterface
    {
        /// <summary>
        /// 新增协议类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddAgreementTypeAsync(AgreementTypeDto dto);
        /// <summary>
        /// 编辑协议类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditAgreementTypeAsync(AgreementTypeDto dto);
        /// <summary>
        /// 查询协议类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<AgreementTypeSearchResultDto>>> QueryAgreementTypeAsync(AgreementTypeSearchParamDto dto);
        /// <summary>
        /// 删除协议类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveAgreementTypeAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除协议类型维护设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveAgreementTypeAsync(string sUserWorkNo, List<int> ids);
    }
}

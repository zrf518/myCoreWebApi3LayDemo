﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 微信会员设置接口定义
    /// </summary>
    public interface IWxMemberInfoInterface
    {
        /// <summary>
        /// 新增微信会员设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddWxMemberInfoAsync(string sCardDBConn, WxMemberInfoDto dto);
        /// <summary>
        /// 编辑微信会员设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditWxMemberInfoAsync(string sCardDBConn, WxMemberInfoDto dto);
        /// <summary>
        /// 查询微信会员设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<WxMemberInfoSearchResultDto>>> QueryWxMemberInfoAsync(string sCardDBConn, WxMemberInfoSearchParamDto dto);
        /// <summary>
        /// 删除微信会员设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveWxMemberInfoAsync(string sCardDBConn, string sUserWorkNo, int MemberID);
        /// <summary>
        /// 批量删除微信会员设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveWxMemberInfoAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

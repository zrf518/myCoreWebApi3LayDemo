﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 短信信息模板设置接口定义
    /// </summary>
    public interface IGsmMessageTemplateInterface
    {
        /// <summary>
        /// 新增短信信息模板设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddGsmMessageTemplateAsync(string sCardDBConn, GsmMessageTemplateDto dto);
        /// <summary>
        /// 编辑短信信息模板设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditGsmMessageTemplateAsync(string sCardDBConn, GsmMessageTemplateDto dto);
        /// <summary>
        /// 查询短信信息模板设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<GsmMessageTemplateSearchResultDto>>> QueryGsmMessageTemplateAsync(string sCardDBConn, GsmMessageTemplateSearchParamDto dto);
        /// <summary>
        /// 删除短信信息模板设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveGsmMessageTemplateAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除短信信息模板设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveGsmMessageTemplateAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

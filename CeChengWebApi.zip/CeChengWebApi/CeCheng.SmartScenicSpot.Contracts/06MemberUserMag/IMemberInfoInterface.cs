﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 会员资料表接口定义
    /// </summary>
    public interface IMemberInfoInterface
    {
        /// <summary>
        /// 新增会员资料表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddMemberInfoAsync(string sCardDBConn, MemberInfoDto dto);
        /// <summary>
        /// 编辑会员资料表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditMemberInfoAsync(string sCardDBConn, MemberInfoDto dto);
        /// <summary>
        /// 查询会员资料表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<MemberInfoSearchResultDto>>> QueryMemberInfoAsync(string sCardDBConn, MemberInfoSearchParamDto dto);
        /// <summary>
        /// 删除会员资料表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveMemberInfoAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除会员资料表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveMemberInfoAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

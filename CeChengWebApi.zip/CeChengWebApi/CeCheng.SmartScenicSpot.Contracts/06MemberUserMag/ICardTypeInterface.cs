﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 卡类接口定义
    /// </summary>
    public interface ICardTypeInterface
    {
        /// <summary>
        /// 新增卡类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddCardTypeAsync(string sCardDBConn, CardTypeDto dto);
        /// <summary>
        /// 编辑卡类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditCardTypeAsync(string sCardDBConn, CardTypeDto dto);
        /// <summary>
        /// 查询卡类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardTypeSearchResultDto>>> QueryCardTypeAsync(string sCardDBConn, CardTypeSearchParamDto dto);
        /// <summary>
        /// 删除卡类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardTypeAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除卡类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardTypeAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

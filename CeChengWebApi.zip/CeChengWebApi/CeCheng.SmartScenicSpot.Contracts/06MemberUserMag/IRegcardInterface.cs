﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 会员卡设置接口定义
    /// </summary>
    public interface IRegcardInterface
    {
        /// <summary>
        /// 新增会员卡设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddRegcardAsync(string sCardDBConn, RegcardCreateDto dto);
        /// <summary>
        /// 编辑会员卡设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditRegcardAsync(string sCardDBConn, RegcardDto dto);
        /// <summary>
        /// 查询会员卡设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<RegcardSearchResultDto>>> QueryRegcardAsync(string sCardDBConn, RegcardSearchParamDto dto);
        /// <summary>
        /// 会员卡充值
        /// </summary>
        Task<ApiResultDto> ChongZhiRegcardAsync(string sCardDBConn, RegcardAddMoneyDto dto);
        /// <summary>
        /// 会员卡修改密码
        /// </summary>
        Task<ApiResultDto> ModifyPwdRegcardAsync(string sCardDBConn, RegcardModifyPwdDto dto);
        /// <summary>
        /// 会员卡重置密码
        /// </summary>
        Task<ApiResultDto> ResetPwdRegcardAsync(string sCardDBConn, RegcardModifyPwdDto dto);
        /// <summary>
        /// 会员卡状态修改（挂失、解挂、停用、启用这几个状态设置）
        /// </summary>
        Task<ApiResultDto> ModifyStateRegcardAsync(string sCardDBConn, RegcardStateModifyDto dto);
        /// <summary>
        /// 会员卡取消发卡
        /// </summary>
        Task<ApiResultDto> CancelRegcardAsync(string sCardDBConn, RegcardCancelDto dto);
        /// <summary>
        /// 会员卡补卡
        /// </summary>
        Task<ApiResultDto> BuKaRegcardAsync(string sCardDBConn, RegcardBuKaDto dto);
        /// <summary>
        /// 会员卡回收
        /// </summary>
        Task<ApiResultDto> HuiShouRegcardAsync(string sCardDBConn, RegcardHuiShouDto dto);
        /// <summary>
        /// 会员卡退卡
        /// </summary>
        Task<ApiResultDto> TuiKaRegcardAsync(string sCardDBConn, RegcardTuiKaDto dto);
        /// <summary>
        /// 会员卡转卡
        /// </summary>
        Task<ApiResultDto> ZhuanKaRegcardAsync(string sCardDBConn, RegcardZhuanKaDto dto);
    }
}

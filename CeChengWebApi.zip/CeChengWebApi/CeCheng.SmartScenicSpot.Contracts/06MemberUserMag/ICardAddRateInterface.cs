﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 增值比率接口定义
    /// </summary>
    public interface ICardAddRateInterface
    {
        /// <summary>
        /// 新增增值比率
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddCardAddRateAsync(string sCardDBConn, CardAddRateDto dto);
        /// <summary>
        /// 编辑增值比率
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditCardAddRateAsync(string sCardDBConn, CardAddRateDto dto);
        /// <summary>
        /// 查询增值比率
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardAddRateSearchResultDto>>> QueryCardAddRateAsync(string sCardDBConn, CardAddRateSearchParamDto dto);
        /// <summary>
        /// 删除增值比率
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardAddRateAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除增值比率
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardAddRateAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

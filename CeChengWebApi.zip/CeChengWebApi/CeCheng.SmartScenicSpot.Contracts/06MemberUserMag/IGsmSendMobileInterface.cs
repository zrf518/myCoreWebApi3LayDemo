﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 短信发送接口定义
    /// </summary>
    public interface IGsmSendMobileInterface
    {
        /// <summary>
        /// 新增短信发送
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddGsmSendMobileAsync(string sCardDBConn, List<GsmSendMobileEntity> dtos);
        /// <summary>
        /// 查询短信发送
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<GsmSendMobileSearchResultDto>>> QueryGsmSendMobileAsync(string sCardDBConn, GsmSendMobileSearchParamDto dto);
        /// <summary>
        /// 删除短信发送
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveGsmSendMobileAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除短信发送
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveGsmSendMobileAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

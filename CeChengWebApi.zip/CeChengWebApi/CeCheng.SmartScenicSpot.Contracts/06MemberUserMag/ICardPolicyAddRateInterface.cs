﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 优惠政策与增值比率关联设置接口定义
    /// </summary>
    public interface ICardPolicyAddRateInterface
    {
        /// <summary>
        /// 新增优惠政策与增值比率关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddCardPolicyAddRateAsync(string sCardDBConn, CardPolicyAddRateDto dto);
        /// <summary>
        /// 编辑优惠政策与增值比率关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditCardPolicyAddRateAsync(string sCardDBConn, CardPolicyAddRateDto dto);
        /// <summary>
        /// 查询优惠政策与增值比率关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardPolicyAddRateSearchResultDto>>> QueryCardPolicyAddRateAsync(string sCardDBConn, CardPolicyAddRateSearchParamDto dto);
        /// <summary>
        /// 删除优惠政策与增值比率关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardPolicyAddRateAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除优惠政策与增值比率关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardPolicyAddRateAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

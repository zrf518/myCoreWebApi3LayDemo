﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 开票记录接口定义
    /// </summary>
    public interface ITaxRecordInterface
    {
        /// <summary>
        /// 新增开票记录
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddTaxRecordAsync(string sCardDBConn, TaxRecordDto dto);
        /// <summary>
        /// 查询开票记录
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<TaxRecordSearchResultDto>>> QueryTaxRecordAsync(string sCardDBConn, TaxRecordSearchParamDto dto);
    }
}

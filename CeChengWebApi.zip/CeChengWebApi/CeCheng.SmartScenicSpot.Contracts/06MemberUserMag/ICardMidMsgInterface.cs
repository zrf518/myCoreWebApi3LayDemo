﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 卡务记录中间表接口定义
    /// </summary>
    public interface ICardMidMsgInterface
    {
        /// <summary>
        /// 查询卡务记录中间表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardMidMsgSearchResultDto>>> QueryCardMidMsgAsync(string sCardDBConn, CardMidMsgSearchParamDto dto);
        /// <summary>
        /// 删除卡务记录中间表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardMidMsgAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除卡务记录中间表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardMidMsgAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

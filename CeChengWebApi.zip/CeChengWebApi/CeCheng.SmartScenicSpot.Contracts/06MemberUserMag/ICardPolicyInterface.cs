﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 优惠政策接口定义
    /// </summary>
    public interface ICardPolicyInterface
    {
        /// <summary>
        /// 新增优惠政策
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddCardPolicyAsync(string sCardDBConn, CardPolicyDto dto);
        /// <summary>
        /// 编辑优惠政策
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditCardPolicyAsync(string sCardDBConn, CardPolicyDto dto);
        /// <summary>
        /// 查询优惠政策
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardPolicySearchResultDto>>> QueryCardPolicyAsync(string sCardDBConn, CardPolicySearchParamDto dto);
        /// <summary>
        /// 删除优惠政策
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardPolicyAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除优惠政策
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardPolicyAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}


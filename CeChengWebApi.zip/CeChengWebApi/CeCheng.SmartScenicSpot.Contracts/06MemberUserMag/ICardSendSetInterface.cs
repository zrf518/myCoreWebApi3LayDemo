﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 会员卡售卡提成设置接口定义
    /// </summary>
    public interface ICardSendSetInterface
    {
        /// <summary>
        /// 新增会员卡售卡提成设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddCardSendSetAsync(string sCardDBConn, CardSendSetDto dto);
        /// <summary>
        /// 编辑会员卡售卡提成设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditCardSendSetAsync(string sCardDBConn, CardSendSetDto dto);
        /// <summary>
        /// 查询会员卡售卡提成设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardSendSetSearchResultDto>>> QueryCardSendSetAsync(string sCardDBConn, CardSendSetSearchParamDto dto);
        /// <summary>
        /// 删除会员卡售卡提成设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardSendSetAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除会员卡售卡提成设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardSendSetAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

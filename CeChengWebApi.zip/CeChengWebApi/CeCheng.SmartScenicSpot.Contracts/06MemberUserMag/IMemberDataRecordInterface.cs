﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 会员资料修改记录表接口定义
    /// </summary>
    public interface IMemberDataRecordInterface
    {
        /// <summary>
        /// 查询会员资料修改记录表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<MemberDataRecordSearchResultDto>>> QueryMemberDataRecordAsync(string sCardDBConn, MemberDataRecordSearchParamDto dto);
        /// <summary>
        /// 删除会员资料修改记录表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveMemberDataRecordAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除会员资料修改记录表
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveMemberDataRecordAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

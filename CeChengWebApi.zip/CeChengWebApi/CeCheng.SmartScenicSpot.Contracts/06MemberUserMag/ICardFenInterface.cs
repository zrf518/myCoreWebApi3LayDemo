﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 积分兑换设置接口定义
    /// </summary>
    public interface ICardFenInterface
    {
        /// <summary>
        /// 新增积分兑换设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddCardFenAsync(string sCardDBConn, CardFenDto dto);
        /// <summary>
        /// 编辑积分兑换设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditCardFenAsync(string sCardDBConn, CardFenDto dto);
        /// <summary>
        /// 查询积分兑换设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardFenSearchResultDto>>> QueryCardFenAsync(string sCardDBConn, CardFenSearchParamDto dto);
        /// <summary>
        /// 删除积分兑换设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardFenAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除积分兑换设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardFenAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

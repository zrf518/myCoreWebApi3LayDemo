﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 优惠政策与微信劵关联设置接口定义
    /// </summary>
    public interface ICardPolicyTicketInterface
    {
        /// <summary>
        /// 新增优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddCardPolicyTicketAsync(string sCardDBConn, CardPolicyTicketDto dto);
        /// <summary>
        /// 编辑优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditCardPolicyTicketAsync(string sCardDBConn, CardPolicyTicketDto dto);
        /// <summary>
        /// 查询优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardPolicyTicketSearchResultDto>>> QueryCardPolicyTicketAsync(string sCardDBConn, CardPolicyTicketSearchParamDto dto);
        /// <summary>
        /// 删除优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardPolicyTicketAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardPolicyTicketAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

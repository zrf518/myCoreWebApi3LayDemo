﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 卡大类接口定义
    /// </summary>
    public interface ICardBigTypeInterface
    {
        /// <summary>
        /// 新增卡大类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddCardBigTypeAsync(string sCardDBConn, CardBigTypeDto dto);
        /// <summary>
        /// 编辑卡大类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditCardBigTypeAsync(string sCardDBConn, CardBigTypeDto dto);
        /// <summary>
        /// 查询卡大类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardBigTypeSearchResultDto>>> QueryCardBigTypeAsync(string sCardDBConn, CardBigTypeSearchParamDto dto);
        /// <summary>
        /// 删除卡大类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardBigTypeAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除卡大类
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardBigTypeAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

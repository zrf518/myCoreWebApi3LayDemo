﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 会议卡卡务记录接口定义
    /// </summary>
    public interface ICardAccountInterface
    {
        /// <summary>
        /// 查询会议卡卡务记录
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<CardAccountSearchResultDto>>> QueryCardAccountAsync(string sCardDBConn, CardAccountSearchParamDto dto);
        /// <summary>
        /// 删除会议卡卡务记录
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveCardAccountAsync(string sCardDBConn, string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除会议卡卡务记录
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveCardAccountAsync(string sCardDBConn, string sUserWorkNo, List<int> ids);
    }
}

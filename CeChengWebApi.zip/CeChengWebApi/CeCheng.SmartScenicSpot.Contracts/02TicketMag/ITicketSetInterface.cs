﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 门票设置接口定义
    /// </summary>
    public interface ITicketSetInterface
    {
        /// <summary>
        /// 新增门票设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddTicketSetAsync(TicketSetDto dto);
        /// <summary>
        /// 编辑门票设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditTicketSetAsync(TicketSetDto dto);
        /// <summary>
        /// 查询门票设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<TicketSetSearchResultDto>>> QueryTicketSetAsync(TicketSetSearchParamDto dto);
        /// <summary>
        /// 删除门票设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveTicketSetAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除门票设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveTicketSetAsync(string sUserWorkNo, List<int> ids);
    }
}

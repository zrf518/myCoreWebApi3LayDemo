﻿using CeCheng.SmartScenicSpot.Models;
using CeCheng.SmartScenicSpot.Models.Dto.TicketMag;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 02 票务管理相关模块  开单销售门票
    /// </summary>
    public interface ITicketKdSellInterface
    {
        #region 开单
        /// <summary>
        /// 获取开单 订单编号
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> CreateKdTicketSellNo();
        /// <summary>
        ///销售门票 --开单新增  
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Task<ApiResultDto> AddKdTicket(STicketSellAddDto entity);

        ///// <summary>
        ///// 出票
        ///// </summary>
        ///// <returns></returns>
        //Task<ApiResultDto> OutKdTicketAsync(SticketOutDto dto);

        /// <summary>
        /// 根据 开单生成的出票的主键id来删除选择的出票信息 
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveChoseTicket(QueryByIdDto dto);

        #endregion

        #region 销售门票- 付款
        /// <summary>
        ///销售门票  --付款写入到记录表  
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        ApiResultDto InsertPayTicket(STicketSellRecordDto dto);
        /// <summary>
        /// 结账 -- 改销售表的状态，改成结账状态
        /// </summary>
        /// <param name="sell_id"></param>
        /// <returns></returns>
        Task<ApiResultDto> JieZhangTicket(QueryByIdDto sell_id);
        #endregion

        #region 出票
        /// <summary>
        /// 查询出票的列表数据
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Task<ApiResultDto<List<STicketSellRecordDetailEntity>>> QueryOutTicketInfoAsync(QueryByIdDto entity);

        /// <summary>
        ///根据选择的票id来 --- 取票等操作 更新门票的相关状态时间等
        /// （这个出票只是更改明细表里面的票的出票状态，也就是更新is_print的值）
        /// </summary>
        /// <param name="record_detail_id">根据选择的票id来出票 甚至打印票等操作</param>
        /// <returns></returns>
        Task<ApiResultDto> OutTicketAsync(List<int> record_detail_id);
        #endregion

        #region 人工售票记录查询
        /// <summary>
        /// 取消开单 删除  主表与记录表
        /// </summary>
        /// <param name="sell_id"></param>
        /// <returns></returns>
        Task<ApiResultDto> CancelKdTicket(QueryByIdDto sell_id);
        /// <summary>
        /// 查询开单主列表 信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<STitcketSellEntity>>> QueryKdTicket(STicketSellQueryDto dto);

        /// <summary>
        /// 根据选择一个单信息 查询所有的票的信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultDto<List<GetSTicketSellRecordDetailEntity>>> QueryKdRecordDetailTicket(QueryByIdWithPageNationDto dto);
        /// <summary>
        /// 取票、退票时会使用到 根据选择一个订单号 查询所有的票的类型  record信息  
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultDto<List<GetSTicketSellRecord>>> QueryKdRecordTicket(QueryTicketRecordBySellNo dto);
        /// <summary>
        /// 根据票号，查询对应可以退的门票列表  
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultDto<GetSTicketSellRecord>> QueryKdRecordTicketByTicketNoToQuit(QueryTicketRecordByTicketNo dto);
        #endregion

        /// <summary>
        /// 修改出票的具体一张票的有效期时间接口
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> UpdateOutTicketValidateTime(UpdateTicketValidateTimeDto ticketid);

        /// <summary>
        /// 销售门票 --出票 触发器写入
        /// （这个出票是生成当前单据的所有的票到detail明细表里）
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        Task<ApiResultDto> OutKdTicketToDetail(QueryByIdDto entity);

        #region 预订单
        /// <summary>
        /// 新增 预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultDto> AddSTicketsBooking(STicketsBookingAddDto dto);

        /// <summary>
        /// 修改 预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultDto> EditSTicketsBooking(STicketsBookingEditDto dto);

        /// <summary>
        /// 删除 预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultDto> RemoveSTicketsBooking(QueryByIdDto dto);

        /// <summary>
        /// 取消预定门票
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultDto> CancelSTicketsBooking(CancelSTicketsBookingParamDto dto);

        /// <summary>
        /// 分页查询 预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<STicketsBookingPageQueryDto>>> QuerySTicketsBooking(STicketsBookingQueryDto dto);

        /// <summary>
        /// 查询单个预定单的整单信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultDto<STicketsBookingOneQueryDto>> QueryOneSTicketsBookingInfo(QueryByIdDto dto);

        /// <summary>
        /// 新增、编辑保存预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        Task<ApiResultDto<STicketsBookingDto>> SaveSTicketsBooking(STicketsBookingSaveDto dto);

        #endregion

        //#region 取票
        ///// <summary>
        ///// 取票查询 根据取票凭证码，查询出对应的票的信息（单据信息、记录信息、票明细信息）  
        ///// </summary>
        ///// <param name="dto"></param>
        ///// <returns></returns>
        //ApiResultDto<QuPiaoQueryResultDto> QuPiaoQuery(QuPiaoQueryDto dto);
        //#endregion

        /// <summary>
        /// 批量修改票的而有效期
        /// </summary>
        /// <param name="dto">批量修改票的而有效期实体</param>
        /// <returns></returns>
        Task<ApiResultDto> BattchUpdateValidDate(BattchUpdateValidDateDto dto);


        /// <summary>
        /// 操作退票
        /// </summary>
        /// <param name="dto">退票参数实体</param>
        /// <returns></returns>
        Task<ApiResultDto> ExecQuitTicket(QuitTicketDto dto);

    }
}

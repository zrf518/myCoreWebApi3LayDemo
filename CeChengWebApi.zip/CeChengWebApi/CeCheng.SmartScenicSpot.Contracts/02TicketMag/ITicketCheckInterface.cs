﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 02 票务管理相关模块  门票验票
    /// </summary>
    public interface ITicketCheckInterface
    {
    }
}

﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 门票项目设置接口定义
    /// </summary>
    public interface ITicketItemInterface
    {
        /// <summary>
        /// 新增门票项目设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddTicketItemAsync(TicketItemDto dto);
        /// <summary>
        /// 编辑门票项目设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditTicketItemAsync(TicketItemDto dto);
        /// <summary>
        /// 查询门票项目设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<TicketItemSearchResultDto>>> QueryTicketItemAsync(TicketItemSearchParamDto dto);
        /// <summary>
        /// 删除门票项目设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveTicketItemAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除门票项目设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveTicketItemAsync(string sUserWorkNo, List<int> ids);
        /// <summary>
        /// 批量新增门票项目设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchAddTicketItemAsync(TicketItemListDtos dto);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// OTA票务平台数据接口
    /// </summary>
    public interface IOTATicketDataInterface
    {
    }
}

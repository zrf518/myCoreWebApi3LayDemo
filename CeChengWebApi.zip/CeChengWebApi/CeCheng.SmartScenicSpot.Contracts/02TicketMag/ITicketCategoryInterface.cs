﻿using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Contracts
{
    /// <summary>
    /// 门票类型设置接口定义
    /// </summary>
    public interface ITicketCategoryInterface
    {
        /// <summary>
        /// 新增门票类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> AddTicketCategoryAsync(TicketCategoryDto dto);
        /// <summary>
        /// 编辑门票类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> EditTicketCategoryAsync(TicketCategoryDto dto);
        /// <summary>
        /// 查询门票类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultPageNationTDataDto<List<TicketCategorySearchResultDto>>> QueryTicketCategoryAsync(TicketCategorySearchParamDto dto);
        /// <summary>
        /// 删除门票类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> RemoveTicketCategoryAsync(string sUserWorkNo, int id);
        /// <summary>
        /// 批量删除门票类型设置
        /// </summary>
        /// <returns></returns>
        Task<ApiResultDto> BattchRemoveTicketCategoryAsync(string sUserWorkNo, List<int> ids);
    }
}

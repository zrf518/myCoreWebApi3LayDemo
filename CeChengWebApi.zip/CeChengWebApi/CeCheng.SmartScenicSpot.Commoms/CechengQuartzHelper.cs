﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CeCheng.SmartScenicSpot.Commoms
{
    /// <summary>
    /// 
    /// </summary>
    public class CechengQuartzHelper
    {
    }
}

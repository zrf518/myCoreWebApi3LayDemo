﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models.Dto.MarketingMag;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;
using CeCheng.SmartScenicSpot.Models;
using System.Linq;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 测试案例
    /// </summary>
    public class MarketingService : IMarketingInterface
    {
        /// <summary>
        /// 测试接口实现
        /// </summary>
        /// <returns></returns>
        public async Task<string> DoTest001(List<MarkAddOrEditDto> listdto)
        {
            var jsonStr = JsonConvert.SerializeObject(new
            {
                Id = 100,
                Name = "策城员工-小张",
                Age = 18,
                MarkInfo = listdto
            });
            return await Task.FromResult<string>(jsonStr);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<LoginUserInfo>>> DoTest004(MarkQueryInputDto dto)
        {
            //查到的数据
            var getdata = new List<LoginUserInfo> {
                         new LoginUserInfo{ account="qq1",s_branch_id=1,pwd="123456"},
                         new LoginUserInfo{ account="ww1",s_branch_id=2,pwd="123456"},
                         new LoginUserInfo{ account="ee1",s_branch_id=3,pwd="123456"},
                         new LoginUserInfo{ account="rr1",s_branch_id=4,pwd="123456"},
                         new LoginUserInfo{ account="qq2",s_branch_id=5,pwd="123456"}
                };

            var totalcount =  getdata.Where(c => c.account.Contains(dto.MarkName)).Count();
            var listdata = new List<LoginUserInfo>();
            if (totalcount>0)
            {
                int skip = (dto.pageIndex - 1) * dto.pageSize;
                int take = dto.pageSize;
                listdata= getdata.Where(c => c.account.Contains(dto.MarkName)).Skip(skip).Take(take).ToList();
            }
            await Task.CompletedTask;
            return ApiResultPageNationTDataDto<List<LoginUserInfo>>.ToResultSuccess(data:listdata,PageIndex:dto.pageIndex,PageSize:dto.pageSize,TotalRow:totalcount);
        }
    }
}

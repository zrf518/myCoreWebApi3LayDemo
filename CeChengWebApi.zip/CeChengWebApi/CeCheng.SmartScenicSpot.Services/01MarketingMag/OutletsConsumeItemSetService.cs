﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 营业点售卖项目接口实现
    /// </summary>
    public class OutletsConsumeItemSetService : IOutletsConsumeItemSetInterface
    {
        /// <summary>
        /// 新增营业点售卖项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddOutletsConsumeItemSetAsync(OutletsConsumeItemSetDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<OutletsConsumeItemSetEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.outlets_setup_id == dto.outlets_setup_id.Value && x.s_consume_item_id == dto.s_consume_item_id.Value && x.n_type == dto.n_type.Value)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "设置重复项");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<OutletsConsumeItemSetEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑营业点售卖项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditOutletsConsumeItemSetAsync(OutletsConsumeItemSetDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<OutletsConsumeItemSetEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id 
                && (x.outlets_setup_id == dto.outlets_setup_id.Value && x.s_consume_item_id == dto.s_consume_item_id.Value && x.n_type == dto.n_type.Value))
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "设置重复项");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<OutletsConsumeItemSetEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<OutletsConsumeItemSetEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询营业点售卖项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<OutletsConsumeItemSetSearchResultDto>>> QueryOutletsConsumeItemSetAsync(OutletsConsumeItemSetSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and oc.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and oc.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.outlets_setup_id.HasValue)
            {
                sWhere += " and oc.outlets_setup_id = @outlets_setup_id";
                listSqlParam.Add(new SugarParameter("@outlets_setup_id", dto.outlets_setup_id.Value));
            }
            if (null != dto && dto.s_consume_item_id.HasValue)
            {
                sWhere += " and oc.s_consume_item_id = @s_consume_item_id";
                listSqlParam.Add(new SugarParameter("@s_consume_item_id", dto.s_consume_item_id.Value));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.outlet_no))
            {
                sWhere += " and oc.outlet_no = @outlet_no";
                listSqlParam.Add(new SugarParameter("@outlet_no", dto.outlet_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.consume_item_no))
            {
                sWhere += " and oc.consume_item_no = @consume_item_no";
                listSqlParam.Add(new SugarParameter("@consume_item_no", dto.consume_item_no));
            }
            if (null != dto && dto.n_type.HasValue)
            {
                sWhere += " and oc.n_type = @n_type";
                listSqlParam.Add(new SugarParameter("@n_type", dto.n_type.Value));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.outlet_name))
            {
                sWhere += " and os.outlet_name like '%' + @outlet_name + '%'";
                listSqlParam.Add(new SugarParameter("@outlet_name", dto.outlet_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.consume_item_name))
            {
                sWhere += $@" and (
                                        (oc.n_type = 1 and ts.ticket_name       like '%' + @consume_item_name + '%')
                                        or
                                        (oc.n_type = 2 and ci.consume_item_name like '%' + @consume_item_name + '%')
                                   )";
                listSqlParam.Add(new SugarParameter("@consume_item_name", dto.consume_item_name));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and oc.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from    outlets_consume_item_set  oc
                                            left join outlets_setup   os on os.id = oc.outlets_setup_id
                                            left join s_ticket_set    ts on ts.id = oc.s_consume_item_id and oc.n_type = 1
                                            left join s_consume_item  ci on ci.id = oc.s_consume_item_id and oc.n_type = 2
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by oc.id desc) as row_no,
		                                    oc.id, oc.outlets_setup_id, oc.outlet_no, oc.s_consume_item_id, oc.consume_item_no, oc.n_type, oc.memo,
		                                    oc.create_date, oc.update_date, oc.create_user_wno, oc.update_user_wno, oc.s_branch_id, oc.is_active,
		                                    outlet_name = isnull(os.outlet_name, ''),
		                                    consume_item_name = case when oc.n_type = 1 then isnull(ts.ticket_name, '')
		                                                             when oc.n_type = 2 then isnull(ci.consume_item_name, '')
		                                                             else ''
		                                                             end
                                    from    outlets_consume_item_set  oc
                                            left join outlets_setup   os on os.id = oc.outlets_setup_id
                                            left join s_ticket_set    ts on ts.id = oc.s_consume_item_id and oc.n_type = 1
                                            left join s_consume_item  ci on ci.id = oc.s_consume_item_id and oc.n_type = 2
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<OutletsConsumeItemSetSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<OutletsConsumeItemSetSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除营业点售卖项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveOutletsConsumeItemSetAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  outlets_consume_item_set  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除营业点售卖项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveOutletsConsumeItemSetAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  outlets_consume_item_set  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

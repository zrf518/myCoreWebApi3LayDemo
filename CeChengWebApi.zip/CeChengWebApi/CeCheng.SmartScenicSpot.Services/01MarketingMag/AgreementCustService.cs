﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 协议客户设置接口实现
    /// </summary>
    public class AgreementCustService : IAgreementCustInterface
    {
        /// <summary>
        /// 新增协议客户设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddAgreementCustAsync(AgreementCustDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<AgreementCustEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.agreement_cust_account_no == dto.agreement_cust_account_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "协议客户账号重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<AgreementCustEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑协议客户设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditAgreementCustAsync(AgreementCustDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<AgreementCustEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.agreement_cust_account_no == dto.agreement_cust_account_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "协议客户账号重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<AgreementCustEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<AgreementCustEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询协议客户设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<AgreementCustSearchResultDto>>> QueryAgreementCustAsync(AgreementCustSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and sac.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and sac.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.agreement_cust_account_no))
            {
                sWhere += " and sac.agreement_cust_account_no = @agreement_cust_account_no";
                listSqlParam.Add(new SugarParameter("@agreement_cust_account_no", dto.agreement_cust_account_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.agreement_cust_name))
            {
                sWhere += " and sac.agreement_cust_name like '%' + @agreement_cust_name + '%'";
                listSqlParam.Add(new SugarParameter("@agreement_cust_name", dto.agreement_cust_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_tele))
            {
                sWhere += " and sac.s_tele like '%' + @s_tele + '%'";
                listSqlParam.Add(new SugarParameter("@s_tele", dto.s_tele));
            }
            if (null != dto && dto.s_sys_cust_type_id.HasValue)
            {
                sWhere += " and sac.s_sys_cust_type_id = @s_sys_cust_type_id";
                listSqlParam.Add(new SugarParameter("@s_sys_cust_type_id", dto.s_sys_cust_type_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.cust_code))
            {
                sWhere += " and sct.cust_code = @cust_code";
                listSqlParam.Add(new SugarParameter("@cust_code", dto.cust_code));
            }
            if (null != dto && dto.arrive_date_start.HasValue)
            {
                sWhere += " and sac.arrive_date >= @arrive_date_start";
                listSqlParam.Add(new SugarParameter("@arrive_date_start", dto.arrive_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.arrive_date_end.HasValue)
            {
                sWhere += " and sac.arrive_date <= @arrive_date_end";
                listSqlParam.Add(new SugarParameter("@arrive_date_end", dto.arrive_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.validate_date_start.HasValue)
            {
                sWhere += " and sac.validate_date >= @validate_date_start";
                listSqlParam.Add(new SugarParameter("@validate_date_start", dto.validate_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.validate_date_end.HasValue)
            {
                sWhere += " and sac.validate_date <= @validate_date_end";
                listSqlParam.Add(new SugarParameter("@validate_date_end", dto.validate_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.dt_stop_start.HasValue)
            {
                sWhere += " and sac.dt_stop >= @dt_stop_start";
                listSqlParam.Add(new SugarParameter("@dt_stop_start", dto.dt_stop_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.dt_stop_end.HasValue)
            {
                sWhere += " and sac.dt_stop <= @dt_stop_end";
                listSqlParam.Add(new SugarParameter("@dt_stop_end", dto.dt_stop_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.can_guazhang))
            {
                sWhere += " and dp.can_guazhang = @can_guazhang";
                listSqlParam.Add(new SugarParameter("@can_guazhang", dto.can_guazhang));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.pyjm))
            {
                sWhere += " and dp.pyjm like '%' + @pyjm + '%'";
                listSqlParam.Add(new SugarParameter("@pyjm", dto.pyjm));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.saler))
            {
                sWhere += " and dp.saler = @saler";
                listSqlParam.Add(new SugarParameter("@saler", dto.saler));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.fycode))
            {
                sWhere += " and dp.fycode = @fycode";
                listSqlParam.Add(new SugarParameter("@fycode", dto.fycode));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_agreement_cust sac
                                           left join s_sys_cust_type     sct on sct.id = sac.s_sys_cust_type_id
                                           left join s_cust_source_type  cst on cst.cust_source_code = sac.stati_type and cst.s_branch_id = sac.s_branch_id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by sac.id desc) as row_no,
		                                    sac.id, sac.agreement_cust_account_no, sac.agreement_cust_name, sac.arrive_date, 
		                                    sac.validate_date, sac.contacts, sac.remark, sac.discount_type, sac.discount_price, 
		                                    sac.set_work_no, sac.n_credit, sac.saler, sac.[address], sac.post, sac.s_sex, sac.s_pdate, 
		                                    sac.can_guazhang, sac.check_state, sac.s_tele, sac.fax, sac.email, sac.s_sys_cust_type_id, 
		                                    sac.pyjm, sac.s_checkoper, sac.dt_checked, sac.s_stopoper, sac.dt_stop, 
		                                    sac.s_disctype, sac.s_sec_code, sac.stati_type, sac.fycode, sac.create_date, sac.update_date, 
		                                    sac.create_user, sac.update_user, sac.s_branch_id,
		                                    cust_code = sct.cust_code,
		                                    s_sys_cust_type_name = sct.cust_name,
		                                    cust_source_id = cst.id,
		                                    cust_source_desc = cst.cust_source_desc
                                    from   s_agreement_cust sac
                                           left join s_sys_cust_type     sct on sct.id = sac.s_sys_cust_type_id
                                           left join s_cust_source_type  cst on cst.cust_source_code = sac.stati_type and cst.s_branch_id = sac.s_branch_id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<AgreementCustSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<AgreementCustSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除协议客户设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveAgreementCustAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_agreement_cust  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除协议客户设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveAgreementCustAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_agreement_cust  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

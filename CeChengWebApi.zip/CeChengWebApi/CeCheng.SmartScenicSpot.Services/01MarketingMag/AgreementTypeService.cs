﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 协议类型维护设置接口实现
    /// </summary>
    public class AgreementTypeService : IAgreementTypeInterface
    {
        /// <summary>
        /// 新增协议类型维护设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddAgreementTypeAsync(AgreementTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<AgreementTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.agreement_type_no == dto.agreement_type_no).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<AgreementTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑协议类型维护设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditAgreementTypeAsync(AgreementTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<AgreementTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.agreement_type_no == dto.agreement_type_no).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<AgreementTypeEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<AgreementTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询协议类型维护设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<AgreementTypeSearchResultDto>>> QueryAgreementTypeAsync(AgreementTypeSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and at.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and at.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.agreement_type_no))
            {
                sWhere += " and at.agreement_type_no = @agreement_type_no";
                listSqlParam.Add(new SugarParameter("@agreement_type_no", dto.agreement_type_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.agreement_type_name))
            {
                sWhere += " and at.agreement_type_name like '%' + @agreement_type_name + '%'";
                listSqlParam.Add(new SugarParameter("@agreement_type_name", dto.agreement_type_name));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and at.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_agreement_type at
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by at.id desc) as row_no,
                                           at.id, at.agreement_type_no, at.agreement_type_name, at.memo, at.is_active, 
                                           at.s_branch_id, at.create_date, at.create_user, at.update_date, at.update_user
                                    from   s_agreement_type at
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<AgreementTypeSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<AgreementTypeSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除协议类型维护设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveAgreementTypeAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_agreement_type  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除协议类型维护设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveAgreementTypeAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_agreement_type  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}
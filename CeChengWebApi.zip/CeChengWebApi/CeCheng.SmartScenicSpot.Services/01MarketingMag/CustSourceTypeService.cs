﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 客源类型设置接口实现
    /// </summary>
    public class CustSourceTypeService : ICustSourceTypeInterface
    {
        /// <summary>
        /// 新增客源类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddCustSourceTypeAsync(CustSourceTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<CustSourceTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.cust_source_code == dto.cust_source_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<CustSourceTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑客源类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditCustSourceTypeAsync(CustSourceTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<CustSourceTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.cust_source_code == dto.cust_source_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<CustSourceTypeEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<CustSourceTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询客源类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<CustSourceTypeSearchResultDto>>> QueryCustSourceTypeAsync(CustSourceTypeSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and cst.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and cst.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.cust_source_type.HasValue)
            {
                sWhere += " and cst.cust_source_type = @cust_source_type";
                listSqlParam.Add(new SugarParameter("@cust_source_type", dto.cust_source_type));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.cust_source_code))
            {
                sWhere += " and cst.cust_source_code = @cust_source_code";
                listSqlParam.Add(new SugarParameter("@cust_source_code", dto.cust_source_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.cust_source_desc))
            {
                sWhere += " and cst.cust_source_desc like '%' + @cust_source_desc + '%'";
                listSqlParam.Add(new SugarParameter("@cust_source_desc", dto.cust_source_desc));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and cst.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_cust_source_type cst
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by cst.id desc) as row_no,
                                           cst.id, cst.cust_source_code, cst.cust_source_desc, cst.cust_source_type, cst.memo, cst.is_active, 
                                           cst.s_branch_id, cst.create_date, cst.create_user, cst.update_date, cst.update_user
                                    from   s_cust_source_type cst
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<CustSourceTypeSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<CustSourceTypeSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除客源类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveCustSourceTypeAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_cust_source_type  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除客源类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveCustSourceTypeAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_cust_source_type  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}
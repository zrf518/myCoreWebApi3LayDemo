﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 会员资料表接口实现
    /// </summary>
    public class MemberInfoService : IMemberInfoInterface
    {

        /// <summary>
        /// 新增会员资料表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddMemberInfoAsync(string sCardDBConn, MemberInfoDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<MemberInfoEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id 
                       && (  (!string.IsNullOrEmpty(dto.id_number) && x.id_number == dto.id_number)
                          || (!string.IsNullOrEmpty(dto.webchat_id) && x.webchat_id == dto.webchat_id)
                          )
                 )
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "身份证、微信号重复");
            }

            var flag = await _CardDbProvider.UseTranAsync(async () =>
            {
               
                // 执行添加
                var result = await _CardDbProvider.Insertable<MemberInfoEntity>(dto).ExecuteReturnEntityAsync();
                if (null == result || result.id < 1)
                    throw new Exception("会员信息保存异常");

                // 生成操作记录
                MemberDataRecordDto objHis = new MemberDataRecordDto();
                objHis.member_data_id = result.id;
                objHis.member_name = dto.member_name;
                objHis.birthday = dto.birthday;
                objHis.id_number = dto.id_number;
                objHis.telephone = dto.telephone;
                objHis.address = dto.address;
                objHis.pic = dto.pic;
                objHis.webchat_id = dto.webchat_id;
                objHis.sex = dto.sex;
                objHis.province = dto.province;
                objHis.city = dto.city;
                objHis.county = dto.county;
                objHis.subject_id = dto.subject_id;
                objHis.create_date = dto.create_date;
                objHis.create_user = dto.create_user;
                objHis.update_date = dto.update_date;
                objHis.update_user = dto.update_user;
                objHis.s_branch_id = dto.s_branch_id;
                objHis.is_active = dto.is_active;
                objHis.last_day = dto.last_day;
                objHis.memo = dto.memo;

                var resSaveRecord = await _CardDbProvider.Insertable<MemberDataRecordEntity>(objHis).ExecuteCommandAsync();
                if (resSaveRecord < 1)
                    throw new Exception("会员信息操作记录保存异常");
            });

            if (flag.Data)
                return ApiResultDto.ToResultSuccess(data: true);
            else
                throw new Exception(flag.ErrorMessage);
        }
        /// <summary>
        /// 编辑会员资料表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditMemberInfoAsync(string sCardDBConn, MemberInfoDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<MemberInfoEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id 
                       && x.id != dto.id
                       && (    (!string.IsNullOrEmpty(dto.id_number) && x.id_number == dto.id_number)
                            || (!string.IsNullOrEmpty(dto.webchat_id) && x.webchat_id == dto.webchat_id)
                          )
                )
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "身份证、微信号重复");
            }

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<MemberInfoEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }

            // 历史数据
            MemberDataRecordEntity objHis = new MemberDataRecordEntity();
            objHis.member_data_id = dto.id;
            objHis.member_name = resQry.member_name;
            objHis.birthday = resQry.birthday;
            objHis.id_number = resQry.id_number;
            objHis.telephone = resQry.telephone;
            objHis.address = resQry.address;
            objHis.pic = resQry.pic;
            objHis.webchat_id = resQry.webchat_id;
            objHis.sex = resQry.sex;
            objHis.province = resQry.province;
            objHis.city = resQry.city;
            objHis.county = resQry.county;
            objHis.subject_id = resQry.subject_id;
            objHis.create_date = resQry.create_date;
            objHis.create_user = resQry.create_user;
            objHis.update_date = resQry.update_date;
            objHis.update_user = resQry.update_user;
            objHis.s_branch_id = resQry.s_branch_id;
            objHis.is_active = resQry.is_active;
            objHis.last_day = resQry.last_day;
            objHis.memo = resQry.memo;

            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            var flag = await _CardDbProvider.UseTranAsync(async () =>
            {
                // 执行更新
                var result = await _CardDbProvider.Updateable<MemberInfoEntity>(dto).ExecuteCommandAsync();
                if (result < 1)
                    throw new Exception("会员信息更新异常");

                // 生成操作记录
                var resSaveRecord = await _CardDbProvider.Insertable<MemberDataRecordEntity>(objHis).ExecuteCommandAsync();
                if (resSaveRecord < 1)
                    throw new Exception("会员信息操作记录保存异常");
            });

            if (flag.Data)
                return ApiResultDto.ToResultSuccess(data: true);
            else
                throw new Exception(flag.ErrorMessage);
        }

        /// <summary>
        /// 查询会员资料表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<MemberInfoSearchResultDto>>> QueryMemberInfoAsync(string sCardDBConn, MemberInfoSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and mbi.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and mbi.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.member_name))
            {
                sWhere += " and mbi.member_name like '%' + @member_name + '%'";
                listSqlParam.Add(new SugarParameter("@member_name", dto.member_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.telephone))
            {
                sWhere += " and mbi.telephone like '%' + @telephone + '%'";
                listSqlParam.Add(new SugarParameter("@telephone", dto.telephone));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.webchat_id))
            {
                sWhere += " and mbi.webchat_id like '%' + @webchat_id + '%'";
                listSqlParam.Add(new SugarParameter("@webchat_id", dto.webchat_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.id_number))
            {
                sWhere += " and mbi.id_number like '%' + @id_number + '%'";
                listSqlParam.Add(new SugarParameter("@id_number", dto.id_number));
            }
            // 创建时间（开始）
            if (null != dto && dto.create_date_start.HasValue)
            {
                sWhere += " and mbi.create_date >= @create_date_start";
                listSqlParam.Add(new SugarParameter("@create_date_start", dto.create_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            // 创建时间（结束）
            if (null != dto && dto.create_date_end.HasValue)
            {
                sWhere += " and mbi.create_date <= @create_date_end";
                listSqlParam.Add(new SugarParameter("@create_date_end", dto.create_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and mbi.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   member_data mbi
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by mbi.id desc) as row_no,
                                           mbi.id, mbi.member_name, mbi.birthday, mbi.is_active, mbi.id_number, mbi.telephone, mbi.create_date, 
                                           mbi.update_date, mbi.create_user, mbi.update_user, mbi.s_branch_id, mbi.[address], mbi.pic, 
                                           mbi.webchat_id, mbi.sex, mbi.province, mbi.city, mbi.county, mbi.subject_id, mbi.last_day, 
                                           mbi.memo
                                    from   member_data mbi
                                    where  1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<MemberInfoSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<MemberInfoSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除会员资料表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveMemberInfoAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = $@"insert into member_data_record(member_data_id, member_name, birthday, id_number, telephone, [address], pic, webchat_id, sex, province, city, county, subject_id, create_date, create_user, update_date, update_user, s_branch_id, is_active, last_day, memo)
                            select member_data_id=id, member_name, birthday, id_number, telephone, [address], pic, webchat_id, sex, province, city, county, subject_id, create_date, create_user, update_date, update_user, s_branch_id, is_active, last_day, memo
                            from   member_data 
                            where  id={id};
                            delete from  member_data  where id=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除会员资料表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveMemberInfoAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = $@"insert into member_data_record(member_data_id, member_name, birthday, id_number, telephone, [address], pic, webchat_id, sex, province, city, county, subject_id, create_date, create_user, update_date, update_user, s_branch_id, is_active, last_day, memo)
                            select member_data_id=id, member_name, birthday, id_number, telephone, [address], pic, webchat_id, sex, province, city, county, subject_id, create_date, create_user, update_date, update_user, s_branch_id, is_active, last_day, memo
                            from   member_data 
                            where  id in ({sWhere});
                            delete from  member_data  where id in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

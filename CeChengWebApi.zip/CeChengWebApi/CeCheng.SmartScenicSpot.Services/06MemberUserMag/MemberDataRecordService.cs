﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 会员资料修改记录表接口实现
    /// </summary>
    public class MemberDataRecordService : IMemberDataRecordInterface
    {
        /// <summary>
        /// 查询会员资料修改记录表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<MemberDataRecordSearchResultDto>>> QueryMemberDataRecordAsync(string sCardDBConn, MemberDataRecordSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and mbi.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and mbi.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.member_name))
            {
                sWhere += " and mbi.member_name like '%' + @member_name + '%'";
                listSqlParam.Add(new SugarParameter("@member_name", dto.member_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.telephone))
            {
                sWhere += " and mbi.telephone like '%' + @telephone + '%'";
                listSqlParam.Add(new SugarParameter("@telephone", dto.telephone));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.webchat_id))
            {
                sWhere += " and mbi.webchat_id like '%' + @webchat_id + '%'";
                listSqlParam.Add(new SugarParameter("@webchat_id", dto.webchat_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.id_number))
            {
                sWhere += " and mbi.id_number like '%' + @id_number + '%'";
                listSqlParam.Add(new SugarParameter("@id_number", dto.id_number));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and mbi.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   member_data_record mbi
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by mbi.id desc) as row_no,
                                           mbi.id, mbi.member_name, mbi.birthday, mbi.is_active, mbi.id_number, mbi.telephone, mbi.create_date, 
                                           mbi.update_date, mbi.create_user, mbi.update_user, mbi.s_branch_id, mbi.[address], mbi.pic, 
                                           mbi.webchat_id, mbi.sex, mbi.province, mbi.city, mbi.county, mbi.subject_id, mbi.last_day, 
                                           mbi.memo, mbi.member_data_id
                                    from   member_data_record mbi
                                    where  1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<MemberDataRecordSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<MemberDataRecordSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除会员资料修改记录表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveMemberDataRecordAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = "delete from  member_data_record  where id=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除会员资料修改记录表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveMemberDataRecordAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  member_data_record  where id in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

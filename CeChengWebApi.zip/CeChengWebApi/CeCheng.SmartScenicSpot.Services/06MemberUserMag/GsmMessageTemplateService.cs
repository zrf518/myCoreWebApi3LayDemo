﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 短信信息模板设置接口实现
    /// </summary>
    public class GsmMessageTemplateService : IGsmMessageTemplateInterface
    {
        /// <summary>
        /// 新增短信信息模板设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddGsmMessageTemplateAsync(string sCardDBConn, GsmMessageTemplateDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<GsmMessageTemplateEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.sNo == dto.sNo).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await _CardDbProvider.Insertable<GsmMessageTemplateEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑短信信息模板设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditGsmMessageTemplateAsync(string sCardDBConn, GsmMessageTemplateDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<GsmMessageTemplateEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.sNo == dto.sNo).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<GsmMessageTemplateEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await _CardDbProvider.Updateable<GsmMessageTemplateEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询短信信息模板设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<GsmMessageTemplateSearchResultDto>>> QueryGsmMessageTemplateAsync(string sCardDBConn, GsmMessageTemplateSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and gmt.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and gmt.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sNo))
            {
                sWhere += " and gmt.sNo = @sNo";
                listSqlParam.Add(new SugarParameter("@sNo", dto.sNo));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sMsgName))
            {
                sWhere += " and gmt.sMsgName like '%' + @sMsgName + '%'";
                listSqlParam.Add(new SugarParameter("@sMsgName", dto.sMsgName));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and gmt.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   gsm_message_template gmt
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by gmt.id desc) as row_no,
                                           gmt.id, gmt.sNo, gmt.sMsgName, gmt.sMsgContent, gmt.memo, gmt.is_active, 
                                           gmt.s_branch_id, gmt.create_date, gmt.create_user, gmt.update_date, gmt.update_user
                                    from   gsm_message_template gmt
                                    where  1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<GsmMessageTemplateSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<GsmMessageTemplateSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除短信信息模板设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveGsmMessageTemplateAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = "delete from  gsm_message_template  where id=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除短信信息模板设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveGsmMessageTemplateAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  gsm_message_template  where id in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}
﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 会议卡卡务记录接口实现
    /// </summary>
    public class CardAccountService : ICardAccountInterface
    {
        /// <summary>
        /// 查询会议卡卡务记录
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<CardAccountSearchResultDto>>> QueryCardAccountAsync(string sCardDBConn, CardAccountSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and cc.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.BillID != 0)
            {
                sWhere += " and cc.BillID = @BillID";
                listSqlParam.Add(new SugarParameter("@BillID", dto.BillID));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_account_no))
            {
                sWhere += " and cc.s_account_no = @s_account_no";
                listSqlParam.Add(new SugarParameter("@s_account_no", dto.s_account_no));
            }
            // 印刷卡号
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_cardno))
            {
                sWhere += " and cc.s_cardno = @s_cardno";
                listSqlParam.Add(new SugarParameter("@s_cardno", dto.s_cardno));
            }
            if (null != dto && dto.s_member_data_id.HasValue)
            {
                sWhere += " and cc.s_member_data_id = @s_member_data_id";
                listSqlParam.Add(new SugarParameter("@s_member_data_id", dto.s_member_data_id));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.member_name))
            {
                sWhere += " and cc.member_name like '%' + @member_name + '%'";
                listSqlParam.Add(new SugarParameter("@member_name", dto.member_name));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select  iCount = count(*)
                                    from    cardaccount cc   
                                            left join regcard      rc  on cc.s_branch_id = rc.s_branch_id and cc.s_account_no = rc.s_account_no
                                            left join member_data  md  on cc.s_member_data_id = md.ID
                                    where   1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by cc.BillID desc) as row_no,
                                            cc.BillID, cc.s_member_data_id, cc.s_account_no, cc.s_serial_no, cc.s_cardno, cc.s_dep_name, 
                                            cc.s_account_to, cc.n_capital, cc.n_caprmb, cc.n_charge, cc.n_chg_tot, cc.n_fen_charge, 
                                            cc.n_fen_send, cc.n_fen_use, cc.n_hour_cnt, cc.s_sys_date, cc.s_set_date, cc.s_set_time, 
                                            cc.s_set_class, cc.s_set_work, cc.s_emp, cc.s_meno, cc.s_del, cc.s_type, cc.n_send_cnt, 
                                            cc.s_sale, cc.s_tax, cc.s_change, cc.s_old_card, cc.member_id, cc.s_department, cc.n_nowblnce, 
                                            cc.n_send_charge, cc.n_add_cnt, cc.s_branch_happen, cc.card_mid_id, cc.send_to_hq, 
                                            cc.n_send1_charge, cc.n_send_room_charge, cc.s_qrcode, cc.pay_type, cc.add_type, cc.paycode, 
                                            cc.QRcode, cc.OutletNo, cc.s_branch_id,
											rc.s_card_no, rc.s_print_no,
											md.member_name
                                    from    cardaccount cc   
                                            left join regcard      rc  on cc.s_branch_id = rc.s_branch_id and cc.s_account_no = rc.s_account_no
                                            left join member_data  md  on cc.s_member_data_id = md.ID
                                    where   1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                   ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<CardAccountSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<CardAccountSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除会议卡卡务记录
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveCardAccountAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;
            string sql = "delete from  cardaccount  where BillID=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除会议卡卡务记录
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveCardAccountAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  cardaccount  where BillID in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

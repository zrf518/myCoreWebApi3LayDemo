﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 优惠政策与电子劵关联设置接口实现
    /// </summary>
    public class CardPolicyTimesService : ICardPolicyTimesInterface
    {
        /// <summary>
        /// 新增优惠政策与电子劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddCardPolicyTimesAsync(string sCardDBConn, CardPolicyTimesDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<CardPolicyTimesEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.PolicyCode == dto.PolicyCode && x.S_no == dto.S_no && x.s_type == dto.s_type)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "关联设置数据重复");
            }

            // 执行添加
            var result = await _CardDbProvider.Insertable<CardPolicyTimesEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑优惠政策与电子劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditCardPolicyTimesAsync(string sCardDBConn, CardPolicyTimesDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<CardPolicyTimesEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.PolicyCode == dto.PolicyCode && x.S_no == dto.S_no && x.s_type == dto.s_type)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "关联设置数据重复");
            }

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<CardPolicyTimesEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await _CardDbProvider.Updateable<CardPolicyTimesEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询优惠政策与电子劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<CardPolicyTimesSearchResultDto>>> QueryCardPolicyTimesAsync(string sCardDBConn, CardPolicyTimesSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and cpt.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and cpt.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.PolicyCode))
            {
                sWhere += " and cpt.PolicyCode = @PolicyCode";
                listSqlParam.Add(new SugarParameter("@PolicyCode", dto.PolicyCode));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.S_no))
            {
                sWhere += " and cpt.S_no = @S_no";
                listSqlParam.Add(new SugarParameter("@S_no", dto.S_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_type))
            {
                sWhere += " and cpt.s_type = @s_type";
                listSqlParam.Add(new SugarParameter("@s_type", dto.s_type));
            }
            // 优惠政策信息查询
            if (null != dto && dto.s_policy_id.HasValue)
            {
                sWhere += " and cp.id = @s_policy_id";
                listSqlParam.Add(new SugarParameter("@s_policy_id", dto.s_policy_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_policy_name))
            {
                sWhere += " and cp.s_describe like '%' + @s_policy_name + '%'";
                listSqlParam.Add(new SugarParameter("@s_policy_name", dto.s_policy_name));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.is_active))
            {
                sWhere += " and cpt.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select  iCount = count(*)
                                    from    card_policy_times cpt   
                                            left join card_policy     cp on cpt.s_branch_id  = cp.s_branch_id and cpt.PolicyCode  = cp.s_code
                                            left join s_charge_type   ct on cpt.s_type = 'A' and cpt.s_branch_id = ct.s_branch_id and cpt.S_no = ct.type_code 
                                            left join s_charge_code   cc on cpt.s_type = 'B' and cpt.s_branch_id = cc.s_branch_id and cpt.S_no = cc.charge_code 
                                            left join s_consume_item  ci on cpt.s_type = 'C' and cpt.s_branch_id = cp.s_branch_id and cpt.S_no = ci.consume_item_no 
                                    where   1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by cpt.id desc) as row_no,
									        cpt.id, cpt.PolicyCode, cpt.s_type, cpt.S_no, cpt.N_Count, cpt.Amount, cpt.is_active, cpt.memo, 
									        cpt.s_branch_id, cpt.create_date, cpt.create_user, cpt.update_date, cpt.update_user,
                                            s_policy_id = cp.id, s_policy_name = cp.s_describe,
									        item_id = case when cpt.s_type = 'A' then ct.id
													       when cpt.s_type = 'B' then cc.id
													       else ci.id
													       end,
									        item_name = case when cpt.s_type = 'A' then ct.sale_consume_name
														     when cpt.s_type = 'B' then cc.charge_describe
														     else ci.consume_item_name
														     end
                                    from    card_policy_times cpt   
                                            left join card_policy     cp on cpt.s_branch_id  = cp.s_branch_id and cpt.PolicyCode  = cp.s_code
                                            left join s_charge_type   ct on cpt.s_type = 'A' and cpt.s_branch_id = ct.s_branch_id and cpt.S_no = ct.type_code 
                                            left join s_charge_code   cc on cpt.s_type = 'B' and cpt.s_branch_id = cc.s_branch_id and cpt.S_no = cc.charge_code 
                                            left join s_consume_item  ci on cpt.s_type = 'C' and cpt.s_branch_id = cp.s_branch_id and cpt.S_no = ci.consume_item_no 
                                    where   1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                   ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<CardPolicyTimesSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<CardPolicyTimesSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除优惠政策与电子劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveCardPolicyTimesAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = "delete from  card_policy_times  where id=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除优惠政策与电子劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveCardPolicyTimesAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  card_policy_times  where id in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

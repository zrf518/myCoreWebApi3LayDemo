﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 卡务记录中间表接口实现
    /// </summary>
    public class CardMidMsgService : ICardMidMsgInterface
    {
        /// <summary>
        /// 查询卡务记录中间表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<CardMidMsgSearchResultDto>>> QueryCardMidMsgAsync(string sCardDBConn, CardMidMsgSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and cmm.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.auto_id != 0)
            {
                sWhere += " and cmm.auto_id = @auto_id";
                listSqlParam.Add(new SugarParameter("@auto_id", dto.auto_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_card_account))
            {
                sWhere += " and cmm.s_card_account = @s_card_account";
                listSqlParam.Add(new SugarParameter("@s_card_account", dto.s_card_account));
            }
            // 卡号
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_card_no))
            {
                sWhere += " and cmm.s_card_no = @s_card_no";
                listSqlParam.Add(new SugarParameter("@s_card_no", dto.s_card_no));
            }
            if (null != dto && dto.s_member_info_id.HasValue)
            {
                sWhere += " and cmm.s_member_info_id = @s_member_info_id";
                listSqlParam.Add(new SugarParameter("@s_member_info_id", dto.s_member_info_id));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.s_print_no))
            {
                sWhere += " and cmm.s_print_no = @s_print_no";
                listSqlParam.Add(new SugarParameter("@s_print_no", dto.s_print_no));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.member_name))
            {
                sWhere += " and cmm.member_name like '%' + @member_name + '%'";
                listSqlParam.Add(new SugarParameter("@member_name", dto.member_name));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select  iCount = count(*)
                                    from    card_mid_msg cmm   
                                            left join regcard      rc  on cmm.s_branch_id = rc.s_branch_id and cmm.s_card_account = rc.s_card_account
                                            left join member_data  md  on cmm.s_member_info_id = md.ID
                                    where   1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by cmm.auto_id desc) as row_no,
                                            cmm.auto_id, cmm.s_member_info_id, cmm.s_card_account, cmm.s_branch_no, cmm.s_card_no, cmm.s_print_no, cmm.s_account_to, 
                                            cmm.n_blnce, cmm.n_use, cmm.s_use_date, cmm.s_use_time, cmm.s_flag, cmm.s_do_time, cmm.n_times, 
                                            cmm.auto_id_1, cmm.s_back, cmm.s_back_time, cmm.s_sys_date, cmm.Auto_ID_2, cmm.n_send_charge, 
                                            cmm.s_work_no, cmm.pay_type, cmm.n_send_blnce, cmm.n_fen_blnce, cmm.n_fen_use, cmm.S_SET_CLASS, 
                                            cmm.s_sales, cmm.s_code, cmm.s_card_type, cmm.PolicyCode, cmm.paycode, cmm.s_name, cmm.s_branch_id,
											rc.s_card_no, rc.s_print_no,
											md.member_name
                                    from    card_mid_msg cmm   
                                            left join regcard      rc  on cmm.s_branch_id = rc.s_branch_id and cmm.s_card_account = rc.s_card_account
                                            left join member_data  md  on cmm.s_member_info_id = md.ID
                                    where   1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                   ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<CardMidMsgSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<CardMidMsgSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除卡务记录中间表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveCardMidMsgAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = "delete from  card_mid_msg  where auto_id=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除卡务记录中间表
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveCardMidMsgAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  card_mid_msg  where auto_id in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

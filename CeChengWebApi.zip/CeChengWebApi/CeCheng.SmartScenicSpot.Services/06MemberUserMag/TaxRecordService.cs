﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 开票记录接口实现
    /// </summary>
    public class TaxRecordService : ITaxRecordInterface
    {
        /// <summary>
        /// 新增开票记录
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddTaxRecordAsync(string sCardDBConn, TaxRecordDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 执行添加
            var result = await _CardDbProvider.Insertable<TaxRecordEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 查询开票记录
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<TaxRecordSearchResultDto>>> QueryTaxRecordAsync(string sCardDBConn, TaxRecordSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and tr.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and tr.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.s_sys_tax_type_id.HasValue)
            {
                sWhere += " and tr.s_sys_tax_type_id = @s_sys_tax_type_id";
                listSqlParam.Add(new SugarParameter("@s_sys_tax_type_id", dto.s_sys_tax_type_id));
            }
            if (null != dto && dto.create_date_start.HasValue)
            {
                sWhere += " and tr.Create_Date >= @create_date_start";
                listSqlParam.Add(new SugarParameter("@create_date_start", dto.create_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.create_date_end.HasValue)
            {
                sWhere += " and tr.Create_Date <= @create_date_end";
                listSqlParam.Add(new SugarParameter("@create_date_end", dto.create_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_tax_record tr
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by tr.id desc) as row_no,
                                           tr.id, tr.taxno, tr.s_sys_tax_type_id, tr.Operator, tr.amount, tr.tax_date, tr.memo, 
                                           tr.s_branch_id, tr.Create_Date, tr.Create_User, tr.Update_Date, tr.Update_User,
                                           fp_code = stt.code, fp_name = stt.describe
                                    from   s_tax_record tr
                                           left join s_sys_tax_type stt on tr.s_sys_tax_type_id = stt.id
                                    where  1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<TaxRecordSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<TaxRecordSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
    }
}
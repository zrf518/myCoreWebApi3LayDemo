﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 微信会员设置接口实现
    /// </summary>
    public class WxMemberInfoService : IWxMemberInfoInterface
    {
        /// <summary>
        /// 新增微信会员设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddWxMemberInfoAsync(string sCardDBConn, WxMemberInfoDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<WxMemberInfoEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.WeChatOpenId == dto.WeChatOpenId).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await _CardDbProvider.Insertable<WxMemberInfoEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑微信会员设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditWxMemberInfoAsync(string sCardDBConn, WxMemberInfoDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<WxMemberInfoEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.MemberID != dto.MemberID && x.WeChatOpenId == dto.WeChatOpenId).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<WxMemberInfoEntity>().Where(x => x.MemberID == dto.MemberID).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await _CardDbProvider.Updateable<WxMemberInfoEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询微信会员设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<WxMemberInfoSearchResultDto>>> QueryWxMemberInfoAsync(string sCardDBConn, WxMemberInfoSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and wmi.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.MemberID != 0)
            {
                sWhere += " and wmi.MemberID = @MemberID";
                listSqlParam.Add(new SugarParameter("@MemberID", dto.MemberID));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.WeChatOpenId))
            {
                sWhere += " and wmi.WeChatOpenId = @WeChatOpenId";
                listSqlParam.Add(new SugarParameter("@WeChatOpenId", dto.WeChatOpenId));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.WeChatId))
            {
                sWhere += " and wmi.WeChatId = @WeChatId";
                listSqlParam.Add(new SugarParameter("@WeChatId", dto.WeChatId));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.MemberName))
            {
                sWhere += " and wmi.MemberName like '%' + @MemberName + '%'";
                listSqlParam.Add(new SugarParameter("@MemberName", dto.MemberName));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.IDName))
            {
                sWhere += " and wmi.IDName like '%' + @IDName + '%'";
                listSqlParam.Add(new SugarParameter("@IDName", dto.IDName));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.TelNumber))
            {
                sWhere += " and wmi.TelNumber like '%' + @TelNumber + '%'";
                listSqlParam.Add(new SugarParameter("@TelNumber", dto.TelNumber));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_address))
            {
                sWhere += " and wmi.s_address like '%' + @s_address + '%'";
                listSqlParam.Add(new SugarParameter("@s_address", dto.s_address));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.Gender))
            {
                sWhere += " and wmi.Gender = @Gender";
                listSqlParam.Add(new SugarParameter("@Gender", dto.Gender));
            }
            if (null != dto && dto.RegisterTimeStart.HasValue)
            {
                sWhere += " and wmi.RegisterTime >= @RegisterTimeStart";
                listSqlParam.Add(new SugarParameter("@RegisterTimeStart", dto.RegisterTimeStart.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.RegisterTimeEnd.HasValue)
            {
                sWhere += " and wmi.RegisterTime <= @RegisterTimeEnd";
                listSqlParam.Add(new SugarParameter("@RegisterTimeEnd", dto.RegisterTimeEnd.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.IDNumber))
            {
                sWhere += " and wmi.IDNumber = @IDNumber";
                listSqlParam.Add(new SugarParameter("@IDNumber", dto.IDNumber));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   memberinfo wmi
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by wmi.MemberID desc) as row_no,
                                           wmi.MemberID, wmi.MemberName, wmi.[Password], wmi.IDNumber, wmi.Gender, wmi.Birthday, 
                                           wmi.TelNumber, wmi.RegisterTime, wmi.WeChatId, wmi.WeChatOpenId, wmi.Remark, wmi.TJ_Code, 
                                           wmi.Use_TJ_code, wmi.s_address, wmi.branch_connect, wmi.Points, wmi.PointsBalance, 
                                           wmi.workno, wmi.LogoUrl, wmi.lcsw_OpenID, wmi.s_branch_no, wmi.RefereeOpenID, wmi.IDName, 
                                           wmi.keychange_date, wmi.keychange_times, wmi.LastUpdateTime, wmi.s_branch_id
                                    from   memberinfo wmi
                                    where  1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<WxMemberInfoSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<WxMemberInfoSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除微信会员设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveWxMemberInfoAsync(string sCardDBConn, string sUserWorkNo, int MemberID)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = "delete from  memberinfo  where MemberID=" + MemberID;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除微信会员设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveWxMemberInfoAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  memberinfo  where MemberID in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}
﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 优惠政策接口实现
    /// </summary>
    public class CardPolicyService : ICardPolicyInterface
    {
        /// <summary>
        /// 新增优惠政策
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddCardPolicyAsync(string sCardDBConn, CardPolicyDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<CardPolicyEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.s_code == dto.s_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await _CardDbProvider.Insertable<CardPolicyEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑优惠政策
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditCardPolicyAsync(string sCardDBConn, CardPolicyDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<CardPolicyEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.s_code == dto.s_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<CardPolicyEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await _CardDbProvider.Updateable<CardPolicyEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询优惠政策
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<CardPolicySearchResultDto>>> QueryCardPolicyAsync(string sCardDBConn, CardPolicySearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and cp.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and cp.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_code))
            {
                sWhere += " and cp.s_code = @s_code";
                listSqlParam.Add(new SugarParameter("@s_code", dto.s_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_describe))
            {
                sWhere += " and cp.s_describe like '%' + @s_describe + '%'";
                listSqlParam.Add(new SugarParameter("@s_describe", dto.s_describe));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.cardtype))
            {
                sWhere += " and cp.cardtype = @cardtype";
                listSqlParam.Add(new SugarParameter("@cardtype", dto.cardtype));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_policyspec))
            {
                sWhere += " and cp.s_policyspec = @s_policyspec";
                listSqlParam.Add(new SugarParameter("@s_policyspec", dto.s_policyspec));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.RateCode))
            {
                sWhere += " and cp.RateCode = @RateCode";
                listSqlParam.Add(new SugarParameter("@RateCode", dto.RateCode));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_free_tax))
            {
                sWhere += " and cp.s_free_tax = @s_free_tax";
                listSqlParam.Add(new SugarParameter("@s_free_tax", dto.s_free_tax));
            }
            // 卡类型关联查询
            if (null != dto && dto.card_type_id.HasValue)
            {
                sWhere += " and ct.id = @card_type_id";
                listSqlParam.Add(new SugarParameter("@card_type_id", dto.card_type_id));
            }            if (null != dto && !string.IsNullOrWhiteSpace(dto.card_type_name))
            {
                sWhere += " and ct.s_describe like '%' + @card_type_name + '%'";
                listSqlParam.Add(new SugarParameter("@card_type_name", dto.card_type_name));
            }
            // 折扣代码关联查询
            if (null != dto && dto.cardpolicy_specm_id.HasValue)
            {
                sWhere += " and cps.id = @cardpolicy_specm_id";
                listSqlParam.Add(new SugarParameter("@cardpolicy_specm_id", dto.cardpolicy_specm_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.cardpolicy_specm_name))
            {
                sWhere += " and cps.s_desc like '%' + @cardpolicy_specm_name + '%'";
                listSqlParam.Add(new SugarParameter("@cardpolicy_specm_name", dto.cardpolicy_specm_name));
            }
            // 房价代码关联查询
            if (null != dto && dto.sm_ratecode_id.HasValue)
            {
                sWhere += " and src.id = @sm_ratecode_id";
                listSqlParam.Add(new SugarParameter("@sm_ratecode_id", dto.sm_ratecode_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sm_ratecode_name))
            {
                sWhere += " and src.[Description] like '%' + @sm_ratecode_name + '%'";
                listSqlParam.Add(new SugarParameter("@sm_ratecode_name", dto.sm_ratecode_name));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.IsActive))
            {
                sWhere += " and cp.IsActive = @IsActive";
                listSqlParam.Add(new SugarParameter("@IsActive", dto.IsActive));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select  iCount = count(*)
                                    from    card_policy cp
                                            left join card_type             ct   on cp.cardtype = ct.s_code      and cp.s_branch_id = ct.s_branch_id
                                            left join cardpolicy_specm      cps  on cp.s_policyspec = cps.s_no   and cp.s_branch_id = cps.s_branch_id
                                            left join SM_RateCode           src  on cp.RateCode = src.RateCode   and cp.s_branch_id = src.s_branch_id
                                            left join s_sys_dictionary_info sdi  on cp.s_free_tax = sdi.diclabel and sdi.dictype=1008
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by cp.id desc) as row_no,
                                            cp.id, cp.cardtype, cp.s_code, cp.s_describe, cp.n_charge, cp.n_pay, cp.n_chg_unit, cp.n_snd_unit, 
                                            cp.s_card_end, cp.n_month_add, cp.n_din_disc, cp.s_policyspec, cp.RateCode, cp.n_miss_add, 
                                            cp.s_Free_sauna, cp.n_free_sauna, cp.s_insider, cp.s_free_tax, cp.IsActive, cp.n_daytimes, 
                                            cp.s_isself, cp.n_free_zzc, cp.isfixadd, cp.n_sauna_disc, cp.n_room_disc, cp.n_dance_disc, 
                                            cp.n_chess_disc, cp.s_CardDescribes, cp.typecode, cp.memo, cp.S_Branch_Id, cp.Create_Date, 
                                            cp.Create_User, cp.Update_Date, cp.Update_User,
                                            card_type_id=ct.id, card_type_name=ct.s_describe,
                                            cardpolicy_specm_id=cps.id, cardpolicy_specm_name=cps.s_desc,
                                            sm_ratecode_id=src.id, sm_ratecode_name=src.[Description],
                                            s_free_tax_name=sdi.dicname
                                    from    card_policy cp
                                            left join card_type             ct   on cp.cardtype = ct.s_code      and cp.s_branch_id = ct.s_branch_id
                                            left join cardpolicy_specm      cps  on cp.s_policyspec = cps.s_no   and cp.s_branch_id = cps.s_branch_id
                                            left join SM_RateCode           src  on cp.RateCode = src.RateCode   and cp.s_branch_id = src.s_branch_id
                                            left join s_sys_dictionary_info sdi  on cp.s_free_tax = sdi.diclabel and sdi.dictype=1008
                                    where   1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<CardPolicySearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<CardPolicySearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }

        /// <summary>
        /// 删除优惠政策
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveCardPolicyAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = "delete from  card_policy  where id=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 批量删除优惠政策
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveCardPolicyAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  card_policy  where id in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}
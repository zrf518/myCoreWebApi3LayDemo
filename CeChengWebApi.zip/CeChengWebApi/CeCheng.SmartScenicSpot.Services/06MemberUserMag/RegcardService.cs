﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using CeCheng.SmartScenicSpot.Models.Entitys;
using NPOI.OpenXmlFormats.Dml.Chart;
using NPOI.OpenXmlFormats.Spreadsheet;
using NPOI.SS.Formula.Functions;
using Org.BouncyCastle.Ocsp;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.Utilities.Collections;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 会员卡设置接口实现
    /// </summary>
    public class RegcardService : IRegcardInterface
    {
        /// <summary>
        /// 新增会员卡设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddRegcardAsync(string sCardDBConn, RegcardCreateDto dto)
        {
            if (string.IsNullOrEmpty(dto.regcardDto.s_account_no) || string.IsNullOrEmpty(dto.regcardDto.s_card_no) || string.IsNullOrEmpty(dto.regcardDto.s_print_no))
            {
                return ApiResultDto.ToResultFail(data: false, msg: "会员卡账号、物理卡号、印刷卡号不能为空");
            }

            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<RegcardEntity>()
                .Where(x => (!string.IsNullOrEmpty(dto.regcardDto.s_account_no) && x.s_account_no == dto.regcardDto.s_account_no)
                            || 
                            (
                                 x.s_branch_id == dto.regcardDto.s_branch_id
                                 && (
                                        (!string.IsNullOrEmpty(dto.regcardDto.s_card_no) && x.s_card_no == dto.regcardDto.s_card_no)
                                     || (!string.IsNullOrEmpty(dto.regcardDto.s_print_no) && x.s_print_no == dto.regcardDto.s_print_no)
                                    )
                            )
                       )
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "账号、卡号、印刷卡号重复");
            }

            _CardDbProvider.BeginTran();
            try
            {
                string s_branch_no = "";
                var resQryBranch = await _CardDbProvider.Queryable<BranchEntity>().Where(x => x.id == dto.regcardDto.s_branch_id).ToListAsync();
                if (null == resQryBranch || 0 == resQryBranch.Count)
                {
                    throw new Exception("分店ID不存在");
                }
                s_branch_no = resQryBranch[0].branch_no;

                // 查会员人员资料
                var resQryMember = await _CardDbProvider.Queryable<MemberInfoEntity>().Where(x => x.id == dto.regcardDto.s_member_info_id).SingleAsync();
                string s_name = "";
                if (null != resQryMember)
                    s_name = resQryMember.member_name;

                // 处理会员卡密码：要是密码为空，就设置成888，然后再转换
                if (string.IsNullOrEmpty(dto.regcardDto.s_sec_code))
                    dto.regcardDto.s_sec_code = "888";
                dto.regcardDto.s_sec_code = EncryptCardPwd(dto.regcardDto.s_sec_code);

                // 初始化卡余额等一些默认的基本数据
                dto.regcardDto.s_use_flag = "Y";
                dto.regcardDto.n_card_tot = 0;
                dto.regcardDto.n_use_tot = 0;
                dto.regcardDto.n_blnce = 0;
                dto.regcardDto.n_send_tot = 0;
                dto.regcardDto.s_stat = "U";
                dto.regcardDto.s_forbin = "N";
                dto.regcardDto.s_out = "N";
                dto.regcardDto.s_branch_no = s_branch_no;

                // 插入新卡数据
                var result = await _CardDbProvider.Insertable<RegcardEntity>(dto.regcardDto).ExecuteReturnEntityAsync();
                if (null == result || result.idno < 1)
                    throw new Exception("会员卡数据保存异常");

                decimal n_blnce_tot = 0;
                decimal n_use_tot = 0;
                decimal n_send_blnce_tot = 0;
                decimal n_fen_blnce_tot = 0;

                var resQryCardPolicy = await _CardDbProvider.Queryable<CardPolicyEntity>()
                    .Where(x => x.IsActive == "Y" && x.s_branch_id == dto.regcardDto.s_branch_id && x.s_code == dto.regcardDto.PolicyCode)
                    .ToListAsync();
                if (null == resQryCardPolicy || resQryCardPolicy.Count < 1)
                    throw new Exception("会员卡优惠政策信息不存在");

                if (false == dto.regcardDto.n_pay.HasValue 
                    || (resQryCardPolicy[0].n_pay.HasValue && resQryCardPolicy[0].n_pay.Value != 0 && dto.regcardDto.n_pay != resQryCardPolicy[0].n_pay)
                    )
                    throw new Exception("卡付款金额不等于销售");

                // 销售金额不为0的，就插入卡务数据记录
                decimal nPayMoneyTot = 0;
                if (null != dto.listPayMoneysDto && 0 < dto.listPayMoneysDto.Count)
                {
                    for (int i = 0; i < dto.listPayMoneysDto.Count; i++)
                    {
                        #region 插入卡务中间表数据记录
                        CardMidMsgDto dtoCardMidMsg = new CardMidMsgDto();
                        dtoCardMidMsg.s_member_info_id = dto.regcardDto.s_member_info_id;
                        dtoCardMidMsg.s_card_account = dto.regcardDto.s_account_no;
                        dtoCardMidMsg.s_branch_no = dto.regcardDto.s_branch_no;
                        dtoCardMidMsg.s_card_no = dto.regcardDto.s_card_no;
                        dtoCardMidMsg.s_print_no = dto.regcardDto.s_print_no;
                        dtoCardMidMsg.s_account_to = "充值";
                        dtoCardMidMsg.n_blnce = n_blnce_tot;
                        dtoCardMidMsg.n_use = n_use_tot;
                        dtoCardMidMsg.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                        dtoCardMidMsg.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                        dtoCardMidMsg.s_flag = "Y";
                        dtoCardMidMsg.s_do_time = DateTime.Now;
                        dtoCardMidMsg.n_times = 1;
                        dtoCardMidMsg.auto_id_1 = 0;
                        dtoCardMidMsg.s_back = "Y";
                        dtoCardMidMsg.s_back_time = DateTime.Now;
                        dtoCardMidMsg.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                        dtoCardMidMsg.Auto_ID_2 = 0;
                        dtoCardMidMsg.n_send_charge = 0;
                        dtoCardMidMsg.s_work_no = dto.regcardDto.s_set_work;
                        dtoCardMidMsg.pay_type = "A"; // 办卡
                        dtoCardMidMsg.n_send_blnce = n_send_blnce_tot;
                        dtoCardMidMsg.n_fen_blnce = n_fen_blnce_tot;
                        dtoCardMidMsg.n_fen_use = 0;
                        dtoCardMidMsg.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                        dtoCardMidMsg.s_sales = dto.regcardDto.s_sale;
                        dtoCardMidMsg.s_code = dto.regcardDto.s_code;
                        dtoCardMidMsg.s_card_type = dto.regcardDto.s_card_type;
                        dtoCardMidMsg.PolicyCode = dto.regcardDto.PolicyCode;
                        dtoCardMidMsg.paycode = dto.listPayMoneysDto[i].s_PayCode;
                        dtoCardMidMsg.s_name = s_name;
                        dtoCardMidMsg.s_branch_id = dto.regcardDto.s_branch_id;

                        // 数据插入数据库表
                        var resuAddCMM = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsg).ExecuteReturnEntityAsync();
                        if (null == resuAddCMM || resuAddCMM.auto_id < 1)
                            throw new Exception("卡务中间表数据保存异常");

                        // 更新Auto_ID_2的值
                        resuAddCMM.Auto_ID_2 = resuAddCMM.auto_id;
                        var resultUpdateCMM = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMM).ExecuteCommandAsync();
                        if (resultUpdateCMM < 1)
                            throw new Exception("卡务中间表数据更新ID异常");
                        #endregion

                        #region 插入卡务数据记录
                        // 查看付款方式名称
                        string s_PayCodeName = "";
                        if (!string.IsNullOrEmpty(dto.listPayMoneysDto[i].s_PayCode))
                        {
                            var resQryPayCode = await _CardDbProvider.Queryable<PayCodeEntity>()
                                .Where(x => x.s_branch_id == dto.regcardDto.s_branch_id && x.pay_code == dto.listPayMoneysDto[i].s_PayCode)
                                .ToListAsync();
                            if (null == resQryPayCode || 0 == resQryPayCode.Count)
                            {
                                throw new Exception("付款编码不存在");
                            }
                            s_PayCodeName = resQryPayCode[0].describe;
                        }

                        CardAccountDto dtoCardAccount = new CardAccountDto();
                        dtoCardAccount.s_member_data_id = dto.regcardDto.s_member_info_id;
                        dtoCardAccount.s_account_no = dto.regcardDto.s_account_no;
                        dtoCardAccount.s_serial_no = 1;
                        dtoCardAccount.s_cardno = dto.regcardDto.s_print_no;
                        dtoCardAccount.s_dep_name = s_PayCodeName;
                        dtoCardAccount.s_account_to = "";
                        dtoCardAccount.n_capital = dto.listPayMoneysDto[i].n_PayMoney;
                        dtoCardAccount.n_caprmb = dto.listPayMoneysDto[i].n_PayMoney;
                        dtoCardAccount.n_charge = 0;
                        dtoCardAccount.n_chg_tot = 0;
                        dtoCardAccount.n_fen_charge = 0;
                        dtoCardAccount.n_fen_send = 0;
                        dtoCardAccount.n_fen_use = 0;
                        dtoCardAccount.n_hour_cnt = 0;
                        dtoCardAccount.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                        dtoCardAccount.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                        dtoCardAccount.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                        dtoCardAccount.s_set_class = dto.loginBusinessDataDto.s_set_class;
                        dtoCardAccount.s_set_work = dto.regcardDto.s_set_work;
                        dtoCardAccount.s_emp = dto.regcardDto.s_set_work;
                        dtoCardAccount.s_meno = dto.regcardDto.s_memo;
                        dtoCardAccount.s_del = null;
                        dtoCardAccount.s_type = null;
                        dtoCardAccount.n_send_cnt = 0;
                        dtoCardAccount.s_sale = dto.regcardDto.s_sale;
                        dtoCardAccount.s_tax = "N";
                        dtoCardAccount.s_change = "";
                        dtoCardAccount.s_old_card = null;
                        dtoCardAccount.member_id = null;
                        dtoCardAccount.s_department = "";
                        dtoCardAccount.n_nowblnce = n_blnce_tot;
                        dtoCardAccount.n_send_charge = 0;
                        dtoCardAccount.n_add_cnt = 0;
                        dtoCardAccount.s_branch_happen = dto.regcardDto.s_branch_no;
                        dtoCardAccount.card_mid_id = resuAddCMM.auto_id;
                        dtoCardAccount.send_to_hq = "N";
                        dtoCardAccount.n_send1_charge = null;
                        dtoCardAccount.n_send_room_charge = null;
                        dtoCardAccount.s_qrcode = null;
                        dtoCardAccount.pay_type = "P";
                        dtoCardAccount.add_type = "V";
                        dtoCardAccount.paycode = dto.listPayMoneysDto[i].s_PayCode;
                        dtoCardAccount.QRcode = null;
                        dtoCardAccount.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                        dtoCardAccount.s_branch_id = dto.regcardDto.s_branch_id;

                        // 数据插入数据库表
                        var resuAddCA = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccount).ExecuteCommandAsync();
                        if (resuAddCA < 1)
                            throw new Exception("卡务数据保存异常");

                        #endregion

                        n_blnce_tot += dto.listPayMoneysDto[i].n_PayMoney;
                        n_use_tot += 0;
                        n_send_blnce_tot += 0;
                        n_fen_blnce_tot += 0;
                        nPayMoneyTot += dto.listPayMoneysDto[i].n_PayMoney;
                    }
                }
                if (dto.regcardDto.n_pay.Value != nPayMoneyTot)
                    throw new Exception("实际付款金额不等于销售金额");

                // 要是付款金额大于卡储金额，多出来的部分，就当成年费处理
                decimal n_YearMoney = 0;
                if (dto.regcardDto.n_pay > resQryCardPolicy[0].n_charge)
                {
                    n_YearMoney = dto.regcardDto.n_pay.Value - resQryCardPolicy[0].n_charge.Value;

                    #region 插入卡务中间表数据记录
                    CardMidMsgDto dtoCardMidMsg = new CardMidMsgDto();
                    dtoCardMidMsg.s_member_info_id = dto.regcardDto.s_member_info_id;
                    dtoCardMidMsg.s_card_account = dto.regcardDto.s_account_no;
                    dtoCardMidMsg.s_branch_no = dto.regcardDto.s_branch_no;
                    dtoCardMidMsg.s_card_no = dto.regcardDto.s_card_no;
                    dtoCardMidMsg.s_print_no = dto.regcardDto.s_print_no;
                    dtoCardMidMsg.s_account_to = "";
                    dtoCardMidMsg.n_blnce = n_blnce_tot;
                    dtoCardMidMsg.n_use = n_use_tot;
                    dtoCardMidMsg.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                    dtoCardMidMsg.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                    dtoCardMidMsg.s_flag = "Y";
                    dtoCardMidMsg.s_do_time = DateTime.Now;
                    dtoCardMidMsg.n_times = 1;
                    dtoCardMidMsg.auto_id_1 = 0;
                    dtoCardMidMsg.s_back = "Y";
                    dtoCardMidMsg.s_back_time = DateTime.Now;
                    dtoCardMidMsg.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoCardMidMsg.Auto_ID_2 = 0;
                    dtoCardMidMsg.n_send_charge = 0;
                    dtoCardMidMsg.s_work_no = dto.regcardDto.s_set_work;
                    dtoCardMidMsg.pay_type = "A"; // 办卡
                    dtoCardMidMsg.n_send_blnce = n_send_blnce_tot;
                    dtoCardMidMsg.n_fen_blnce = n_fen_blnce_tot;
                    dtoCardMidMsg.n_fen_use = 0;
                    dtoCardMidMsg.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                    dtoCardMidMsg.s_sales = dto.regcardDto.s_sale;
                    dtoCardMidMsg.s_code = dto.regcardDto.s_code;
                    dtoCardMidMsg.s_card_type = dto.regcardDto.s_card_type;
                    dtoCardMidMsg.PolicyCode = dto.regcardDto.PolicyCode;
                    dtoCardMidMsg.paycode = "";
                    dtoCardMidMsg.s_name = s_name;
                    dtoCardMidMsg.s_branch_id = dto.regcardDto.s_branch_id;

                    // 数据插入数据库表
                    var resuAddCMM = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsg).ExecuteReturnEntityAsync();
                    if (null == resuAddCMM || resuAddCMM.auto_id < 1)
                        throw new Exception("卡务中间表数据保存异常");

                    // 更新Auto_ID_2的值
                    resuAddCMM.Auto_ID_2 = resuAddCMM.auto_id;
                    var resultUpdateCMM = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMM).ExecuteCommandAsync();
                    if (resultUpdateCMM < 1)
                        throw new Exception("卡务中间表数据更新ID异常");
                    #endregion

                    #region 插入卡务数据记录
                    CardAccountDto dtoCardAccount = new CardAccountDto();
                    dtoCardAccount.s_member_data_id = dto.regcardDto.s_member_info_id;
                    dtoCardAccount.s_account_no = dto.regcardDto.s_account_no;
                    dtoCardAccount.s_serial_no = 1;
                    dtoCardAccount.s_cardno = dto.regcardDto.s_print_no;
                    dtoCardAccount.s_dep_name = "年费";
                    dtoCardAccount.s_account_to = "";
                    dtoCardAccount.n_capital = 0;
                    dtoCardAccount.n_caprmb = 0;
                    dtoCardAccount.n_charge = n_YearMoney;
                    dtoCardAccount.n_chg_tot = 0;
                    dtoCardAccount.n_fen_charge = 0;
                    dtoCardAccount.n_fen_send = 0;
                    dtoCardAccount.n_fen_use = 0;
                    dtoCardAccount.n_hour_cnt = 0;
                    dtoCardAccount.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoCardAccount.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                    dtoCardAccount.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                    dtoCardAccount.s_set_class = dto.loginBusinessDataDto.s_set_class;
                    dtoCardAccount.s_set_work = dto.regcardDto.s_set_work;
                    dtoCardAccount.s_emp = dto.regcardDto.s_set_work;
                    dtoCardAccount.s_meno = dto.regcardDto.s_memo;
                    dtoCardAccount.s_del = null;
                    dtoCardAccount.s_type = null;
                    dtoCardAccount.n_send_cnt = 0;
                    dtoCardAccount.s_sale = dto.regcardDto.s_sale;
                    dtoCardAccount.s_tax = "N";
                    dtoCardAccount.s_change = "";
                    dtoCardAccount.s_old_card = null;
                    dtoCardAccount.member_id = null;
                    dtoCardAccount.s_department = "";
                    dtoCardAccount.n_nowblnce = n_blnce_tot;
                    dtoCardAccount.n_send_charge = 0;
                    dtoCardAccount.n_add_cnt = 0;
                    dtoCardAccount.s_branch_happen = dto.regcardDto.s_branch_no;
                    dtoCardAccount.card_mid_id = resuAddCMM.auto_id;
                    dtoCardAccount.send_to_hq = "N";
                    dtoCardAccount.n_send1_charge = null;
                    dtoCardAccount.n_send_room_charge = null;
                    dtoCardAccount.s_qrcode = null;
                    dtoCardAccount.pay_type = "P";
                    dtoCardAccount.add_type = "V";
                    dtoCardAccount.paycode = "";
                    dtoCardAccount.QRcode = null;
                    dtoCardAccount.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                    dtoCardAccount.s_branch_id = dto.regcardDto.s_branch_id;

                    // 数据插入数据库表
                    var resuAddCA = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccount).ExecuteCommandAsync();
                    if (resuAddCA < 1)
                        throw new Exception("卡务数据保存异常");

                    #endregion

                    n_blnce_tot -= n_YearMoney;
                    n_use_tot += 0;
                    n_send_blnce_tot += 0;
                    n_fen_blnce_tot += 0;
                }
                // 要是付款金额小于卡储金额，就是有赠送，设置赠送金额
                decimal n_SendMoney = 0;
                if (dto.regcardDto.n_pay < dto.regcardDto.n_charge.Value)
                {
                    n_SendMoney = dto.regcardDto.n_charge.Value - dto.regcardDto.n_pay.Value;

                    #region 插入卡务中间表数据记录
                    CardMidMsgDto dtoCardMidMsg = new CardMidMsgDto();
                    dtoCardMidMsg.s_member_info_id = dto.regcardDto.s_member_info_id;
                    dtoCardMidMsg.s_card_account = dto.regcardDto.s_account_no;
                    dtoCardMidMsg.s_branch_no = dto.regcardDto.s_branch_no;
                    dtoCardMidMsg.s_card_no = dto.regcardDto.s_card_no;
                    dtoCardMidMsg.s_print_no = dto.regcardDto.s_print_no;
                    dtoCardMidMsg.s_account_to = "充值";
                    dtoCardMidMsg.n_blnce = n_blnce_tot;
                    dtoCardMidMsg.n_use = n_use_tot;
                    dtoCardMidMsg.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                    dtoCardMidMsg.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                    dtoCardMidMsg.s_flag = "Y";
                    dtoCardMidMsg.s_do_time = DateTime.Now;
                    dtoCardMidMsg.n_times = 1;
                    dtoCardMidMsg.auto_id_1 = 0;
                    dtoCardMidMsg.s_back = "Y";
                    dtoCardMidMsg.s_back_time = DateTime.Now;
                    dtoCardMidMsg.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoCardMidMsg.Auto_ID_2 = 0;
                    dtoCardMidMsg.n_send_charge = 0;
                    dtoCardMidMsg.s_work_no = dto.regcardDto.s_set_work;
                    dtoCardMidMsg.pay_type = "A"; // 办卡
                    dtoCardMidMsg.n_send_blnce = n_send_blnce_tot;
                    dtoCardMidMsg.n_fen_blnce = n_fen_blnce_tot;
                    dtoCardMidMsg.n_fen_use = 0;
                    dtoCardMidMsg.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                    dtoCardMidMsg.s_sales = dto.regcardDto.s_sale;
                    dtoCardMidMsg.s_code = dto.regcardDto.s_code;
                    dtoCardMidMsg.s_card_type = dto.regcardDto.s_card_type;
                    dtoCardMidMsg.PolicyCode = dto.regcardDto.PolicyCode;
                    dtoCardMidMsg.paycode = "";
                    dtoCardMidMsg.s_name = s_name;
                    dtoCardMidMsg.s_branch_id = dto.regcardDto.s_branch_id;

                    // 数据插入数据库表
                    var resuAddCMM = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsg).ExecuteReturnEntityAsync();
                    if (null == resuAddCMM || resuAddCMM.auto_id < 1)
                        throw new Exception("卡务中间表数据保存异常");

                    // 更新Auto_ID_2的值
                    resuAddCMM.Auto_ID_2 = resuAddCMM.auto_id;
                    var resultUpdateCMM = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMM).ExecuteCommandAsync();
                    if (resultUpdateCMM < 1)
                        throw new Exception("卡务中间表数据更新ID异常");
                    #endregion

                    #region 插入卡务数据记录
                    CardAccountDto dtoCardAccount = new CardAccountDto();
                    dtoCardAccount.s_member_data_id = dto.regcardDto.s_member_info_id;
                    dtoCardAccount.s_account_no = dto.regcardDto.s_account_no;
                    dtoCardAccount.s_serial_no = 1;
                    dtoCardAccount.s_cardno = dto.regcardDto.s_print_no;
                    dtoCardAccount.s_dep_name = "赠送";
                    dtoCardAccount.s_account_to = "";
                    dtoCardAccount.n_capital = n_SendMoney;
                    dtoCardAccount.n_caprmb = n_SendMoney;
                    dtoCardAccount.n_charge = 0;
                    dtoCardAccount.n_chg_tot = 0;
                    dtoCardAccount.n_fen_charge = 0;
                    dtoCardAccount.n_fen_send = 0;
                    dtoCardAccount.n_fen_use = 0;
                    dtoCardAccount.n_hour_cnt = 0;
                    dtoCardAccount.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoCardAccount.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                    dtoCardAccount.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                    dtoCardAccount.s_set_class = dto.loginBusinessDataDto.s_set_class;
                    dtoCardAccount.s_set_work = dto.regcardDto.s_set_work;
                    dtoCardAccount.s_emp = dto.regcardDto.s_set_work;
                    dtoCardAccount.s_meno = dto.regcardDto.s_memo;
                    dtoCardAccount.s_del = null;
                    dtoCardAccount.s_type = null;
                    dtoCardAccount.n_send_cnt = 0;
                    dtoCardAccount.s_sale = dto.regcardDto.s_sale;
                    dtoCardAccount.s_tax = "N";
                    dtoCardAccount.s_change = "";
                    dtoCardAccount.s_old_card = null;
                    dtoCardAccount.member_id = null;
                    dtoCardAccount.s_department = "";
                    dtoCardAccount.n_nowblnce = n_blnce_tot;
                    dtoCardAccount.n_send_charge = 0;
                    dtoCardAccount.n_add_cnt = 0;
                    dtoCardAccount.s_branch_happen = dto.regcardDto.s_branch_no;
                    dtoCardAccount.card_mid_id = resuAddCMM.auto_id;
                    dtoCardAccount.send_to_hq = "N";
                    dtoCardAccount.n_send1_charge = null;
                    dtoCardAccount.n_send_room_charge = null;
                    dtoCardAccount.s_qrcode = null;
                    dtoCardAccount.pay_type = "P";
                    dtoCardAccount.add_type = "V";
                    dtoCardAccount.paycode = "";
                    dtoCardAccount.QRcode = null;
                    dtoCardAccount.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                    dtoCardAccount.s_branch_id = dto.regcardDto.s_branch_id;

                    // 数据插入数据库表
                    var resuAddCA = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccount).ExecuteCommandAsync();
                    if (resuAddCA < 1)
                        throw new Exception("卡务数据保存异常");

                    #endregion

                    n_blnce_tot += n_SendMoney;
                    n_use_tot += 0;
                    n_send_blnce_tot += 0;
                    n_fen_blnce_tot += 0;
                }

                // 按优惠政策送票
                var resQryPolicyTicket = await _CardDbProvider.Queryable<CardPolicyTicketEntity>()
                    .Where(x => x.IsActive == "Y" && x.s_branch_id == dto.regcardDto.s_branch_id && x.PolicyCode == dto.regcardDto.PolicyCode)
                    .ToListAsync();
                if (null != resQryPolicyTicket && 0 < resQryPolicyTicket.Count && dto.regcardDto.n_pay >= resQryCardPolicy[0].n_pay)
                {
                    // 获取单号
                    string sBillNo = await CeChengBusinessFunctionHelper.GetSysNextNo(NextNumberIdentityEnum.ticket_sell_no);
                    for (int i=0; i < resQryPolicyTicket.Count; i++)
                    {
                        //// 按优惠政策送票
                        //var resQryTicket = await _CardDbProvider.Queryable<TicketSetEntity>()
                        //    .Where(x => x.is_active == "Y" && x.s_branch_id == dto.regcardDto.s_branch_id && x.ticket_code == resQryPolicyTicket[i].TypeCode)
                        //    .ToListAsync();
                        //if (null == resQryTicket || resQryTicket.Count < 1)
                        //{
                        //    continue;
                        //}
                        //// 保存门票销售单据表数据（赠送的当成一条销售数据保存，对应s_ticket_sell表）
                        //STicketSellAddDto dtoSTicketSellAdd = new STicketSellAddDto();
                        //dtoSTicketSellAdd.sell_no = sBillNo;
                        //dtoSTicketSellAdd.wechat_Id = dto.regcardDto.WeChatId;
                        //dtoSTicketSellAdd.regcard_id = result.idno;
                        //dtoSTicketSellAdd.pay_type = "3"; // 赠送

                        //var resultSaveTicketBill = await _CardDbProvider.Insertable<STitcketSellEntity>(dtoSTicketSellAdd).ExecuteReturnEntityAsync();
                        //if (null == resultSaveTicketBill || resultSaveTicketBill.id < 1)
                        //    throw new Exception("门票销售主表数据保存异常");

                        //// 保存销售的门票项目列表数据（每种票当成一条数据保存，对应s_ticket_sell_record表）
                        //STicketSellRecordEntity dtoTicketSellRecord = new STicketSellRecordEntity();
                        //dtoTicketSellRecord.s_titcket_sell_id = resultSaveTicketBill.id;
                        //dtoTicketSellRecord.ticket_code = resQryTicket[0].ticket_code;
                        //dtoTicketSellRecord.amount = resQryPolicyTicket[i].N_Count;
                        //dtoTicketSellRecord.price = resQryTicket[0].price;
                        //dtoTicketSellRecord.s_branch_id = dto.regcardDto.s_branch_id.Value;
                        //// 票的有效期(取卡有效期、计算出来的有效期、票的可使用结束日期中最小的那个)
                        //DateTime dateTicketValid = dto.regcardDto.s_forbin_date.Value;
                        //if (resQryTicket[0].validate_day.HasValue)
                        //{
                        //    dateTicketValid = DateTime.Now.AddDays(resQryTicket[0].validate_day.Value);
                        //}
                        //if (resQryTicket[0].use_end_date.HasValue 
                        //    && resQryTicket[0].use_end_date.Value.ToString("yyyy-MM-dd HH:mm:ss").CompareTo(dateTicketValid.ToString("yyyy-MM-dd HH:mm:ss")) < 0)
                        //{
                        //    dateTicketValid = resQryTicket[0].use_end_date.Value;
                        //}
                        //dtoTicketSellRecord.valid_date = dateTicketValid;

                        //var resultSaveTicketReord = await _CardDbProvider.Insertable<STicketSellRecordEntity>(dtoTicketSellRecord).ExecuteReturnEntityAsync();
                        //if (null == resultSaveTicketReord || resultSaveTicketReord.id < 1)
                        //    throw new Exception("门票销售记录表数据保存异常");

                        //// 更新s_ticket_sell表的状态，使生成对应明细票数据到s_ticket_sell_record_detail
                        //resultSaveTicketBill.status = "Y";
                        //var resultSaveTicketBill2 = await _CardDbProvider.Updateable<STitcketSellEntity>(resultSaveTicketBill).ExecuteCommandAsync();
                        //if (resultSaveTicketBill2 < 1)
                        //    throw new Exception("门票销售主表数据更新异常");

                    }
                }

                #region 生成短信记录
                if (!string.IsNullOrEmpty(dto.regcardDto.remind_add) && "Y" == dto.regcardDto.remind_add.Trim().ToUpper()
                    && null != resQryMember
                    && !string.IsNullOrEmpty(resQryMember.telephone)
                    && resQryMember.telephone.Length > 10)
                {
                    string sMoHuPrintNo = dto.regcardDto.s_print_no;
                    if (sMoHuPrintNo.Length > 4)
                    {
                        sMoHuPrintNo = sMoHuPrintNo.Substring(sMoHuPrintNo.Length - 4, 4);
                    }
                    string sDate = DateTime.Now.ToString("yyyy-MM-dd");
                    GsmSendMobileDto dtoGsmSendMobile = new GsmSendMobileDto();
                    dtoGsmSendMobile.create_date = DateTime.Now;
                    dtoGsmSendMobile.d_hotel_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoGsmSendMobile.n_cnt = 0;
                    dtoGsmSendMobile.s_flag = "N";
                    dtoGsmSendMobile.s_send_flag = "N";
                    dtoGsmSendMobile.s_branch_id = dto.regcardDto.s_branch_id;
                    dtoGsmSendMobile.s_mobile = resQryMember.telephone;
                    dtoGsmSendMobile.s_message = "尊敬的客户，您好，您的会员卡***" + sMoHuPrintNo + "于" + sDate + "充值：" + dto.regcardDto.n_pay + "元，余额为：" + dto.regcardDto.n_charge + "元。";

                    // 保存短信记录到短信表
                    var resuAddGsm = await _CardDbProvider.Insertable<GsmSendMobileEntity>(dtoGsmSendMobile).ExecuteCommandAsync();
                    if (resuAddGsm < 1)
                        throw new Exception("转入卡短信记录保存异常");
                }
                #endregion


                //// 有开票金额，就写开票记录(表没定，暂时放缓开发)
                //if (dto.regcardDto.n_invoice.HasValue)
                //{
                //    if (null != dto.taxRecordDto
                //        && !string.IsNullOrEmpty(dto.taxRecordDto.taxno)
                //        && dto.taxRecordDto.s_sys_tax_type_id.HasValue
                //        && dto.taxRecordDto.amount.HasValue
                //        )
                //    {
                //        dto.taxRecordDto.create_date = DateTime.Now;
                //        dto.taxRecordDto.create_user = dto.regcardDto.s_set_work;
                //        dto.taxRecordDto.s_branch_id = dto.regcardDto.s_branch_id;

                //        // 插入开票数据
                //        var resultAddKP = await _CardDbProvider.Insertable<RegcardEntity>(dto.taxRecordDto).ExecuteCommandAsync();
                //        if (resultAddKP < 1)
                //            throw new Exception("开票数据保存异常");
                //    }
                //    else
                //    {
                //        throw new Exception("开票记录编码、类型ID、金额不能都为空");
                //    }
                //}

                _CardDbProvider.CommitTran();
            }
            catch (Exception ex)
            {
                _CardDbProvider.RollbackTran();
                throw ex;
            }

            return ApiResultDto.ToResultSuccess(data: true);
        }
        
        /// <summary>
        /// 编辑会员卡设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditRegcardAsync(string sCardDBConn, RegcardDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            //// 查看编码是否有重复
            //var resQryTestCode = await _CardDbProvider.Queryable<RegcardEntity>()
            //    .Where(x => x.idno != dto.idno
            //               &&
            //               (
            //                    (!string.IsNullOrEmpty(dto.s_account_no) && x.s_account_no == dto.s_account_no)
            //                    ||
            //                    (
            //                         x.s_branch_id == dto.s_branch_id
            //                         && (
            //                                (!string.IsNullOrEmpty(dto.s_card_no) && x.s_card_no == dto.s_card_no)
            //                            || (!string.IsNullOrEmpty(dto.s_print_no) && x.s_print_no == dto.s_print_no)
            //                            )
            //                    )
            //               )
            //           )
            //    .ToListAsync();
            //if (null != resQryTestCode && 0 < resQryTestCode.Count)
            //{
            //    return ApiResultDto.ToResultFail(data: false, msg: "账号、卡号、印刷卡号重复");
            //}

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "该会员卡不存在");
            }
            // 只更改几个可以更改的卡资料信息，涉及到卡金额信息的不在这里更改，人员信息的也不在这里改，在会员人员信息那边改
            // 备注
            resQry.s_memo = dto.s_memo;
            // 有效期
            resQry.s_forbin_date = dto.s_forbin_date;
            // 专用锁牌
            resQry.s_keyno = dto.s_keyno;
            // 销售员
            resQry.s_sale = dto.s_sale;
            // 充值提醒
            resQry.remind_add = dto.remind_add;
            // 消费提醒
            resQry.remind_pay = dto.remind_pay;
            // 是否主卡
            resQry.s_share = dto.s_share;
            // 父卡账号
            resQry.s_father_acct = dto.s_father_acct;

            // 执行更新
            var result = await _CardDbProvider.Updateable<RegcardEntity>(resQry).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 查询会员卡设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<RegcardSearchResultDto>>> QueryRegcardAsync(string sCardDBConn, RegcardSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and rc.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.idno != 0)
            {
                sWhere += " and rc.idno = @idno";
                listSqlParam.Add(new SugarParameter("@idno", dto.idno));
            }
            // 会员卡的账号
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_account_no))
            {
                sWhere += " and rc.s_account_no = @s_account_no";
                listSqlParam.Add(new SugarParameter("@s_account_no", dto.s_account_no));
            }
            // 卡号
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_card_no))
            {
                sWhere += " and rc.s_card_no = @s_card_no";
                listSqlParam.Add(new SugarParameter("@s_card_no", dto.s_card_no));
            }
            // 印刷卡号
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_print_no))
            {
                sWhere += " and rc.s_print_no = @s_print_no";
                listSqlParam.Add(new SugarParameter("@s_print_no", dto.s_print_no));
            }
            // 会员人的ID
            if (null != dto && dto.s_member_info_id != 0)
            {
                sWhere += " and rc.s_member_info_id = @s_member_info_id";
                listSqlParam.Add(new SugarParameter("@s_member_info_id", dto.s_member_info_id));
            }
            // 卡大类编号
            if (null != dto && !string.IsNullOrEmpty(dto.s_code))
            {
                sWhere += " and rc.s_code = @s_code";
                listSqlParam.Add(new SugarParameter("@s_code", dto.s_code));
            }
            // 卡类型
            if (null != dto && !string.IsNullOrEmpty(dto.s_card_type))
            {
                sWhere += " and rc.s_card_type = @s_card_type";
                listSqlParam.Add(new SugarParameter("@s_card_type", dto.s_card_type));
            }
            // 优惠政策代码
            if (null != dto && !string.IsNullOrEmpty(dto.PolicyCode))
            {
                sWhere += " and rc.PolicyCode = @PolicyCode";
                listSqlParam.Add(new SugarParameter("@PolicyCode", dto.PolicyCode));
            }
            // 卡状态
            if (null != dto && !string.IsNullOrEmpty(dto.s_stat))
            {
                sWhere += " and rc.s_stat = @s_stat";
                listSqlParam.Add(new SugarParameter("@s_stat", dto.s_stat));
            }
            // 会员姓名
            if (null != dto && !string.IsNullOrEmpty(dto.s_name))
            {
                sWhere += " and (rc.s_name like '%' + @s_name + '%' or md.member_name like '%' + @s_name + '%')";
                listSqlParam.Add(new SugarParameter("@s_name", dto.s_name));
            }
            // 客人昵称
            if (null != dto && !string.IsNullOrEmpty(dto.s_name2))
            {
                sWhere += " and rc.s_name2 like '%' + @s_name2 + '%'";
                listSqlParam.Add(new SugarParameter("@s_name2", dto.s_name2));
            }
            // 身份证号
            if (null != dto && !string.IsNullOrEmpty(dto.s_id_no))
            {
                sWhere += " and (rc.s_id_no like '%' + @s_id_no + '%' or md.id_number like '%' + @s_id_no + '%')";
                listSqlParam.Add(new SugarParameter("@s_id_no", dto.s_id_no));
            }
            // 联系电话
            if (null != dto && !string.IsNullOrEmpty(dto.s_tel))
            {
                sWhere += " and (rc.s_tel like '%' + @s_tel + '%' or md.telephone like '%' + @s_tel + '%')";
                listSqlParam.Add(new SugarParameter("@s_tel", dto.s_tel));
            }
            // 销售员
            if (null != dto && !string.IsNullOrEmpty(dto.s_sale))
            {
                sWhere += " and rc.s_sale = @s_sale";
                listSqlParam.Add(new SugarParameter("@s_sale", dto.s_sale));
            }
            // 备注
            if (null != dto && !string.IsNullOrEmpty(dto.s_memo))
            {
                sWhere += " and rc.s_memo like '%' + @s_memo + '%'";
                listSqlParam.Add(new SugarParameter("@s_memo", dto.s_memo));
            }
            // 父卡账号
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_father_acct))
            {
                sWhere += " and rc.s_father_acct = @s_father_acct";
                listSqlParam.Add(new SugarParameter("@s_father_acct", dto.s_father_acct));
            }
            // 初始化日期(开始)
            if (null != dto && dto.s_set_date_start.HasValue)
            {
                sWhere += " and (rc.s_set_date + ' ' + rc.s_set_time) >= @s_set_date_start";
                listSqlParam.Add(new SugarParameter("@s_set_date_start", dto.s_set_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            // 初始化日期(结束)
            if (null != dto && dto.s_set_date_end.HasValue)
            {
                sWhere += " and (rc.s_set_date + ' ' + rc.s_set_time) <= @s_set_date_end";
                listSqlParam.Add(new SugarParameter("@s_set_date_end", dto.s_set_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            // 操作员
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_set_work))
            {
                sWhere += " and rc.s_set_work = @s_set_work";
                listSqlParam.Add(new SugarParameter("@s_set_work", dto.s_set_work));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   regcard  rc 
                                           left join member_data    md  on rc.s_member_info_id=md.id
                                           left join card_big_type  cbt on rc.s_branch_id=cbt.s_branch_id and rc.s_code=cbt.s_no
                                           left join card_type      ct  on rc.s_branch_id=ct.s_branch_id and rc.s_card_type=ct.s_code 
                                           left join card_Policy    cp  on rc.s_branch_id=cp.s_branch_id and rc.PolicyCode=cp.s_code
                                           left join s_sys_area     pr  on rc.Province=pr.id
                                           left join s_sys_area     ci  on rc.City=ci.id 
                                           left join s_sys_area     co  on rc.County=co.id
                                           left join s_sys_user     su  on rc.s_branch_id=su.s_branch_id and rc.s_set_work=su.user_work_no
                                           left join s_sys_saler    ss  on rc.s_branch_id=ss.s_branch_id and rc.s_sale=ss.sale_work_no 
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by rc.idno desc) as row_no,
                                            rc.idno, rc.s_member_info_id, rc.s_account_no, rc.s_card_no, rc.s_print_no, rc.s_code, rc.s_card_type, 
                                            rc.PolicyCode, rc.n_charge, rc.n_pay, rc.s_name, rc.s_name2, rc.s_birth_day, rc.s_id_no, rc.s_tel, 
                                            rc.s_forbin_date, rc.s_mforbin_date, rc.s_set_date, rc.s_set_time, rc.s_set_work, rc.s_use_flag, 
                                            rc.s_use_date, rc.s_use_time, rc.s_use_work, rc.n_card_tot, rc.n_use_tot, rc.n_blnce, rc.n_charge_tot, 
                                            rc.n_invoice, rc.n_fen_tot, rc.n_fen_use, rc.n_fen_blnce, rc.n_use_cnt, rc.n_send_tot, rc.n_send_use, 
                                            rc.n_send_blnce, rc.n_yj, rc.n_reg_pay, rc.s_stat, rc.s_forbin, rc.s_sale, rc.s_memo, rc.n_ablnce, 
                                            rc.s_tax, rc.s_sec_code, rc.s_last_day, rc.s_keyno, rc.s_share, rc.s_father_acct, rc.[address], 
                                            rc.s_branch_no, rc.send_to_hq, rc.remind_add, rc.remind_pay, rc.s_pic, rc.d_use_date, rc.WeChatId, 
                                            rc.QRCode, rc.d_sale_date, rc.Gender, rc.Province, rc.City, rc.County, rc.subject_id, rc.n_charge_send, 
                                            rc.n_send1_tot, rc.n_send1_use, rc.n_send1_blnce, rc.n_send_room_tot, rc.s_charge_no, rc.n_room_disc, 
                                            rc.n_sauna_disc, rc.n_din_disc, rc.n_dance_disc, rc.n_chess_disc, rc.n_send_room_use, rc.n_send_room_blnce, 
                                            rc.member_id, rc.n_modi_cnt, rc.n_hour_tot, rc.s_telcode, rc.chest_s_date, rc.chest_t_date, rc.s_ren, 
                                            rc.s_account_fm, rc.s_out, rc.s_teacher, rc.s_branch_id,
		                                    s_member_info_name= md.member_name,
                                            s_card_big_type_id = cbt.id,
                                            s_card_big_type_name = cbt.s_name,
                                            s_card_type_id = ct.id,
                                            s_card_type_name = ct.s_describe,
                                            s_policy_id = cp.id,
                                            s_policy_name = cp.s_describe,
                                            Province_name = pr.area_name,
                                            City_name = ci.area_name,
                                            County_name = co.area_name,
                                            s_set_work_id = su.id,
                                            s_set_work_name = su.[user_name],
                                            s_sale_name = ss.sale_name
                                    from   regcard  rc 
                                           left join member_data    md  on rc.s_member_info_id=md.id
                                           left join card_big_type  cbt on rc.s_branch_id=cbt.s_branch_id and rc.s_code=cbt.s_no
                                           left join card_type      ct  on rc.s_branch_id=ct.s_branch_id and rc.s_card_type=ct.s_code 
                                           left join card_Policy    cp  on rc.s_branch_id=cp.s_branch_id and rc.PolicyCode=cp.s_code
                                           left join s_sys_area     pr  on rc.Province=pr.id
                                           left join s_sys_area     ci  on rc.City=ci.id 
                                           left join s_sys_area     co  on rc.County=co.id
                                           left join s_sys_user     su  on rc.s_branch_id=su.s_branch_id and rc.s_set_work=su.user_work_no
                                           left join s_sys_saler    ss  on rc.s_branch_id=ss.s_branch_id and rc.s_sale=ss.sale_work_no 
                                    where  1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<RegcardSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<RegcardSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }

        /// <summary>
        /// 加密会员卡密码
        /// </summary>
        /// <param name="sOrigCardPwd"></param>
        /// <returns></returns>
        private string EncryptCardPwd(string sOrigCardPwd)
        {
            if (string.IsNullOrEmpty(sOrigCardPwd))
            {
                return sOrigCardPwd;
            }
            char[] mPwd = sOrigCardPwd.ToUpper().ToCharArray();
            for (int i = 0; i < mPwd.Length; i++)
            {
                mPwd[i] = (char)(Convert.ToInt32(mPwd[i]) + 11);
            }
            return new string(mPwd);
        }

        /// <summary>
        /// 会员卡充值
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> ChongZhiRegcardAsync(string sCardDBConn, RegcardAddMoneyDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<RegcardEntity>()
                .Where(x => x.idno == dto.regcardDto.idno)
                .ToListAsync();
            if (null == resQryTestCode || resQryTestCode.Count < 1)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "卡记录不存在");
            }

            _CardDbProvider.BeginTran();
            try
            {
                // 查看卡类型是否可以充值
                var resQryCardType = await _CardDbProvider.Queryable<CardTypeEntity>()
                    .Where(x => x.id == dto.regcardDto.s_branch_id && x.s_code == resQryTestCode[0].s_card_type)
                    .ToListAsync();
                if (null == resQryCardType || 0 == resQryCardType.Count)
                {
                    throw new Exception("卡类型不存在");
                }
                if (string.IsNullOrEmpty(resQryCardType[0].s_able_cz) || "N" == resQryCardType[0].s_able_cz.Trim().ToUpper())
                {
                    throw new Exception("当前卡类型不可充值");
                }

                string s_branch_no = "";
                var resQryBranch = await _CardDbProvider.Queryable<BranchEntity>().Where(x => x.id == dto.regcardDto.s_branch_id).ToListAsync();
                if (null == resQryBranch || 0 == resQryBranch.Count)
                {
                    throw new Exception("分店ID不存在");
                }
                s_branch_no = resQryBranch[0].branch_no;

                // 查会员人员资料
                var resQryMember = await _CardDbProvider.Queryable<MemberInfoEntity>().Where(x => x.id == resQryTestCode[0].s_member_info_id).SingleAsync();
                string s_name = "";
                if (null != resQryMember)
                    s_name = resQryMember.member_name;

                decimal n_blnce_tot = resQryTestCode[0].n_ablnce.Value;
                decimal n_use_tot = resQryTestCode[0].n_use_tot.Value;
                decimal n_send_blnce_tot = resQryTestCode[0].n_send_blnce.Value;
                decimal n_fen_blnce_tot = resQryTestCode[0].n_fen_blnce.Value;

                var resQryCardPolicy = await _CardDbProvider.Queryable<CardPolicyEntity>()
                    .Where(x => x.IsActive == "Y" && x.s_branch_id == dto.regcardDto.s_branch_id && x.s_code == dto.regcardDto.PolicyCode)
                    .ToListAsync();
                if (null == resQryCardPolicy || resQryCardPolicy.Count < 1)
                    throw new Exception("会员卡优惠政策信息不存在");

                // 固定充值的，就需要判断付款金额是否和优惠政策设置的是否一样
                if (!string.IsNullOrEmpty(resQryCardPolicy[0].isfixadd) && "Y" == resQryCardPolicy[0].isfixadd.Trim().ToUpper())
                {
                    if (false == dto.regcardDto.n_pay.HasValue
                        || (resQryCardPolicy[0].n_pay.HasValue && dto.regcardDto.n_pay != resQryCardPolicy[0].n_pay)
                        )
                        throw new Exception("卡付款金额不等于销售");
                }

                int iAddCnt = 0;
                // 销售金额不为0的，就插入卡务数据记录
                decimal nPayMoneyTot = 0;
                if (null != dto.listPayMoneysDto && 0 < dto.listPayMoneysDto.Count)
                {
                    // 查cardaccount表当前卡号的cnt的值
                    var resultOldCA = await _CardDbProvider.Queryable<CardAccountEntity>()
                        .Where(x => x.s_account_no == resQryTestCode[0].s_account_no)
                        .OrderBy(x => x.n_add_cnt, OrderByType.Desc)
                        .ToListAsync();
                    if (null != resultOldCA && resultOldCA.Count > 0)
                    {
                        iAddCnt = resultOldCA[0].n_add_cnt.Value;
                    }
                    iAddCnt += 1;
                    for (int i = 0; i < dto.listPayMoneysDto.Count; i++)
                    {
                        #region 插入卡务中间表数据记录
                        CardMidMsgDto dtoCardMidMsg = new CardMidMsgDto();
                        dtoCardMidMsg.s_member_info_id = resQryTestCode[0].s_member_info_id;
                        dtoCardMidMsg.s_card_account = resQryTestCode[0].s_account_no;
                        dtoCardMidMsg.s_branch_no = resQryTestCode[0].s_branch_no;
                        dtoCardMidMsg.s_card_no = resQryTestCode[0].s_card_no;
                        dtoCardMidMsg.s_print_no = resQryTestCode[0].s_print_no;
                        dtoCardMidMsg.s_account_to = "充值";
                        dtoCardMidMsg.n_blnce = n_blnce_tot;
                        dtoCardMidMsg.n_use = n_use_tot;
                        dtoCardMidMsg.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                        dtoCardMidMsg.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                        dtoCardMidMsg.s_flag = "Y";
                        dtoCardMidMsg.s_do_time = DateTime.Now;
                        dtoCardMidMsg.n_times = 1;
                        dtoCardMidMsg.auto_id_1 = 0;
                        dtoCardMidMsg.s_back = "Y";
                        dtoCardMidMsg.s_back_time = DateTime.Now;
                        dtoCardMidMsg.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                        dtoCardMidMsg.Auto_ID_2 = 0;
                        dtoCardMidMsg.n_send_charge = 0;
                        dtoCardMidMsg.s_work_no = dto.regcardDto.s_set_work;
                        dtoCardMidMsg.pay_type = "P"; // 充值
                        dtoCardMidMsg.n_send_blnce = n_send_blnce_tot;
                        dtoCardMidMsg.n_fen_blnce = n_fen_blnce_tot;
                        dtoCardMidMsg.n_fen_use = 0;
                        dtoCardMidMsg.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                        dtoCardMidMsg.s_sales = dto.regcardDto.s_sale;
                        dtoCardMidMsg.s_code = resQryTestCode[0].s_code;
                        dtoCardMidMsg.s_card_type = resQryTestCode[0].s_card_type;
                        dtoCardMidMsg.PolicyCode = dto.regcardDto.PolicyCode;
                        dtoCardMidMsg.paycode = dto.listPayMoneysDto[i].s_PayCode;
                        dtoCardMidMsg.s_name = s_name;
                        dtoCardMidMsg.s_branch_id = dto.regcardDto.s_branch_id;

                        // 数据插入数据库表
                        var resuAddCMM = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsg).ExecuteReturnEntityAsync();
                        if (null == resuAddCMM || resuAddCMM.auto_id < 1)
                            throw new Exception("卡务中间表数据保存异常");

                        // 更新Auto_ID_2的值
                        resuAddCMM.Auto_ID_2 = resuAddCMM.auto_id;
                        var resultUpdateCMM = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMM).ExecuteCommandAsync();
                        if (resultUpdateCMM < 1)
                            throw new Exception("卡务中间表数据更新ID异常");
                        #endregion

                        #region 插入卡务数据记录

                        // 查看付款方式名称
                        string s_PayCodeName = "";
                        if (!string.IsNullOrEmpty(dto.listPayMoneysDto[i].s_PayCode))
                        {
                            var resQryPayCode = await _CardDbProvider.Queryable<PayCodeEntity>()
                                .Where(x => x.s_branch_id == dto.regcardDto.s_branch_id && x.pay_code == dto.listPayMoneysDto[i].s_PayCode)
                                .ToListAsync();
                            if (null == resQryPayCode || 0 == resQryPayCode.Count)
                            {
                                throw new Exception("付款编码不存在");
                            }
                            s_PayCodeName = resQryPayCode[0].describe;
                        }

                        CardAccountDto dtoCardAccount = new CardAccountDto();
                        dtoCardAccount.s_member_data_id = resQryTestCode[0].s_member_info_id;
                        dtoCardAccount.s_account_no = resQryTestCode[0].s_account_no;
                        dtoCardAccount.s_serial_no = 1;
                        dtoCardAccount.s_cardno = resQryTestCode[0].s_print_no;
                        dtoCardAccount.s_dep_name = s_PayCodeName;
                        dtoCardAccount.s_account_to = "";
                        dtoCardAccount.n_capital = dto.listPayMoneysDto[i].n_PayMoney;
                        dtoCardAccount.n_caprmb = dto.listPayMoneysDto[i].n_PayMoney;
                        dtoCardAccount.n_charge = 0;
                        dtoCardAccount.n_chg_tot = 0;
                        dtoCardAccount.n_fen_charge = 0;
                        dtoCardAccount.n_fen_send = 0;
                        dtoCardAccount.n_fen_use = 0;
                        dtoCardAccount.n_hour_cnt = 0;
                        dtoCardAccount.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                        dtoCardAccount.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                        dtoCardAccount.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                        dtoCardAccount.s_set_class = dto.loginBusinessDataDto.s_set_class;
                        dtoCardAccount.s_set_work = dto.regcardDto.s_set_work;
                        dtoCardAccount.s_emp = dto.regcardDto.s_set_work;
                        dtoCardAccount.s_meno = dto.regcardDto.s_memo;
                        dtoCardAccount.s_del = null;
                        dtoCardAccount.s_type = null;
                        dtoCardAccount.n_send_cnt = 0;
                        dtoCardAccount.s_sale = dto.regcardDto.s_sale;
                        dtoCardAccount.s_tax = "N";
                        dtoCardAccount.s_change = "";
                        dtoCardAccount.s_old_card = null;
                        dtoCardAccount.member_id = null;
                        dtoCardAccount.s_department = "";
                        dtoCardAccount.n_nowblnce = n_blnce_tot;
                        dtoCardAccount.n_send_charge = 0;
                        dtoCardAccount.n_add_cnt = iAddCnt;
                        dtoCardAccount.s_branch_happen = s_branch_no;
                        dtoCardAccount.card_mid_id = resuAddCMM.auto_id;
                        dtoCardAccount.send_to_hq = "N";
                        dtoCardAccount.n_send1_charge = null;
                        dtoCardAccount.n_send_room_charge = null;
                        dtoCardAccount.s_qrcode = null;
                        dtoCardAccount.pay_type = "P";
                        dtoCardAccount.add_type = "V";
                        dtoCardAccount.paycode = dto.listPayMoneysDto[i].s_PayCode;
                        dtoCardAccount.QRcode = null;
                        dtoCardAccount.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                        dtoCardAccount.s_branch_id = dto.regcardDto.s_branch_id;

                        // 数据插入数据库表
                        var resuAddCA = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccount).ExecuteCommandAsync();
                        if (resuAddCA < 1)
                            throw new Exception("卡务数据保存异常");

                        #endregion

                        n_blnce_tot += dto.listPayMoneysDto[i].n_PayMoney;
                        n_use_tot += 0;
                        n_send_blnce_tot += 0;
                        n_fen_blnce_tot += 0;
                        nPayMoneyTot += dto.listPayMoneysDto[i].n_PayMoney;
                    }
                }
                if (dto.regcardDto.n_pay.Value != nPayMoneyTot)
                    throw new Exception("实际付款金额不等于销售金额");

                // 固定充值的时候，要是付款金额大于卡储金额，多出来的部分，就当成年费处理
                decimal n_YearMoney = 0;
                if (!string.IsNullOrEmpty(resQryCardPolicy[0].isfixadd) && "Y" == resQryCardPolicy[0].isfixadd.Trim().ToUpper() // 固定充值
                    && dto.regcardDto.n_pay > resQryCardPolicy[0].n_charge // 付款金额大于年费
                    )
                {
                    n_YearMoney = dto.regcardDto.n_pay.Value - resQryCardPolicy[0].n_charge.Value;

                    #region 插入卡务中间表数据记录
                    CardMidMsgDto dtoCardMidMsg = new CardMidMsgDto();
                    dtoCardMidMsg.s_member_info_id = resQryTestCode[0].s_member_info_id;
                    dtoCardMidMsg.s_card_account = resQryTestCode[0].s_account_no;
                    dtoCardMidMsg.s_branch_no = resQryTestCode[0].s_branch_no;
                    dtoCardMidMsg.s_card_no = resQryTestCode[0].s_card_no;
                    dtoCardMidMsg.s_print_no = resQryTestCode[0].s_print_no;
                    dtoCardMidMsg.s_account_to = "";
                    dtoCardMidMsg.n_blnce = n_blnce_tot;
                    dtoCardMidMsg.n_use = n_use_tot;
                    dtoCardMidMsg.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                    dtoCardMidMsg.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                    dtoCardMidMsg.s_flag = "Y";
                    dtoCardMidMsg.s_do_time = DateTime.Now;
                    dtoCardMidMsg.n_times = 1;
                    dtoCardMidMsg.auto_id_1 = 0;
                    dtoCardMidMsg.s_back = "Y";
                    dtoCardMidMsg.s_back_time = DateTime.Now;
                    dtoCardMidMsg.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoCardMidMsg.Auto_ID_2 = 0;
                    dtoCardMidMsg.n_send_charge = 0;
                    dtoCardMidMsg.s_work_no = dto.regcardDto.s_set_work;
                    dtoCardMidMsg.pay_type = "A"; // 办卡
                    dtoCardMidMsg.n_send_blnce = n_send_blnce_tot;
                    dtoCardMidMsg.n_fen_blnce = n_fen_blnce_tot;
                    dtoCardMidMsg.n_fen_use = 0;
                    dtoCardMidMsg.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                    dtoCardMidMsg.s_sales = dto.regcardDto.s_sale;
                    dtoCardMidMsg.s_code = resQryTestCode[0].s_code;
                    dtoCardMidMsg.s_card_type = resQryTestCode[0].s_card_type;
                    dtoCardMidMsg.PolicyCode = dto.regcardDto.PolicyCode;
                    dtoCardMidMsg.paycode = "";
                    dtoCardMidMsg.s_name = s_name;
                    dtoCardMidMsg.s_branch_id = dto.regcardDto.s_branch_id;

                    // 数据插入数据库表
                    var resuAddCMM = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsg).ExecuteReturnEntityAsync();
                    if (null == resuAddCMM || resuAddCMM.auto_id < 1)
                        throw new Exception("卡务中间表数据保存异常");

                    // 更新Auto_ID_2的值
                    resuAddCMM.Auto_ID_2 = resuAddCMM.auto_id;
                    var resultUpdateCMM = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMM).ExecuteCommandAsync();
                    if (resultUpdateCMM < 1)
                        throw new Exception("卡务中间表数据更新ID异常");
                    #endregion

                    #region 插入卡务数据记录
                    CardAccountDto dtoCardAccount = new CardAccountDto();
                    dtoCardAccount.s_member_data_id = resQryTestCode[0].s_member_info_id;
                    dtoCardAccount.s_account_no = resQryTestCode[0].s_account_no;
                    dtoCardAccount.s_serial_no = 1;
                    dtoCardAccount.s_cardno = resQryTestCode[0].s_print_no;
                    dtoCardAccount.s_dep_name = "年费";
                    dtoCardAccount.s_account_to = "";
                    dtoCardAccount.n_capital = 0;
                    dtoCardAccount.n_caprmb = 0;
                    dtoCardAccount.n_charge = n_YearMoney;
                    dtoCardAccount.n_chg_tot = 0;
                    dtoCardAccount.n_fen_charge = 0;
                    dtoCardAccount.n_fen_send = 0;
                    dtoCardAccount.n_fen_use = 0;
                    dtoCardAccount.n_hour_cnt = 0;
                    dtoCardAccount.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoCardAccount.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                    dtoCardAccount.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                    dtoCardAccount.s_set_class = dto.loginBusinessDataDto.s_set_class;
                    dtoCardAccount.s_set_work = dto.regcardDto.s_set_work;
                    dtoCardAccount.s_emp = dto.regcardDto.s_set_work;
                    dtoCardAccount.s_meno = dto.regcardDto.s_memo;
                    dtoCardAccount.s_del = null;
                    dtoCardAccount.s_type = null;
                    dtoCardAccount.n_send_cnt = 0;
                    dtoCardAccount.s_sale = dto.regcardDto.s_sale;
                    dtoCardAccount.s_tax = "N";
                    dtoCardAccount.s_change = "";
                    dtoCardAccount.s_old_card = null;
                    dtoCardAccount.member_id = null;
                    dtoCardAccount.s_department = "";
                    dtoCardAccount.n_nowblnce = n_blnce_tot;
                    dtoCardAccount.n_send_charge = 0;
                    dtoCardAccount.n_add_cnt = iAddCnt;
                    dtoCardAccount.s_branch_happen = s_branch_no;
                    dtoCardAccount.card_mid_id = resuAddCMM.auto_id;
                    dtoCardAccount.send_to_hq = "N";
                    dtoCardAccount.n_send1_charge = null;
                    dtoCardAccount.n_send_room_charge = null;
                    dtoCardAccount.s_qrcode = null;
                    dtoCardAccount.pay_type = "P";
                    dtoCardAccount.add_type = "V";
                    dtoCardAccount.paycode = "";
                    dtoCardAccount.QRcode = null;
                    dtoCardAccount.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                    dtoCardAccount.s_branch_id = dto.regcardDto.s_branch_id;

                    // 数据插入数据库表
                    var resuAddCA = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccount).ExecuteCommandAsync();
                    if (resuAddCA < 1)
                        throw new Exception("卡务数据保存异常");

                    #endregion

                    n_blnce_tot -= n_YearMoney;
                    n_use_tot += 0;
                    n_send_blnce_tot += 0;
                    n_fen_blnce_tot += 0;
                }

                // 赠送金额
                decimal? n_SendMoney = dto.regcardDto.n_send_money;
                // 要是固定充，赠送金额就是优惠政策里面的设置的赠送金额
                if (!string.IsNullOrEmpty(resQryCardPolicy[0].isfixadd) && "Y" == resQryCardPolicy[0].isfixadd.Trim().ToUpper()) // 固定充值
                {
                    n_SendMoney = 0; // 固定充的赠送金额通过计算得到，不是传过来的
                    if (dto.regcardDto.n_pay < resQryCardPolicy[0].n_charge)// 卡储金额大于付款金额
                        n_SendMoney = resQryCardPolicy[0].n_charge - dto.regcardDto.n_pay;
                }

                // 写赠送金额
                if (n_SendMoney.HasValue && 0 != n_SendMoney.Value)
                {
                    #region 插入卡务中间表数据记录
                    CardMidMsgDto dtoCardMidMsg = new CardMidMsgDto();
                    dtoCardMidMsg.s_member_info_id = resQryTestCode[0].s_member_info_id;
                    dtoCardMidMsg.s_card_account = resQryTestCode[0].s_account_no;
                    dtoCardMidMsg.s_branch_no = resQryTestCode[0].s_branch_no;
                    dtoCardMidMsg.s_card_no = resQryTestCode[0].s_card_no;
                    dtoCardMidMsg.s_print_no = resQryTestCode[0].s_print_no;
                    dtoCardMidMsg.s_account_to = "充值";
                    dtoCardMidMsg.n_blnce = n_blnce_tot;
                    dtoCardMidMsg.n_use = n_use_tot;
                    dtoCardMidMsg.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                    dtoCardMidMsg.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                    dtoCardMidMsg.s_flag = "Y";
                    dtoCardMidMsg.s_do_time = DateTime.Now;
                    dtoCardMidMsg.n_times = 1;
                    dtoCardMidMsg.auto_id_1 = 0;
                    dtoCardMidMsg.s_back = "Y";
                    dtoCardMidMsg.s_back_time = DateTime.Now;
                    dtoCardMidMsg.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoCardMidMsg.Auto_ID_2 = 0;
                    dtoCardMidMsg.n_send_charge = 0;
                    dtoCardMidMsg.s_work_no = dto.regcardDto.s_set_work;
                    dtoCardMidMsg.pay_type = "P"; // 充值
                    dtoCardMidMsg.n_send_blnce = n_send_blnce_tot;
                    dtoCardMidMsg.n_fen_blnce = n_fen_blnce_tot;
                    dtoCardMidMsg.n_fen_use = 0;
                    dtoCardMidMsg.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                    dtoCardMidMsg.s_sales = dto.regcardDto.s_sale;
                    dtoCardMidMsg.s_code = resQryTestCode[0].s_code;
                    dtoCardMidMsg.s_card_type = resQryTestCode[0].s_card_type;
                    dtoCardMidMsg.PolicyCode = resQryTestCode[0].PolicyCode;
                    dtoCardMidMsg.paycode = "";
                    dtoCardMidMsg.s_name = s_name;
                    dtoCardMidMsg.s_branch_id = dto.regcardDto.s_branch_id;

                    // 数据插入数据库表
                    var resuAddCMM = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsg).ExecuteReturnEntityAsync();
                    if (null == resuAddCMM || resuAddCMM.auto_id < 1)
                        throw new Exception("卡务中间表数据保存异常");

                    // 更新Auto_ID_2的值
                    resuAddCMM.Auto_ID_2 = resuAddCMM.auto_id;
                    var resultUpdateCMM = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMM).ExecuteCommandAsync();
                    if (resultUpdateCMM < 1)
                        throw new Exception("卡务中间表数据更新ID异常");
                    #endregion

                    #region 插入卡务数据记录
                    CardAccountDto dtoCardAccount = new CardAccountDto();
                    dtoCardAccount.s_member_data_id = resQryTestCode[0].s_member_info_id;
                    dtoCardAccount.s_account_no = resQryTestCode[0].s_account_no;
                    dtoCardAccount.s_serial_no = 1;
                    dtoCardAccount.s_cardno = resQryTestCode[0].s_print_no;
                    dtoCardAccount.s_dep_name = "赠送";
                    dtoCardAccount.s_account_to = "";
                    dtoCardAccount.n_capital = n_SendMoney;
                    dtoCardAccount.n_caprmb = n_SendMoney;
                    dtoCardAccount.n_charge = 0;
                    dtoCardAccount.n_chg_tot = 0;
                    dtoCardAccount.n_fen_charge = 0;
                    dtoCardAccount.n_fen_send = 0;
                    dtoCardAccount.n_fen_use = 0;
                    dtoCardAccount.n_hour_cnt = 0;
                    dtoCardAccount.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoCardAccount.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                    dtoCardAccount.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                    dtoCardAccount.s_set_class = dto.loginBusinessDataDto.s_set_class;
                    dtoCardAccount.s_set_work = dto.regcardDto.s_set_work;
                    dtoCardAccount.s_emp = dto.regcardDto.s_set_work;
                    dtoCardAccount.s_meno = dto.regcardDto.s_memo;
                    dtoCardAccount.s_del = null;
                    dtoCardAccount.s_type = null;
                    dtoCardAccount.n_send_cnt = 0;
                    dtoCardAccount.s_sale = dto.regcardDto.s_sale;
                    dtoCardAccount.s_tax = "N";
                    dtoCardAccount.s_change = "";
                    dtoCardAccount.s_old_card = null;
                    dtoCardAccount.member_id = null;
                    dtoCardAccount.s_department = "";
                    dtoCardAccount.n_nowblnce = n_blnce_tot;
                    dtoCardAccount.n_send_charge = 0;
                    dtoCardAccount.n_add_cnt = iAddCnt;
                    dtoCardAccount.s_branch_happen = s_branch_no;
                    dtoCardAccount.card_mid_id = resuAddCMM.auto_id;
                    dtoCardAccount.send_to_hq = "N";
                    dtoCardAccount.n_send1_charge = null;
                    dtoCardAccount.n_send_room_charge = null;
                    dtoCardAccount.s_qrcode = null;
                    dtoCardAccount.pay_type = "P";
                    dtoCardAccount.add_type = "V";
                    dtoCardAccount.paycode = "";
                    dtoCardAccount.QRcode = null;
                    dtoCardAccount.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                    dtoCardAccount.s_branch_id = dto.regcardDto.s_branch_id;

                    // 数据插入数据库表
                    var resuAddCA = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccount).ExecuteCommandAsync();
                    if (resuAddCA < 1)
                        throw new Exception("卡务数据保存异常");

                    #endregion

                    n_blnce_tot += n_SendMoney.Value;
                    n_use_tot += 0;
                    n_send_blnce_tot += 0;
                    n_fen_blnce_tot += 0;
                }

                // 按优惠政策送票
                var resQryPolicyTicket = await _CardDbProvider.Queryable<CardPolicyTicketEntity>()
                    .Where(x => x.IsActive == "Y" && x.s_branch_id == dto.regcardDto.s_branch_id && x.PolicyCode == dto.regcardDto.PolicyCode)
                    .ToListAsync();
                if (null != resQryPolicyTicket && 0 < resQryPolicyTicket.Count && dto.regcardDto.n_pay >= resQryCardPolicy[0].n_pay)
                {
                    // 获取单号
                    string sBillNo = await CeChengBusinessFunctionHelper.GetSysNextNo(NextNumberIdentityEnum.ticket_sell_no);
                    for (int i = 0; i < resQryPolicyTicket.Count; i++)
                    {
                        //// 按优惠政策送票
                        //var resQryTicket = await _CardDbProvider.Queryable<TicketSetEntity>()
                        //    .Where(x => x.is_active == "Y" && x.s_branch_id == dto.regcardDto.s_branch_id && x.ticket_code == resQryPolicyTicket[i].TypeCode)
                        //    .ToListAsync();
                        //if (null == resQryTicket || resQryTicket.Count < 1)
                        //{
                        //    continue;
                        //}
                        //// 保存门票销售单据表数据（赠送的当成一条销售数据保存，对应s_ticket_sell表）
                        //STicketSellAddDto dtoSTicketSellAdd = new STicketSellAddDto();
                        //dtoSTicketSellAdd.sell_no = sBillNo;
                        //dtoSTicketSellAdd.wechat_Id = resQryTestCode[0].WeChatId;
                        //dtoSTicketSellAdd.regcard_id = resQryTestCode[0].idno;
                        //dtoSTicketSellAdd.pay_type = "3"; // 赠送

                        //var resultSaveTicketBill = await _CardDbProvider.Insertable<STitcketSellEntity>(dtoSTicketSellAdd).ExecuteReturnEntityAsync();
                        //if (null == resultSaveTicketBill || resultSaveTicketBill.id < 1)
                        //    throw new Exception("门票销售主表数据保存异常");

                        //// 保存销售的门票项目列表数据（每种票当成一条数据保存，对应s_ticket_sell_record表）
                        //STicketSellRecordEntity dtoTicketSellRecord = new STicketSellRecordEntity();
                        //dtoTicketSellRecord.s_titcket_sell_id = resultSaveTicketBill.id;
                        //dtoTicketSellRecord.ticket_code = resQryTicket[0].ticket_code;
                        //dtoTicketSellRecord.amount = resQryPolicyTicket[i].N_Count;
                        //dtoTicketSellRecord.price = resQryTicket[0].price;
                        //dtoTicketSellRecord.s_branch_id = dto.regcardDto.s_branch_id.Value;
                        //// 票的有效期(取卡有效期、计算出来的有效期、票的可使用结束日期中最小的那个)
                        //DateTime dateTicketValid = resQryTestCode[0].s_forbin_date.Value;
                        //if (resQryTicket[0].validate_day.HasValue)
                        //{
                        //    dateTicketValid = DateTime.Now.AddDays(resQryTicket[0].validate_day.Value);
                        //}
                        //if (resQryTicket[0].use_end_date.HasValue
                        //    && resQryTicket[0].use_end_date.Value.ToString("yyyy-MM-dd HH:mm:ss").CompareTo(dateTicketValid.ToString("yyyy-MM-dd HH:mm:ss")) < 0)
                        //{
                        //    dateTicketValid = resQryTicket[0].use_end_date.Value;
                        //}
                        //dtoTicketSellRecord.valid_date = dateTicketValid;



                        //var resultSaveTicketReord = await _CardDbProvider.Insertable<STicketSellRecordEntity>(dtoTicketSellRecord).ExecuteReturnEntityAsync();
                        //if (null == resultSaveTicketReord || resultSaveTicketReord.id < 1)
                        //    throw new Exception("门票销售记录表数据保存异常");

                        //// 更新s_ticket_sell表的状态，使生成对应明细票数据到s_ticket_sell_record_detail
                        //resultSaveTicketBill.status = "Y";
                        //var resultSaveTicketBill2 = await _CardDbProvider.Updateable<STitcketSellEntity>(resultSaveTicketBill).ExecuteCommandAsync();
                        //if (resultSaveTicketBill2 < 1)
                        //    throw new Exception("门票销售主表数据更新异常");

                    }
                }

                #region 生成短信记录
                if (!string.IsNullOrEmpty(resQryTestCode[0].remind_add) && "Y" == resQryTestCode[0].remind_add.Trim().ToUpper()
                    && null != resQryMember
                    && !string.IsNullOrEmpty(resQryMember.telephone)
                    && resQryMember.telephone.Length > 10)
                {
                    // 查询余额
                    var resQryEndCz = await _CardDbProvider.Queryable<RegcardEntity>()
                        .Where(x => x.idno == dto.regcardDto.idno)
                        .SingleAsync();
                    // 短信信息中的印刷卡号处理部分内容
                    string sMoHuPrintNo = resQryTestCode[0].s_print_no;
                    if (sMoHuPrintNo.Length > 4)
                    {
                        sMoHuPrintNo = sMoHuPrintNo.Substring(sMoHuPrintNo.Length - 4, 4);
                    }
                    string sDate = DateTime.Now.ToString("yyyy-MM-dd");
                    GsmSendMobileDto dtoGsmSendMobile = new GsmSendMobileDto();
                    dtoGsmSendMobile.create_date = DateTime.Now;
                    dtoGsmSendMobile.d_hotel_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoGsmSendMobile.n_cnt = 0;
                    dtoGsmSendMobile.s_flag = "N";
                    dtoGsmSendMobile.s_send_flag = "N";
                    dtoGsmSendMobile.s_branch_id = dto.regcardDto.s_branch_id;
                    dtoGsmSendMobile.s_mobile = resQryMember.telephone;
                    dtoGsmSendMobile.s_message = "尊敬的客户，您好，您的会员卡***" + sMoHuPrintNo + "于" + sDate + "充值：" + dto.regcardDto.n_pay + "元，本次赠送："+ n_SendMoney + "元，余额为：" + resQryEndCz.n_blnce + "元。";

                    // 保存短信记录到短信表
                    var resuAddGsm = await _CardDbProvider.Insertable<GsmSendMobileEntity>(dtoGsmSendMobile).ExecuteCommandAsync();
                    if (resuAddGsm < 1)
                        throw new Exception("短信提醒数据保存异常");
                }
                #endregion

                //// 有开票金额，就写开票记录(表没定，暂时放缓开发)
                //if (dto.regcardDto.n_invoice.HasValue)
                //{
                //    if (null != dto.taxRecordDto
                //        && !string.IsNullOrEmpty(dto.taxRecordDto.taxno)
                //        && dto.taxRecordDto.s_sys_tax_type_id.HasValue
                //        && dto.taxRecordDto.amount.HasValue
                //        )
                //    {
                //        dto.taxRecordDto.create_date = DateTime.Now;
                //        dto.taxRecordDto.create_user = dto.regcardDto.s_set_work;
                //        dto.taxRecordDto.s_branch_id = dto.regcardDto.s_branch_id;

                //        // 插入开票数据
                //        var resultAddKP = await _CardDbProvider.Insertable<RegcardEntity>(dto.taxRecordDto).ExecuteCommandAsync();
                //        if (resultAddKP < 1)
                //            throw new Exception("开票数据保存异常");
                //    }
                //    else
                //    {
                //        throw new Exception("开票记录编码、类型ID、金额不能都为空");
                //    }
                //}

                _CardDbProvider.CommitTran();
            }
            catch (Exception ex)
            {
                _CardDbProvider.RollbackTran();
                throw ex;
            }

            return ApiResultDto.ToResultSuccess(data: true);
        }

        /// <summary>
        /// 会员卡修改密码
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> ModifyPwdRegcardAsync(string sCardDBConn, RegcardModifyPwdDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "该会员卡不存在");
            }
            if (string.IsNullOrEmpty(dto.sOldPwd) || string.IsNullOrEmpty(dto.sNewPwd))
                throw new Exception("新、老密码都不能为空");

            string sEncrOldPwd = EncryptCardPwd(dto.sOldPwd);
            string sEncrNewPwd = EncryptCardPwd(dto.sNewPwd);

            if (sEncrOldPwd.CompareTo(resQry.s_sec_code) != 0)
            {
                throw new Exception("老密码验证不通过");
            }
            resQry.s_sec_code = sEncrNewPwd;

            // 执行更新
            var result = await _CardDbProvider.Updateable<RegcardEntity>(resQry).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 会员卡修改密码
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> ResetPwdRegcardAsync(string sCardDBConn, RegcardModifyPwdDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "该会员卡不存在");
            }

            resQry.s_sec_code = EncryptCardPwd("888");

            // 执行更新
            var result = await _CardDbProvider.Updateable<RegcardEntity>(resQry).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 会员卡状态修改（挂失、解挂、停用、启用这几个状态设置）
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> ModifyStateRegcardAsync(string sCardDBConn, RegcardStateModifyDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "该会员卡不存在");
            }

            _CardDbProvider.BeginTran();
            try
            {
                if (string.IsNullOrEmpty(dto.s_Op_Mark))
                    throw new Exception("操作标识码不能为空");

                if(!("G" == dto.s_Op_Mark || "J" == dto.s_Op_Mark || "T" == dto.s_Op_Mark || "Q" == dto.s_Op_Mark))
                    throw new Exception("操作标识码不能时别");

                string s_branch_no = "";
                var resQryBranch = await _CardDbProvider.Queryable<BranchEntity>().Where(x => x.id == dto.s_branch_id).ToListAsync();
                if (null == resQryBranch || 0 == resQryBranch.Count)
                {
                    throw new Exception("分店ID不存在");
                }
                s_branch_no = resQryBranch[0].branch_no;

                string s_reason = dto.s_reason;
                string s_type_no = "";
                string s_modi_des = "";
                string IsActive = "Y";
                if (string.IsNullOrEmpty(s_reason))
                {
                    // s_Op_Mark标识码：G：挂失；J：解挂；T：停用；Q：启用
                    if ("G" == dto.s_Op_Mark)
                    {
                        s_reason = "挂失";
                    }
                    else if ("J" == dto.s_Op_Mark)
                    {
                        s_reason = "解挂";
                    }
                    else if ("T" == dto.s_Op_Mark)
                    {
                        s_reason = "停用";
                    }
                    else if ("Q" == dto.s_Op_Mark)
                    {
                        s_reason = "启用";
                    }
                }
                // s_Op_Mark标识码：G：挂失；J：解挂；T：停用；Q：启用
                // 卡状态：C：退卡；F：挂失；R：回收；S：初始；T：停用；U：在用；
                if ("G" == dto.s_Op_Mark)
                {
                    resQry.s_stat = "F";
                    resQry.s_last_day = dto.loginBusinessDataDto.s_sys_date;
                    s_type_no = "2";
                    s_modi_des = "挂失";
                }
                else if ("J" == dto.s_Op_Mark)
                {
                    resQry.s_stat = "U";
                    s_type_no = "4";
                    s_modi_des = "解挂";
                    IsActive = "N";
                }
                else if ("T" == dto.s_Op_Mark)
                {
                    resQry.s_stat = "T";
                    s_type_no = "6";
                    s_modi_des = "停用";
                }
                else if ("Q" == dto.s_Op_Mark)
                {
                    resQry.s_stat = "U";
                    s_type_no = "7";
                    s_modi_des = "启用";
                    IsActive = "N";
                }

                // 写card_forbin表记录
                CardForbinDto dtoCardForbin = new CardForbinDto();
                dtoCardForbin.s_card_no = resQry.s_card_no;
                dtoCardForbin.create_date = DateTime.Now;
                dtoCardForbin.IsActive = IsActive;
                dtoCardForbin.send_to_hq = "N";
                dtoCardForbin.s_branch_no = s_branch_no;
                dtoCardForbin.s_branch_id = dto.s_branch_id;

                // 解挂、启用的操作，要先删除原来的
                if (IsActive == "N") 
                {
                    // 插入会员卡禁用历史记录数据
                    var resultDelCF = await _CardDbProvider.Deleteable<CardForbinEntity>()
                        .Where(x => x.s_branch_id == dto.s_branch_id && x.s_card_no == resQry.s_card_no && x.IsActive == "Y")
                        .ExecuteCommandAsync();
                }

                // 插入会员卡禁用历史记录数据
                var resultAddCF = await _CardDbProvider.Insertable<CardForbinEntity>(dtoCardForbin).ExecuteReturnEntityAsync();
                if (null == resultAddCF || resultAddCF.Billid < 1)
                    throw new Exception("会员卡禁用历史记录数据保存异常");

                // 执行会员卡状态数据
                var result = await _CardDbProvider.Updateable<RegcardEntity>(resQry).ExecuteCommandAsync();
                if (result < 1)
                    throw new Exception("会员卡数据更新异常");

                // 写card_forbin表记录
                ModiCardDto dtoModiCard = new ModiCardDto();
                dtoModiCard.s_account_no = resQry.s_account_no;
                dtoModiCard.s_type_no = s_type_no;
                dtoModiCard.s_modi_des = s_modi_des;
                dtoModiCard.s_old_no = resQry.s_print_no;
                dtoModiCard.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoModiCard.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoModiCard.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoModiCard.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoModiCard.s_set_work = dto.s_set_work;
                dtoModiCard.s_meno = s_reason;
                dtoModiCard.s_member_info_id = resQry.s_member_info_id;
                dtoModiCard.s_branch_id = dto.s_branch_id;
                
                // 插入会员卡操作历史记录数据
                var resultAddMC = await _CardDbProvider.Insertable<ModiCardEntity>(dtoModiCard).ExecuteReturnEntityAsync();
                if (null == resultAddMC || resultAddMC.AutoID < 1)
                    throw new Exception("会员卡操作历史记录数据保存异常");

                _CardDbProvider.CommitTran();
            }
            catch (Exception ex)
            {
                _CardDbProvider.RollbackTran();
                throw ex;
            }

            return ApiResultDto.ToResultSuccess(data: true);
        }

        /// <summary>
        /// 会员卡取消发卡
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> CancelRegcardAsync(string sCardDBConn, RegcardCancelDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "该会员卡不存在");
            }

            _CardDbProvider.BeginTran();
            try
            {
                // 营业日期不是今天的不能取消
                if (null != resQry.s_set_date 
                    && null != resQry.s_set_time
                    && 0 < DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd HH:mm:ss").CompareTo(resQry.s_set_date + " " + resQry.s_set_time))
                    throw new Exception("发卡时间已超过24小时，不允许取消发卡");

                // 有消费信息的，不允许取消
                if (resQry.n_use_tot != 0)
                    throw new Exception("卡上有消费信息，不能取消发卡");

                // 查看是否有充值记录
                var resQryCA = await _CardDbProvider.Queryable<CardAccountEntity>()
                    .Where(x => x.s_account_no == resQry.s_account_no 
                               && x.n_caprmb != 0
                               && (x.s_dep_name == "会员卡转入" || x.s_dep_name == "赠送转入" || x.s_dep_name == "会员卡转出"|| x.s_dep_name == "赠送转出")
                          )
                    .ToListAsync();
                if (null != resQryCA && 0 < resQryCA.Count)
                    throw new Exception("该会员已有转卡金额，不能取消发卡");


                // 查看是否已使用了赠票
                string sql = $@"
                                    select tsd.id
                                    from   s_titcket_sell ts
                                           inner join s_ticket_sell_record         tsr  on tsr.s_titcket_sell_id = ts.id
                                           inner join s_ticket_sell_record_detail  tsd  on tsd.s_ticket_sell_record_id = tsr.id
                                    where  tsd.Is_used <> 'Y' 
                                      and  ts.regcard_id = {resQry.idno}
                                ";
                var resultUsedTicket = await _CardDbProvider.Ado.SqlQueryAsync<RegcardSearchResultDto>(sql);
                if(null != resultUsedTicket && 0 < resultUsedTicket.Count)
                    throw new Exception("该会员卡已有门票使用记录，不能取消发卡");

                sql = $@"
                            Delete From s_ticket_sell_record_detail  Where s_ticket_sell_record_id In(
                                    Select s_ticket_sell_record_id = tsr.id
                                    From   s_titcket_sell ts
                                           inner join s_ticket_sell_record tsr  on tsr.s_titcket_sell_id = ts.id
                                    Where  ts.regcard_id = {resQry.idno} and ts.pay_type = '3'
                             );

                            Delete From s_ticket_sell_record   Where s_titcket_sell_id In(
                                    Select s_titcket_sell_id = ts.id
                                    From   s_titcket_sell ts
                                    Where  ts.regcard_id = {resQry.idno} and ts.pay_type = '3'
                             );

                            Delete From s_titcket_sell Where regcard_id = {resQry.idno} and pay_type = '3';

                            Delete From regcard_times_details  Where s_account_no = {resQry.s_account_no};
                            Delete From regcard_times          Where s_account_no = {resQry.s_account_no};

                            Delete From cardaccount            Where s_account_no = {resQry.s_account_no};
                            Delete From regcard                Where s_account_no = {resQry.s_account_no};
                       ";

                var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
                if (result < 1)
                    throw new Exception("会员卡相关信息删除失败，取消发卡不成功");

                // 写card_forbin表记录
                string s_reason = (null == dto.s_set_work ? "" : dto.s_set_work) + "取消发卡" + resQry.s_print_no;
                ModiCardDto dtoModiCard = new ModiCardDto();
                dtoModiCard.s_account_no = resQry.s_account_no;
                dtoModiCard.s_type_no = "6";
                dtoModiCard.s_modi_des = "取消发卡";
                dtoModiCard.s_old_no = resQry.s_print_no;
                dtoModiCard.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoModiCard.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoModiCard.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoModiCard.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoModiCard.s_set_work = dto.s_set_work;
                dtoModiCard.s_meno = s_reason;
                dtoModiCard.s_member_info_id = resQry.s_member_info_id;
                dtoModiCard.s_branch_id = dto.s_branch_id;

                // 插入会员卡操作历史记录数据
                var resultAddMC = await _CardDbProvider.Insertable<ModiCardEntity>(dtoModiCard).ExecuteReturnEntityAsync();
                if (null == resultAddMC || resultAddMC.AutoID < 1)
                    throw new Exception("会员卡操作历史记录数据保存异常");

                _CardDbProvider.CommitTran();
            }
            catch (Exception ex)
            {
                _CardDbProvider.RollbackTran();
                throw ex;
            }

            return ApiResultDto.ToResultSuccess(data: true);
        }

        /// <summary>
        /// 会员卡补卡
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BuKaRegcardAsync(string sCardDBConn, RegcardBuKaDto dto)
        {
            if (string.IsNullOrEmpty(dto.s_card_no) || string.IsNullOrEmpty(dto.s_print_no))
            {
                return ApiResultDto.ToResultFail(data: false, msg: "会员卡新物理卡号、印刷卡号不能为空");
            }

            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "该会员卡不存在");
            }

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<RegcardEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id
                            && x.idno != dto.idno
                            && (
                                       (!string.IsNullOrEmpty(dto.s_card_no) && x.s_card_no == dto.s_card_no)
                                    || (!string.IsNullOrEmpty(dto.s_print_no) && x.s_print_no == dto.s_print_no)
                               )
                       )
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "卡号、印刷卡号重复");
            }

            _CardDbProvider.BeginTran();
            try
            {
                string sql = $@"
                                    update regcard 
                                       Set s_use_flag = 'Y' , 
                                           s_ren = 'Y' , 
                                           s_print_no = @s_print_no_new, 
                                           s_forbin = 'N' , 
                                           s_stat = 'U' , 
                                           s_card_no = @s_card_no_new
                                    Where idno ={resQry.idno}													
                                    ;

                                    update cardaccount 
                                       Set s_account_no = '{resQry.s_account_no}', 
                                           s_meno = '补卡从' + '{resQry.s_account_no}' 
                                    Where s_account_no = '{resQry.s_account_no}'
                                    ; 
                               ";

                List<SugarParameter> listSqlParam = new List<SugarParameter>();
                listSqlParam.Add(new SugarParameter("@s_print_no_new", dto.s_print_no));
                listSqlParam.Add(new SugarParameter("@s_card_no_new", dto.s_card_no));

                var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql, listSqlParam);
                if (result < 1)
                    throw new Exception("卡务及卡信息更新异常");

                // 写card_forbin表记录
                string s_reason = null;
                ModiCardDto dtoModiCard = new ModiCardDto();
                dtoModiCard.s_account_no = resQry.s_account_no;
                dtoModiCard.s_type_no = "1";
                dtoModiCard.s_modi_des = "补卡";
                dtoModiCard.s_old_no = resQry.s_print_no;
                dtoModiCard.s_account_to = resQry.s_account_no;
                dtoModiCard.s_new_no = dto.s_print_no;
                dtoModiCard.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoModiCard.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoModiCard.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoModiCard.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoModiCard.s_set_work = dto.s_set_work;
                dtoModiCard.s_meno = s_reason;
                dtoModiCard.s_member_info_id = resQry.s_member_info_id;
                dtoModiCard.s_branch_id = dto.s_branch_id;
                dtoModiCard.n_tot = resQry.n_card_tot;
                dtoModiCard.n_use = resQry.n_use_tot;
                dtoModiCard.n_blnce = resQry.n_blnce;
                dtoModiCard.n_use_cnt = resQry.n_use_cnt;

                // 插入会员卡操作历史记录数据
                var resultAddMC = await _CardDbProvider.Insertable<ModiCardEntity>(dtoModiCard).ExecuteReturnEntityAsync();
                if (null == resultAddMC || resultAddMC.AutoID < 1)
                    throw new Exception("会员卡操作历史记录数据保存异常");

                _CardDbProvider.CommitTran();
            }
            catch (Exception ex)
            {
                _CardDbProvider.RollbackTran();
                throw ex;
            }

            return ApiResultDto.ToResultSuccess(data: true);
        }

        /// <summary>
        /// 会员卡回收
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> HuiShouRegcardAsync(string sCardDBConn, RegcardHuiShouDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "该会员卡不存在");
            }

            _CardDbProvider.BeginTran();
            try
            {
                string s_branch_no = "";
                var resQryBranch = await _CardDbProvider.Queryable<BranchEntity>().Where(x => x.id == dto.s_branch_id).ToListAsync();
                if (null == resQryBranch || 0 == resQryBranch.Count)
                {
                    throw new Exception("分店ID不存在");
                }
                s_branch_no = resQryBranch[0].branch_no;

                // 查会员人员资料
                var resQryMember = await _CardDbProvider.Queryable<MemberInfoEntity>().Where(x => x.id == resQry.s_member_info_id).SingleAsync();
                string s_name = "";
                if (null != resQryMember)
                    s_name = resQryMember.member_name;

                #region 插入卡务中间表数据记录
                CardMidMsgDto dtoCardMidMsg = new CardMidMsgDto();
                dtoCardMidMsg.s_member_info_id = resQry.s_member_info_id;
                dtoCardMidMsg.s_card_account = resQry.s_account_no;
                dtoCardMidMsg.s_branch_no = s_branch_no;
                dtoCardMidMsg.s_card_no = resQry.s_card_no;
                dtoCardMidMsg.s_print_no = resQry.s_print_no;
                dtoCardMidMsg.s_account_to = "";
                dtoCardMidMsg.n_blnce = resQry.n_blnce;
                dtoCardMidMsg.n_use = resQry.n_blnce;
                dtoCardMidMsg.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardMidMsg.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardMidMsg.s_flag = "Y";
                dtoCardMidMsg.s_do_time = DateTime.Now;
                dtoCardMidMsg.n_times = 0;
                dtoCardMidMsg.auto_id_1 = 0;
                dtoCardMidMsg.s_back = "Y";
                dtoCardMidMsg.s_back_time = DateTime.Now;
                dtoCardMidMsg.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardMidMsg.Auto_ID_2 = 0;
                dtoCardMidMsg.n_send_charge = 0;
                dtoCardMidMsg.s_work_no = dto.s_set_work;
                dtoCardMidMsg.pay_type = "R"; // 回收
                dtoCardMidMsg.n_send_blnce = resQry.n_send_blnce;
                dtoCardMidMsg.n_fen_blnce = resQry.n_fen_blnce;
                dtoCardMidMsg.n_fen_use = resQry.n_fen_use;
                dtoCardMidMsg.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                dtoCardMidMsg.s_sales = "";
                dtoCardMidMsg.s_code = resQry.s_code;
                dtoCardMidMsg.s_card_type = resQry.s_card_type;
                dtoCardMidMsg.PolicyCode = resQry.PolicyCode;
                dtoCardMidMsg.paycode = "";
                dtoCardMidMsg.s_name = s_name;
                dtoCardMidMsg.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCMM = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsg).ExecuteReturnEntityAsync();
                if (null == resuAddCMM || resuAddCMM.auto_id < 1)
                    throw new Exception("卡务中间表数据保存异常");

                // 更新Auto_ID_2的值
                resuAddCMM.Auto_ID_2 = resuAddCMM.auto_id;
                var resultUpdateCMM = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMM).ExecuteCommandAsync();
                if (resultUpdateCMM < 1)
                    throw new Exception("卡务中间表数据更新ID异常");
                #endregion

                #region 插入卡务数据记录
                CardAccountDto dtoCardAccount = new CardAccountDto();
                dtoCardAccount.s_member_data_id = resQry.s_member_info_id;
                dtoCardAccount.s_account_no = resQry.s_account_no;
                dtoCardAccount.s_serial_no = 1;
                dtoCardAccount.s_cardno = resQry.s_print_no;
                dtoCardAccount.s_dep_name = "卡回收";
                dtoCardAccount.s_account_to = "";
                dtoCardAccount.n_capital = 0;
                dtoCardAccount.n_caprmb = 0;
                dtoCardAccount.n_charge = 0;
                dtoCardAccount.n_chg_tot = 0;
                dtoCardAccount.n_fen_charge = 0;
                dtoCardAccount.n_fen_send = 0;
                dtoCardAccount.n_fen_use = 0;
                dtoCardAccount.n_hour_cnt = 0;
                dtoCardAccount.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardAccount.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardAccount.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardAccount.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoCardAccount.s_set_work = dto.s_set_work;
                dtoCardAccount.s_emp = dto.s_set_work;
                dtoCardAccount.s_meno = "";
                dtoCardAccount.s_del = null;
                dtoCardAccount.s_type = null;
                dtoCardAccount.n_send_cnt = 0;
                dtoCardAccount.s_sale = "";
                dtoCardAccount.s_tax = "N";
                dtoCardAccount.s_change = "";
                dtoCardAccount.s_old_card = null;
                dtoCardAccount.member_id = null;
                dtoCardAccount.s_department = s_branch_no;
                dtoCardAccount.n_nowblnce = 0;
                dtoCardAccount.n_send_charge = 0;
                dtoCardAccount.n_add_cnt = 0;
                dtoCardAccount.s_branch_happen = s_branch_no;
                dtoCardAccount.card_mid_id = resuAddCMM.auto_id;
                dtoCardAccount.send_to_hq = "N";
                dtoCardAccount.n_send1_charge = null;
                dtoCardAccount.n_send_room_charge = null;
                dtoCardAccount.s_qrcode = null;
                dtoCardAccount.pay_type = "R";
                dtoCardAccount.add_type = "";
                dtoCardAccount.paycode = "";
                dtoCardAccount.QRcode = null;
                dtoCardAccount.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                dtoCardAccount.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCA = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccount).ExecuteCommandAsync();
                if (resuAddCA < 1)
                    throw new Exception("卡务数据保存异常");

                #endregion


                string sql = $@"
                                    update regcard 
                                       Set n_ablnce =0 , n_card_tot =0 , n_use_tot =0 , n_send_tot =0 , n_send_use =0 , s_stat ='R' , s_card_no ='' , s_print_no =''
                                    Where idno ={resQry.idno}													
                                    ;
                               ";
                var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
                if (result < 1)
                    throw new Exception("卡信息更新异常");

                // 写card_forbin表记录
                string s_reason = null;
                ModiCardDto dtoModiCard = new ModiCardDto();
                dtoModiCard.s_account_no = resQry.s_account_no;
                dtoModiCard.s_type_no = "3";
                dtoModiCard.s_modi_des = "回收";
                dtoModiCard.s_old_no = resQry.s_print_no;
                dtoModiCard.s_account_to = resQry.s_card_no;
                dtoModiCard.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoModiCard.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoModiCard.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoModiCard.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoModiCard.s_set_work = dto.s_set_work;
                dtoModiCard.s_member_info_id = resQry.s_member_info_id;
                dtoModiCard.s_branch_id = dto.s_branch_id;
                dtoModiCard.n_blnce = (decimal?)0.0;

                // 插入会员卡操作历史记录数据
                var resultAddMC = await _CardDbProvider.Insertable<ModiCardEntity>(dtoModiCard).ExecuteReturnEntityAsync();
                if (null == resultAddMC || resultAddMC.AutoID < 1)
                    throw new Exception("会员卡操作历史记录数据保存异常");

                _CardDbProvider.CommitTran();
            }
            catch (Exception ex)
            {
                _CardDbProvider.RollbackTran();
                throw ex;
            }

            return ApiResultDto.ToResultSuccess(data: true);
        }

        /// <summary>
        /// 会员卡退卡
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> TuiKaRegcardAsync(string sCardDBConn, RegcardTuiKaDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "该会员卡不存在");
            }

            _CardDbProvider.BeginTran();
            try
            {
                string s_branch_no = "";
                var resQryBranch = await _CardDbProvider.Queryable<BranchEntity>().Where(x => x.id == dto.s_branch_id).ToListAsync();
                if (null == resQryBranch || 0 == resQryBranch.Count)
                {
                    throw new Exception("分店ID不存在");
                }
                s_branch_no = resQryBranch[0].branch_no;

                if (dto.n_money_back.HasValue && (resQry.n_blnce - resQry.n_send_blnce) < dto.n_money_back)
                {
                    throw new Exception("退卡金额不允许大于剩余可用本金额");
                }

                // 查看卡类型允许回收余额
                var resQryCardType = await _CardDbProvider.Queryable<CardTypeEntity>()
                    .Where(x => x.id == dto.s_branch_id && x.s_code == resQry.s_card_type)
                    .ToListAsync();
                if (null == resQryCardType || 0 == resQryCardType.Count)
                {
                    throw new Exception("卡类型不存在");
                }
                if (dto.n_money_back.HasValue && dto.n_money_back.Value > 0
                    && (false == resQryCardType[0].n_tax_rate.HasValue || resQryCardType[0].n_tax_rate < dto.n_money_back.Value))
                {
                    throw new Exception("当前卡类型允许回收余额卡余额不足");
                }

                // 查会员人员资料
                var resQryMember = await _CardDbProvider.Queryable<MemberInfoEntity>().Where(x => x.id == resQry.s_member_info_id).SingleAsync();
                string s_name = "";
                if (null != resQryMember)
                    s_name = resQryMember.member_name;

                #region 退款记录

                #region 插入卡务中间表数据记录
                CardMidMsgDto dtoCardMidMsgTK = new CardMidMsgDto();
                dtoCardMidMsgTK.s_member_info_id = resQry.s_member_info_id;
                dtoCardMidMsgTK.s_card_account = resQry.s_account_no;
                dtoCardMidMsgTK.s_branch_no = s_branch_no;
                dtoCardMidMsgTK.s_card_no = resQry.s_card_no;
                dtoCardMidMsgTK.s_print_no = resQry.s_print_no;
                dtoCardMidMsgTK.s_account_to = "余额退卡";
                dtoCardMidMsgTK.n_blnce = resQry.n_blnce;
                dtoCardMidMsgTK.n_use = 0 - dto.n_money_back.Value;
                dtoCardMidMsgTK.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardMidMsgTK.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardMidMsgTK.s_flag = "Y";
                dtoCardMidMsgTK.s_do_time = DateTime.Now;
                dtoCardMidMsgTK.n_times = 1;
                dtoCardMidMsgTK.auto_id_1 = 0;
                dtoCardMidMsgTK.s_back = "Y";
                dtoCardMidMsgTK.s_back_time = DateTime.Now;
                dtoCardMidMsgTK.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardMidMsgTK.Auto_ID_2 = 0;
                dtoCardMidMsgTK.n_send_charge = 0;
                dtoCardMidMsgTK.s_work_no = dto.s_set_work;
                dtoCardMidMsgTK.pay_type = "P";
                dtoCardMidMsgTK.n_send_blnce = 0;
                dtoCardMidMsgTK.n_fen_blnce = 0;
                dtoCardMidMsgTK.n_fen_use = 0;
                dtoCardMidMsgTK.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                dtoCardMidMsgTK.s_sales = "";
                dtoCardMidMsgTK.s_code = resQry.s_code;
                dtoCardMidMsgTK.s_card_type = resQry.s_card_type;
                dtoCardMidMsgTK.PolicyCode = resQry.PolicyCode;
                dtoCardMidMsgTK.paycode = "";
                dtoCardMidMsgTK.s_name = s_name;
                dtoCardMidMsgTK.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCMMTK = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsgTK).ExecuteReturnEntityAsync();
                if (null == resuAddCMMTK || resuAddCMMTK.auto_id < 1)
                    throw new Exception("卡务中间表数据保存异常");

                // 更新Auto_ID_2的值
                resuAddCMMTK.Auto_ID_2 = resuAddCMMTK.auto_id;
                var resultUpdateCMMTK = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMMTK).ExecuteCommandAsync();
                if (resultUpdateCMMTK < 1)
                    throw new Exception("卡务中间表数据更新ID异常");
                #endregion

                #region 插入卡务数据记录
                CardAccountDto dtoCardAccountTK = new CardAccountDto();
                dtoCardAccountTK.s_member_data_id = resQry.s_member_info_id;
                dtoCardAccountTK.s_account_no = resQry.s_account_no;
                dtoCardAccountTK.s_serial_no = 1;
                dtoCardAccountTK.s_cardno = resQry.s_print_no;
                dtoCardAccountTK.s_dep_name = "余额退卡";
                dtoCardAccountTK.s_account_to = "";
                dtoCardAccountTK.n_capital = 0 - dto.n_money_back.Value;
                dtoCardAccountTK.n_caprmb = 0 - dto.n_money_back.Value;
                dtoCardAccountTK.n_charge = 0;
                dtoCardAccountTK.n_chg_tot = 0;
                dtoCardAccountTK.n_fen_charge = 0;
                dtoCardAccountTK.n_fen_send = 0;
                dtoCardAccountTK.n_fen_use = 0;
                dtoCardAccountTK.n_hour_cnt = 0;
                dtoCardAccountTK.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardAccountTK.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardAccountTK.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardAccountTK.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoCardAccountTK.s_set_work = dto.s_set_work;
                dtoCardAccountTK.s_emp = dto.s_set_work;
                dtoCardAccountTK.s_meno = dto.s_reason;
                dtoCardAccountTK.s_del = null;
                dtoCardAccountTK.s_type = null;
                dtoCardAccountTK.n_send_cnt = 0;
                dtoCardAccountTK.s_sale = "";
                dtoCardAccountTK.s_tax = "N";
                dtoCardAccountTK.s_change = "";
                dtoCardAccountTK.s_old_card = null;
                dtoCardAccountTK.member_id = null;
                dtoCardAccountTK.s_department = s_branch_no;
                dtoCardAccountTK.n_nowblnce = resQry.n_blnce;
                dtoCardAccountTK.n_send_charge = 0;
                dtoCardAccountTK.n_add_cnt = 0;
                dtoCardAccountTK.s_branch_happen = s_branch_no;
                dtoCardAccountTK.card_mid_id = dtoCardMidMsgTK.auto_id;
                dtoCardAccountTK.send_to_hq = "N";
                dtoCardAccountTK.n_send1_charge = null;
                dtoCardAccountTK.n_send_room_charge = null;
                dtoCardAccountTK.s_qrcode = null;
                dtoCardAccountTK.pay_type = "P";
                dtoCardAccountTK.add_type = "";
                dtoCardAccountTK.paycode = "";
                dtoCardAccountTK.QRcode = null;
                dtoCardAccountTK.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                dtoCardAccountTK.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCATK = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccountTK).ExecuteCommandAsync();
                if (resuAddCATK < 1)
                    throw new Exception("卡务数据保存异常");

                #endregion

                #endregion

                #region 退卡费记录

                // 退卡费 = 卡余额 - 当前退款金额
                decimal? n_TuiKaFei = resQry.n_blnce.Value - dto.n_money_back.Value;

                #region 插入卡务中间表数据记录
                CardMidMsgDto dtoCardMidMsgTF = new CardMidMsgDto();
                dtoCardMidMsgTF.s_member_info_id = resQry.s_member_info_id;
                dtoCardMidMsgTF.s_card_account = resQry.s_account_no;
                dtoCardMidMsgTF.s_branch_no = s_branch_no;
                dtoCardMidMsgTF.s_card_no = resQry.s_card_no;
                dtoCardMidMsgTF.s_print_no = resQry.s_print_no;
                dtoCardMidMsgTF.s_account_to = "余额退卡";
                dtoCardMidMsgTF.n_blnce = n_TuiKaFei;
                dtoCardMidMsgTF.n_use = n_TuiKaFei;
                dtoCardMidMsgTF.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardMidMsgTF.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardMidMsgTF.s_flag = "Y";
                dtoCardMidMsgTF.s_do_time = DateTime.Now;
                dtoCardMidMsgTF.n_times = 1;
                dtoCardMidMsgTF.auto_id_1 = 0;
                dtoCardMidMsgTF.s_back = "Y";
                dtoCardMidMsgTF.s_back_time = DateTime.Now;
                dtoCardMidMsgTF.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardMidMsgTF.Auto_ID_2 = 0;
                dtoCardMidMsgTF.n_send_charge = 0;
                dtoCardMidMsgTF.s_work_no = dto.s_set_work;
                dtoCardMidMsgTF.pay_type = "C";
                dtoCardMidMsgTF.n_send_blnce = resQry.n_fen_blnce;
                dtoCardMidMsgTF.n_fen_blnce = 0;
                dtoCardMidMsgTF.n_fen_use = 0;
                dtoCardMidMsgTF.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                dtoCardMidMsgTF.s_sales = "";
                dtoCardMidMsgTF.s_code = resQry.s_code;
                dtoCardMidMsgTF.s_card_type = resQry.s_card_type;
                dtoCardMidMsgTF.PolicyCode = resQry.PolicyCode;
                dtoCardMidMsgTF.paycode = "";
                dtoCardMidMsgTF.s_name = s_name;
                dtoCardMidMsgTF.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCMMTF = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsgTF).ExecuteReturnEntityAsync();
                if (null == resuAddCMMTF || resuAddCMMTF.auto_id < 1)
                    throw new Exception("卡务中间表数据保存异常");

                // 更新Auto_ID_2的值
                resuAddCMMTF.Auto_ID_2 = resuAddCMMTF.auto_id;
                var resultUpdateCMMTF = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMMTF).ExecuteCommandAsync();
                if (resultUpdateCMMTF < 1)
                    throw new Exception("卡务中间表数据更新ID异常");
                #endregion

                #region 插入卡务数据记录
                CardAccountDto dtoCardAccountTF = new CardAccountDto();
                dtoCardAccountTF.s_member_data_id = resQry.s_member_info_id;
                dtoCardAccountTF.s_account_no = resQry.s_account_no;
                dtoCardAccountTF.s_serial_no = 1;
                dtoCardAccountTF.s_cardno = resQry.s_print_no;
                dtoCardAccountTF.s_dep_name = "退卡费";
                dtoCardAccountTF.s_account_to = "";
                dtoCardAccountTF.n_capital = 0;
                dtoCardAccountTF.n_caprmb = 0;
                dtoCardAccountTF.n_charge = n_TuiKaFei;
                dtoCardAccountTF.n_chg_tot = 0;
                dtoCardAccountTF.n_fen_charge = 0;
                dtoCardAccountTF.n_fen_send = 0;
                dtoCardAccountTF.n_fen_use = 0;
                dtoCardAccountTF.n_hour_cnt = 0;
                dtoCardAccountTF.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardAccountTF.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardAccountTF.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardAccountTF.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoCardAccountTF.s_set_work = dto.s_set_work;
                dtoCardAccountTF.s_emp = dto.s_set_work;
                dtoCardAccountTF.s_meno = dto.s_reason;
                dtoCardAccountTF.s_del = null;
                dtoCardAccountTF.s_type = null;
                dtoCardAccountTF.n_send_cnt = 0;
                dtoCardAccountTF.s_sale = "";
                dtoCardAccountTF.s_tax = "N";
                dtoCardAccountTF.s_change = "";
                dtoCardAccountTF.s_old_card = null;
                dtoCardAccountTF.member_id = null;
                dtoCardAccountTF.s_department = s_branch_no;
                dtoCardAccountTF.n_nowblnce = n_TuiKaFei;
                dtoCardAccountTF.n_send_charge = 0;
                dtoCardAccountTF.n_add_cnt = 0;
                dtoCardAccountTF.s_branch_happen = s_branch_no;
                dtoCardAccountTF.card_mid_id = resuAddCMMTF.auto_id;
                dtoCardAccountTF.send_to_hq = "N";
                dtoCardAccountTF.n_send1_charge = null;
                dtoCardAccountTF.n_send_room_charge = null;
                dtoCardAccountTF.s_qrcode = null;
                dtoCardAccountTF.pay_type = "C";
                dtoCardAccountTF.add_type = "";
                dtoCardAccountTF.paycode = "";
                dtoCardAccountTF.QRcode = null;
                dtoCardAccountTF.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                dtoCardAccountTF.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCA = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccountTF).ExecuteCommandAsync();
                if (resuAddCA < 1)
                    throw new Exception("卡务数据保存异常");

                #endregion
                #endregion

                // 次卡退卡及主卡状态更新
                string sql = $@"
                                    Insert Into dbo.regcard_times_details 
		                                    ( s_account_no, S_no, n_balance, n_times, pay_id, s_sales, s_branch_happen, s_sys_date, s_set_date, 
		                                      s_set_work, s_set_calss, s_type, s_flag, s_start_date, s_forbin_date, n_use_times, n_add_cnt, s_account_to
		                                    ) 
                                    Select s_account_no, S_no, n_balance = 0 - n_balance , n_times = 0 - n_times_balance , pay_id = Null , 
                                           s_sales = @s_work_no, s_branch_happen = @s_branch_no, s_sys_date = @s_sys_date, s_set_date = GETDATE(), 
                                           s_set_work = @s_work_no, s_set_calss = @s_set_calss, s_type, s_flag = 'N', s_start_date = @s_set_date, 
                                           s_forbin_date = @s_forbin_date, n_use_times = n_times_balance,  n_add_cnt = NULL, s_account_to = '次卡退卡'  
                                    From   regcard_times 
                                    Where  s_account_no = '{resQry.s_account_no}' 
                                      And  n_times_balance > 0 
                                    ;

                                    update regcard 
                                       Set s_stat ='C', s_out ='Y' 
                                    Where idno ={resQry.idno}													
                                    ;
                               ";

                List<SugarParameter> listSqlParam = new List<SugarParameter>();
                listSqlParam.Add(new SugarParameter("@s_work_no", dto.s_set_work));
                listSqlParam.Add(new SugarParameter("@s_branch_no", s_branch_no));
                listSqlParam.Add(new SugarParameter("@s_sys_date", dto.loginBusinessDataDto.s_sys_date));
                listSqlParam.Add(new SugarParameter("@s_set_calss", dto.loginBusinessDataDto.s_set_class));
                listSqlParam.Add(new SugarParameter("@s_set_date", resQry.s_set_date));
                listSqlParam.Add(new SugarParameter("@s_forbin_date", resQry.s_forbin_date));

                var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql, listSqlParam);
                if (result < 1)
                    throw new Exception("卡信息更新异常");

                // 写card_forbin表记录
                string s_reason = dto.s_reason;
                ModiCardDto dtoModiCard = new ModiCardDto();
                dtoModiCard.s_account_no = resQry.s_account_no;
                dtoModiCard.s_type_no = "6";
                dtoModiCard.s_modi_des = "退卡";
                dtoModiCard.s_old_no = resQry.s_print_no;
                dtoModiCard.s_account_to = resQry.s_card_no;
                dtoModiCard.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoModiCard.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoModiCard.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoModiCard.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoModiCard.s_set_work = dto.s_set_work;
                dtoModiCard.s_member_info_id = resQry.s_member_info_id;
                dtoModiCard.s_branch_id = dto.s_branch_id;
                dtoModiCard.n_blnce = (decimal?)0.0;

                // 插入会员卡操作历史记录数据
                var resultAddMC = await _CardDbProvider.Insertable<ModiCardEntity>(dtoModiCard).ExecuteReturnEntityAsync();
                if (null == resultAddMC || resultAddMC.AutoID < 1)
                    throw new Exception("会员卡操作历史记录数据保存异常");

                _CardDbProvider.CommitTran();
            }
            catch (Exception ex)
            {
                _CardDbProvider.RollbackTran();
                throw ex;
            }

            return ApiResultDto.ToResultSuccess(data: true);
        }

        /// <summary>
        /// 会员卡转卡
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> ZhuanKaRegcardAsync(string sCardDBConn, RegcardZhuanKaDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查出原数据（转出会员卡）
            var resQry_from = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno_from).SingleAsync();
            if (null == resQry_from)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "被转出金额的会员卡不存在");
            }
            // 查出原数据（转入会员卡）
            var resQry_to = await _CardDbProvider.Queryable<RegcardEntity>().Where(x => x.idno == dto.idno_to).SingleAsync();
            if (null == resQry_to)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "被转入的会员卡不存在");
            }
            if ((false == dto.n_money_out.HasValue || 0 >= dto.n_money_out.Value ) && (false == dto.n_fen_out.HasValue || 0 >= dto.n_fen_out.Value)) 
            {
                return ApiResultDto.ToResultFail(data: false, msg: "转出金额、分数的值不能全部为空或0，至少要有一个要给出一个大于0的值");
            }
            if (resQry_from.n_blnce < dto.n_money_out || resQry_from.n_fen_blnce < dto.n_fen_out)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "转出金额、分数不能大于卡里面的剩余金额、分数");
            }

            _CardDbProvider.BeginTran();
            try
            {
                string s_branch_no = "";
                var resQryBranch = await _CardDbProvider.Queryable<BranchEntity>().Where(x => x.id == dto.s_branch_id).ToListAsync();
                if (null == resQryBranch || 0 == resQryBranch.Count)
                {
                    throw new Exception("分店ID不存在");
                }
                s_branch_no = resQryBranch[0].branch_no;

                // 查会员人员资料（转出卡的）
                var resQryMember_from = await _CardDbProvider.Queryable<MemberInfoEntity>().Where(x => x.id == resQry_from.s_member_info_id).SingleAsync();
                string s_name_from = "";
                if (null != resQryMember_from)
                    s_name_from = resQryMember_from.member_name;

                // 查会员人员资料（转入卡的）
                var resQryMember_to = await _CardDbProvider.Queryable<MemberInfoEntity>().Where(x => x.id == resQry_to.s_member_info_id).SingleAsync();
                string s_name_to = "";
                if (null != resQryMember_to)
                    s_name_to = resQryMember_to.member_name;

                #region 转出记录

                #region 插入卡务中间表数据记录
                CardMidMsgDto dtoCardMidMsgZC = new CardMidMsgDto();
                dtoCardMidMsgZC.s_member_info_id = resQry_from.s_member_info_id;
                dtoCardMidMsgZC.s_card_account = resQry_from.s_account_no;
                dtoCardMidMsgZC.s_branch_no = s_branch_no;
                dtoCardMidMsgZC.s_card_no = resQry_from.s_card_no;
                dtoCardMidMsgZC.s_print_no = resQry_from.s_print_no;
                dtoCardMidMsgZC.s_account_to = "会员卡转出";
                dtoCardMidMsgZC.n_blnce = resQry_from.n_blnce;
                dtoCardMidMsgZC.n_use = dto.n_money_out.Value;
                dtoCardMidMsgZC.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardMidMsgZC.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardMidMsgZC.s_flag = "Y";
                dtoCardMidMsgZC.s_do_time = DateTime.Now;
                dtoCardMidMsgZC.n_times = 1;
                dtoCardMidMsgZC.auto_id_1 = 0;
                dtoCardMidMsgZC.s_back = "Y";
                dtoCardMidMsgZC.s_back_time = DateTime.Now;
                dtoCardMidMsgZC.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardMidMsgZC.Auto_ID_2 = 0;
                dtoCardMidMsgZC.n_send_charge = 0;
                dtoCardMidMsgZC.s_work_no = dto.s_set_work;
                dtoCardMidMsgZC.pay_type = "P";
                dtoCardMidMsgZC.n_send_blnce = 0;
                dtoCardMidMsgZC.n_fen_blnce = 0;
                dtoCardMidMsgZC.n_fen_use = 0;
                dtoCardMidMsgZC.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                dtoCardMidMsgZC.s_sales = "";
                dtoCardMidMsgZC.s_code = resQry_from.s_code;
                dtoCardMidMsgZC.s_card_type = resQry_from.s_card_type;
                dtoCardMidMsgZC.PolicyCode = resQry_from.PolicyCode;
                dtoCardMidMsgZC.paycode = "";
                dtoCardMidMsgZC.s_name = s_name_from;
                dtoCardMidMsgZC.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCMMZC = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsgZC).ExecuteReturnEntityAsync();
                if (null == resuAddCMMZC || resuAddCMMZC.auto_id < 1)
                    throw new Exception("转出卡卡务中间表数据保存异常");

                // 更新Auto_ID_2的值
                resuAddCMMZC.Auto_ID_2 = resuAddCMMZC.auto_id;
                var resultUpdateCMMZC = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMMZC).ExecuteCommandAsync();
                if (resultUpdateCMMZC < 1)
                    throw new Exception("转出卡卡务中间表数据更新ID异常");
                #endregion

                #region 插入卡务数据记录
                CardAccountDto dtoCardAccountZC = new CardAccountDto();
                dtoCardAccountZC.s_member_data_id = resQry_from.s_member_info_id;
                dtoCardAccountZC.s_account_no = resQry_from.s_account_no;
                dtoCardAccountZC.s_serial_no = 1;
                dtoCardAccountZC.s_cardno = resQry_from.s_print_no;
                dtoCardAccountZC.s_dep_name = "会员卡转出";
                dtoCardAccountZC.s_account_to = "";
                dtoCardAccountZC.n_capital = 0 - dto.n_money_out.Value;
                dtoCardAccountZC.n_caprmb = 0 - dto.n_money_out.Value;
                dtoCardAccountZC.n_charge = 0;
                dtoCardAccountZC.n_chg_tot = 0;
                dtoCardAccountZC.n_fen_charge = 0;
                dtoCardAccountZC.n_fen_send = 0;
                dtoCardAccountZC.n_fen_use = dto.n_fen_out.Value;
                dtoCardAccountZC.n_hour_cnt = 0;
                dtoCardAccountZC.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardAccountZC.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardAccountZC.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardAccountZC.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoCardAccountZC.s_set_work = dto.s_set_work;
                dtoCardAccountZC.s_emp = dto.s_set_work;
                dtoCardAccountZC.s_meno = "目标:" + resQry_to.s_print_no;
                dtoCardAccountZC.s_del = null;
                dtoCardAccountZC.s_type = null;
                dtoCardAccountZC.n_send_cnt = 0;
                dtoCardAccountZC.s_sale = "";
                dtoCardAccountZC.s_tax = "N";
                dtoCardAccountZC.s_change = "";
                dtoCardAccountZC.s_old_card = null;
                dtoCardAccountZC.member_id = null;
                dtoCardAccountZC.s_department = s_branch_no;
                dtoCardAccountZC.n_nowblnce = resQry_from.n_blnce;
                dtoCardAccountZC.n_send_charge = 0;
                dtoCardAccountZC.n_add_cnt = 0;
                dtoCardAccountZC.s_branch_happen = s_branch_no;
                dtoCardAccountZC.card_mid_id = dtoCardMidMsgZC.auto_id;
                dtoCardAccountZC.send_to_hq = "N";
                dtoCardAccountZC.n_send1_charge = null;
                dtoCardAccountZC.n_send_room_charge = null;
                dtoCardAccountZC.s_qrcode = null;
                dtoCardAccountZC.pay_type = "P";
                dtoCardAccountZC.add_type = "";
                dtoCardAccountZC.paycode = "";
                dtoCardAccountZC.QRcode = null;
                dtoCardAccountZC.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                dtoCardAccountZC.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCAZC = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccountZC).ExecuteCommandAsync();
                if (resuAddCAZC < 1)
                    throw new Exception("转出卡的卡务数据保存异常");

                #endregion

                #region 生成短信记录
                if (!string.IsNullOrEmpty(resQry_from.remind_add) && "Y" == resQry_from.remind_add.Trim().ToUpper()
                    && null != resQryMember_from 
                    && !string.IsNullOrEmpty(resQryMember_from.telephone) 
                    && resQryMember_from.telephone.Length > 10)
                {
                    string sMoHuPrintNo = resQry_from.s_print_no;
                    if (sMoHuPrintNo.Length > 4)
                    {
                        sMoHuPrintNo = sMoHuPrintNo.Substring(sMoHuPrintNo.Length - 4, 4);
                    }
                    string sDate = DateTime.Now.ToString("yyyy-MM-dd");
                    GsmSendMobileDto dtoGsmSendMobile_from = new GsmSendMobileDto();
                    dtoGsmSendMobile_from.create_date = DateTime.Now;
                    dtoGsmSendMobile_from.d_hotel_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoGsmSendMobile_from.n_cnt = 0;
                    dtoGsmSendMobile_from.s_flag = "N";
                    dtoGsmSendMobile_from.s_send_flag = "N";
                    dtoGsmSendMobile_from.s_branch_id = dto.s_branch_id;
                    dtoGsmSendMobile_from.s_mobile = resQryMember_from.telephone;
                    dtoGsmSendMobile_from.s_message = "尊敬的客户，您好，您的会员卡***" + sMoHuPrintNo + "于" + sDate + "转出：" + dto.n_money_out + "元，余额为：" + (resQry_from.n_blnce - dto.n_money_out) + "元。";

                    // 保存短信记录到短信表
                    var resuAddGsm_From = await _CardDbProvider.Insertable<GsmSendMobileEntity>(dtoGsmSendMobile_from).ExecuteCommandAsync();
                    if (resuAddCAZC < 1)
                        throw new Exception("转出卡短信记录保存异常");
                }
                #endregion

                #endregion

                #region 转入记录

                #region 插入卡务中间表数据记录
                CardMidMsgDto dtoCardMidMsgZR = new CardMidMsgDto();
                dtoCardMidMsgZR.s_member_info_id = resQry_to.s_member_info_id;
                dtoCardMidMsgZR.s_card_account = resQry_to.s_account_no;
                dtoCardMidMsgZR.s_branch_no = s_branch_no;
                dtoCardMidMsgZR.s_card_no = resQry_to.s_card_no;
                dtoCardMidMsgZR.s_print_no = resQry_to.s_print_no;
                dtoCardMidMsgZR.s_account_to = "会员卡转入";
                dtoCardMidMsgZR.n_blnce = resQry_to.n_blnce;
                dtoCardMidMsgZR.n_use = 0 - dto.n_money_out.Value;
                dtoCardMidMsgZR.s_use_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardMidMsgZR.s_use_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardMidMsgZR.s_flag = "Y";
                dtoCardMidMsgZR.s_do_time = DateTime.Now;
                dtoCardMidMsgZR.n_times = 1;
                dtoCardMidMsgZR.auto_id_1 = 0;
                dtoCardMidMsgZR.s_back = "Y";
                dtoCardMidMsgZR.s_back_time = DateTime.Now;
                dtoCardMidMsgZR.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardMidMsgZR.Auto_ID_2 = 0;
                dtoCardMidMsgZR.n_send_charge = 0;
                dtoCardMidMsgZR.s_work_no = dto.s_set_work;
                dtoCardMidMsgZR.pay_type = "P";
                dtoCardMidMsgZR.n_send_blnce = 0;
                dtoCardMidMsgZR.n_fen_blnce = 0;
                dtoCardMidMsgZR.n_fen_use = 0;
                dtoCardMidMsgZR.S_SET_CLASS = dto.loginBusinessDataDto.s_set_class;
                dtoCardMidMsgZR.s_sales = "";
                dtoCardMidMsgZR.s_code = resQry_to.s_code;
                dtoCardMidMsgZR.s_card_type = resQry_to.s_card_type;
                dtoCardMidMsgZR.PolicyCode = resQry_to.PolicyCode;
                dtoCardMidMsgZR.paycode = "";
                dtoCardMidMsgZR.s_name = s_name_to;
                dtoCardMidMsgZR.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCMMZR = await _CardDbProvider.Insertable<CardMidMsgEntity>(dtoCardMidMsgZR).ExecuteReturnEntityAsync();
                if (null == resuAddCMMZR || resuAddCMMZR.auto_id < 1)
                    throw new Exception("转入卡卡务中间表数据保存异常");

                // 更新Auto_ID_2的值
                resuAddCMMZR.Auto_ID_2 = resuAddCMMZR.auto_id;
                var resultUpdateCMMZR = await _CardDbProvider.Updateable<CardMidMsgEntity>(resuAddCMMZR).ExecuteCommandAsync();
                if (resultUpdateCMMZR < 1)
                    throw new Exception("转入卡卡务中间表数据更新ID异常");
                #endregion

                #region 插入卡务数据记录
                CardAccountDto dtoCardAccountZR = new CardAccountDto();
                dtoCardAccountZR.s_member_data_id = resQry_to.s_member_info_id;
                dtoCardAccountZR.s_account_no = resQry_to.s_account_no;
                dtoCardAccountZR.s_serial_no = 1;
                dtoCardAccountZR.s_cardno = resQry_to.s_print_no;
                dtoCardAccountZR.s_dep_name = "会员卡转入";
                dtoCardAccountZR.s_account_to = "";
                dtoCardAccountZR.n_capital = dto.n_money_out.Value;
                dtoCardAccountZR.n_caprmb = dto.n_money_out.Value;
                dtoCardAccountZR.n_charge = 0;
                dtoCardAccountZR.n_chg_tot = 0;
                dtoCardAccountZR.n_fen_charge = 0;
                dtoCardAccountZR.n_fen_send = 0;
                dtoCardAccountZR.n_fen_use = 0 - dto.n_fen_out.Value;
                dtoCardAccountZR.n_hour_cnt = 0;
                dtoCardAccountZR.s_sys_date = dto.loginBusinessDataDto.s_sys_date;
                dtoCardAccountZR.s_set_date = DateTime.Now.ToString("yyyy-MM-dd");
                dtoCardAccountZR.s_set_time = DateTime.Now.ToString("HH:mm:ss");
                dtoCardAccountZR.s_set_class = dto.loginBusinessDataDto.s_set_class;
                dtoCardAccountZR.s_set_work = dto.s_set_work;
                dtoCardAccountZR.s_emp = dto.s_set_work;
                dtoCardAccountZR.s_meno = "来源:" + resQry_from.s_print_no;
                dtoCardAccountZR.s_del = null;
                dtoCardAccountZR.s_type = null;
                dtoCardAccountZR.n_send_cnt = 0;
                dtoCardAccountZR.s_sale = "";
                dtoCardAccountZR.s_tax = "N";
                dtoCardAccountZR.s_change = "";
                dtoCardAccountZR.s_old_card = null;
                dtoCardAccountZR.member_id = null;
                dtoCardAccountZR.s_department = s_branch_no;
                dtoCardAccountZR.n_nowblnce = resQry_to.n_blnce;
                dtoCardAccountZR.n_send_charge = 0;
                dtoCardAccountZR.n_add_cnt = 0;
                dtoCardAccountZR.s_branch_happen = s_branch_no;
                dtoCardAccountZR.card_mid_id = resuAddCMMZR.auto_id;
                dtoCardAccountZR.send_to_hq = "N";
                dtoCardAccountZR.n_send1_charge = null;
                dtoCardAccountZR.n_send_room_charge = null;
                dtoCardAccountZR.s_qrcode = null;
                dtoCardAccountZR.pay_type = "C";
                dtoCardAccountZR.add_type = "";
                dtoCardAccountZR.paycode = "";
                dtoCardAccountZR.QRcode = null;
                dtoCardAccountZR.OutletNo = dto.loginBusinessDataDto.sOutletNo;
                dtoCardAccountZR.s_branch_id = dto.s_branch_id;

                // 数据插入数据库表
                var resuAddCAZR = await _CardDbProvider.Insertable<CardAccountEntity>(dtoCardAccountZR).ExecuteCommandAsync();
                if (resuAddCAZR < 1)
                    throw new Exception("转入卡务数据保存异常");

                #region 生成短信记录
                if (!string.IsNullOrEmpty(resQry_to.remind_add) && "Y" == resQry_to.remind_add.Trim().ToUpper()
                    && null != resQryMember_to
                    && !string.IsNullOrEmpty(resQryMember_to.telephone)
                    && resQryMember_to.telephone.Length > 10)
                {
                    string sMoHuPrintNo = resQry_to.s_print_no;
                    if (sMoHuPrintNo.Length > 4)
                    {
                        sMoHuPrintNo = sMoHuPrintNo.Substring(sMoHuPrintNo.Length - 4, 4);
                    }
                    string sDate = DateTime.Now.ToString("yyyy-MM-dd");
                    GsmSendMobileDto dtoGsmSendMobile_to = new GsmSendMobileDto();
                    dtoGsmSendMobile_to.create_date = DateTime.Now;
                    dtoGsmSendMobile_to.d_hotel_date = dto.loginBusinessDataDto.s_sys_date;
                    dtoGsmSendMobile_to.n_cnt = 0;
                    dtoGsmSendMobile_to.s_flag = "N";
                    dtoGsmSendMobile_to.s_send_flag = "N";
                    dtoGsmSendMobile_to.s_branch_id = dto.s_branch_id;
                    dtoGsmSendMobile_to.s_mobile = resQryMember_to.telephone;
                    dtoGsmSendMobile_to.s_message = "尊敬的客户，您好，您的会员卡***" + sMoHuPrintNo + "于" + sDate + "转入：" + dto.n_money_out + "元，余额为：" + (resQry_to.n_blnce + dto.n_money_out) + "元。";

                    // 保存短信记录到短信表
                    var resuAddGsm_to = await _CardDbProvider.Insertable<GsmSendMobileEntity>(dtoGsmSendMobile_to).ExecuteCommandAsync();
                    if (resuAddGsm_to < 1)
                        throw new Exception("转入卡短信记录保存异常");
                }
                #endregion

                #endregion

                #endregion

                _CardDbProvider.CommitTran();
            }
            catch (Exception ex)
            {
                _CardDbProvider.RollbackTran();
                throw ex;
            }

            return ApiResultDto.ToResultSuccess(data: true);
        }
    }
}
﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 优惠政策与微信劵关联设置接口实现
    /// </summary>
    public class CardPolicyTicketService : ICardPolicyTicketInterface
    {
        /// <summary>
        /// 新增优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddCardPolicyTicketAsync(string sCardDBConn, CardPolicyTicketDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<CardPolicyTicketEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.PolicyCode == dto.PolicyCode && x.TypeCode == dto.TypeCode)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "关联设置数据重复");
            }

            // 执行添加
            var result = await _CardDbProvider.Insertable<CardPolicyTicketEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditCardPolicyTicketAsync(string sCardDBConn, CardPolicyTicketDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<CardPolicyTicketEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.PolicyCode == dto.PolicyCode && x.TypeCode == dto.TypeCode)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "关联设置数据重复");
            }

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<CardPolicyTicketEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await _CardDbProvider.Updateable<CardPolicyTicketEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<CardPolicyTicketSearchResultDto>>> QueryCardPolicyTicketAsync(string sCardDBConn, CardPolicyTicketSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and cpt.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and cpt.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.PolicyCode))
            {
                sWhere += " and cpt.PolicyCode = @PolicyCode";
                listSqlParam.Add(new SugarParameter("@PolicyCode", dto.PolicyCode));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.TypeCode))
            {
                sWhere += " and cpt.TypeCode = @TypeCode";
                listSqlParam.Add(new SugarParameter("@TypeCode", dto.TypeCode));
            }
            // 优惠政策信息查询
            if (null != dto && dto.s_policy_id.HasValue)
            {
                sWhere += " and cp.id = @s_policy_id";
                listSqlParam.Add(new SugarParameter("@s_policy_id", dto.s_policy_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_policy_name))
            {
                sWhere += " and cp.s_describe like '%' + @s_policy_name + '%'";
                listSqlParam.Add(new SugarParameter("@s_policy_name", dto.s_policy_name));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.IsActive))
            {
                sWhere += " and cpt.IsActive = @IsActive";
                listSqlParam.Add(new SugarParameter("@IsActive", dto.IsActive));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select  iCount = count(*)
                                    from    card_policy_ticket cpt
                                            left join card_policy   cp on cpt.s_branch_id = cp.s_branch_id and cpt.PolicyCode = cp.s_code
                                            left join s_ticket_set  ts on cpt.s_branch_id = ts.s_branch_id and cpt.TypeCode = ts.ticket_code
                                    where   1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by cpt.id desc) as row_no,
									        cpt.id, cpt.PolicyCode, cpt.TypeCode, cpt.N_Count, cpt.n_day, cpt.Amount, cpt.IsActive, cpt.memo, 
									        cpt.s_branch_id, cpt.create_date, cpt.create_user, cpt.update_date, cpt.update_user,
                                            s_policy_id = cp.id, s_policy_name = cp.s_describe,
									        ticket_id = ts.id,
									        ticket_name = ts.ticket_name
                                    from    card_policy_ticket cpt
                                            left join card_policy   cp on cpt.s_branch_id = cp.s_branch_id and cpt.PolicyCode = cp.s_code
                                            left join s_ticket_set  ts on cpt.s_branch_id = ts.s_branch_id and cpt.TypeCode = ts.ticket_code
                                    where   1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                   ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<CardPolicyTicketSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<CardPolicyTicketSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveCardPolicyTicketAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = "delete from  card_policy_ticket  where id=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveCardPolicyTicketAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  card_policy_ticket  where id in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

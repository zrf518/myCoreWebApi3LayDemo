﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 短信发送接口实现
    /// </summary>
    public class GsmSendMobileService : IGsmSendMobileInterface
    {
        /// <summary>
        /// 新增短信发送
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddGsmSendMobileAsync(string sCardDBConn, List<GsmSendMobileEntity> dtos)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 执行添加
            var result = await _CardDbProvider.Insertable<GsmSendMobileEntity>(dtos.ToArray()).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 查询短信发送
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<GsmSendMobileSearchResultDto>>> QueryGsmSendMobileAsync(string sCardDBConn, GsmSendMobileSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and gsm.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.autoid != 0)
            {
                sWhere += " and gsm.autoid = @autoid";
                listSqlParam.Add(new SugarParameter("@autoid", dto.autoid));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_mobile))
            {
                sWhere += " and gsm.s_mobile = @s_mobile";
                listSqlParam.Add(new SugarParameter("@s_mobile", dto.s_mobile));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_account_no))
            {
                sWhere += " and gsm.s_account_no = @s_account_no";
                listSqlParam.Add(new SugarParameter("@s_account_no", dto.s_account_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_message))
            {
                sWhere += " and gsm.s_message like '%' + @s_message + '%'";
                listSqlParam.Add(new SugarParameter("@s_message", dto.s_message));
            }
            if (null != dto && dto.n_cnt.HasValue)
            {
                sWhere += " and gsm.n_cnt = @n_cnt";
                listSqlParam.Add(new SugarParameter("@n_cnt", dto.n_cnt));
            }
            // 发送时间（开始）
            if (null != dto && dto.d_send_date_start.HasValue)
            {
                sWhere += " and gsm.d_send_date >= @d_send_date_start";
                listSqlParam.Add(new SugarParameter("@d_send_date_start", dto.d_send_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            // 发送时间（结束）
            if (null != dto && dto.d_send_date_end.HasValue)
            {
                sWhere += " and gsm.d_send_date <= @d_send_date_end";
                listSqlParam.Add(new SugarParameter("@d_send_date_end", dto.d_send_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            // 创建时间（开始）
            if (null != dto && dto.create_date_start.HasValue)
            {
                sWhere += " and gsm.create_date >= @create_date_start";
                listSqlParam.Add(new SugarParameter("@create_date_start", dto.create_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            // 创建时间（结束）
            if (null != dto && dto.create_date_end.HasValue)
            {
                sWhere += " and gsm.create_date <= @create_date_end";
                listSqlParam.Add(new SugarParameter("@create_date_end", dto.create_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            // 营业日期
            if (null != dto && !string.IsNullOrEmpty(dto.d_hotel_date))
            {
                sWhere += " and gsm.d_hotel_date = @d_hotel_date";
                listSqlParam.Add(new SugarParameter("@d_hotel_date", dto.d_hotel_date));
            }
            // 是否已发送
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_flag))
            {
                sWhere += " and gsm.s_flag = @s_flag";
                listSqlParam.Add(new SugarParameter("@s_flag", dto.s_flag));
            }
            // 发送标志
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_send_flag))
            {
                sWhere += " and gsm.s_send_flag = @s_send_flag";
                listSqlParam.Add(new SugarParameter("@s_send_flag", dto.s_send_flag));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   gsm_send_mobile gsm
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by gsm.autoid desc) as row_no,
                                           gsm.autoid, gsm.s_mobile, gsm.s_group, gsm.n_cnt, gsm.s_flag, gsm.d_send_date, gsm.s_message, 
                                           gsm.d_hotel_date, gsm.s_account_no, gsm.s_send_flag, gsm.s_branch_id, gsm.create_date
                                    from   gsm_send_mobile gsm
                                    where  1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<GsmSendMobileSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<GsmSendMobileSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除短信发送
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveGsmSendMobileAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = "delete from  gsm_send_mobile  where autoid=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除短信发送
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveGsmSendMobileAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  gsm_send_mobile  where autoid in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}
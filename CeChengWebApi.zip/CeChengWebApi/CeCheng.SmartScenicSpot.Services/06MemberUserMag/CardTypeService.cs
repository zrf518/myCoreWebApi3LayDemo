﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 卡类接口实现
    /// </summary>
    public class CardTypeService : ICardTypeInterface
    {
        /// <summary>
        /// 新增卡类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddCardTypeAsync(string sCardDBConn, CardTypeDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<CardTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.s_code == dto.s_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await _CardDbProvider.Insertable<CardTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑卡类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditCardTypeAsync(string sCardDBConn, CardTypeDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            // 查看编码是否有重复
            var resQryTestCode = await _CardDbProvider.Queryable<CardTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.s_code == dto.s_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await _CardDbProvider.Queryable<CardTypeEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await _CardDbProvider.Updateable<CardTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询卡类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<CardTypeSearchResultDto>>> QueryCardTypeAsync(string sCardDBConn, CardTypeSearchParamDto dto)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and ct.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and ct.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_code))
            {
                sWhere += " and ct.s_code = @s_code";
                listSqlParam.Add(new SugarParameter("@s_code", dto.s_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_describe))
            {
                sWhere += " and ct.s_describe like '%' + @s_describe + '%'";
                listSqlParam.Add(new SugarParameter("@s_describe", dto.s_describe));
            }
            // 卡大类编码
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_type))
            {
                sWhere += " and ct.s_type = @s_type";
                listSqlParam.Add(new SugarParameter("@s_type", dto.s_type));
            }
            if (null != dto && dto.card_big_type_id.HasValue)
            {
                sWhere += " and cbt.id = @card_big_type_id";
                listSqlParam.Add(new SugarParameter("@card_big_type_id", dto.card_big_type_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.card_big_type_name))
            {
                sWhere += " and cbt.s_name like '%' + @card_big_type_name + '%'";
                listSqlParam.Add(new SugarParameter("@card_big_type_name", dto.card_big_type_name));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.isactive))
            {
                sWhere += " and ct.isactive = @isactive";
                listSqlParam.Add(new SugarParameter("@isactive", dto.isactive));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   card_type ct
                                           left join card_big_type cbt on cbt.s_branch_id = ct.s_branch_id and cbt.s_no = ct.s_type
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by ct.id desc) as row_no,
                                           ct.Id, ct.s_code, ct.s_type, ct.s_describe, ct.s_print_no, ct.s_insider, ct.n_saletc, ct.s_issn, 
                                           ct.s_iscy, ct.s_isht, ct.isactive, ct.s_curdayamt, ct.s_key, ct.n_curdayamt, ct.n_tax_rate, 
                                           ct.n_sort, ct.n_charge, ct.n_pay, ct.n_room_disc, ct.n_sauna_disc, ct.n_din_disc, ct.n_dance_disc, 
                                           ct.n_chess_disc, ct.n_chg_unit, ct.n_snd_unit, ct.s_card_no, ct.s_card_end, ct.n_send_day, 
                                           ct.n_sauna_cnt, ct.n_rate_cnt, ct.n_price, ct.n_miss_add, ct.n_cuozao_cnt, ct.n_card_disc, 
                                           ct.s_ktype, ct.s_WxHYCardCode, ct.s_WxHYHuoJiaPageUrl, ct.memo, ct.S_Branch_Id, ct.Create_Date, 
                                           ct.Create_User, ct.Update_Date, ct.Update_User,
                                           card_big_type_id=cbt.id,
                                           card_big_type_name=cbt.s_name
                                    from   card_type ct
                                           left join card_big_type cbt on cbt.s_branch_id = ct.s_branch_id and cbt.s_no = ct.s_type
                                    where  1=1
                                ";
            #endregion

            int iCount = await _CardDbProvider.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await _CardDbProvider.Ado.SqlQueryAsync<CardTypeSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<CardTypeSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除卡类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveCardTypeAsync(string sCardDBConn, string sUserWorkNo, int id)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sql = "delete from  card_type  where id=" + id;
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除卡类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveCardTypeAsync(string sCardDBConn, string sUserWorkNo, List<int> ids)
        {
            SqlSugarClient _CardDbProvider = new CeChengCardDBHelper(sCardDBConn).DbProvider;

            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  card_type  where id in (" + sWhere + ")";
            var result = await _CardDbProvider.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

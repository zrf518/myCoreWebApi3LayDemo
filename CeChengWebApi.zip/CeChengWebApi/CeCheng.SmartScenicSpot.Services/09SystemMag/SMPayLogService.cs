﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using MySqlX.XDevAPI.Common;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 扫码付款记录接口实现
    /// </summary>
    public class SMPayLogService : ISMPayLogInterface
    {
        /// <summary>
        /// 新增扫码付款记录
        /// </summary>
        /// <returns></returns>
        public ApiResultDto AddSMPayLog(SMPayLogEntity dto)
        {
            // 判读是否是付款操作，是付款操作就要判断交易流水号是否重复了，重复了就不让通过
            if (true == dto.Pay_amount.HasValue && dto.Pay_amount.Value > 0 && dto.Refund_Amount <= 0)
            {
                // 查看编码是否有重复
                var resQryTestCode = DbScoped.Sugar.Queryable<SMPayLogEntity>()
                    .Where(x => x.s_branch_id == dto.s_branch_id && x.out_trade_no == dto.out_trade_no)
                    .ToList();
                if (null != resQryTestCode && 0 < resQryTestCode.Count)
                {
                    return ApiResultDto.ToResultFail(data: false, msg: "策城流水号重复");
                }
            }

            // 执行添加
            var result = DbScoped.Sugar.Insertable<SMPayLogEntity>(dto).ExecuteReturnEntity();
            if (null != result && result.id > 0)
                return ApiResultDto.ToResultSuccess(data: result);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑扫码付款记录
        /// </summary>
        /// <returns></returns>
        public ApiResultDto EditSMPayLog(SMPayLogEntity dto)
        {
            // 查出原数据
            var resQry = DbScoped.Sugar.Queryable<SMPayLogEntity>().Where(x => x.id == dto.id).Single();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }

            // 执行更新
            var result = DbScoped.Sugar.Updateable<SMPayLogEntity>(dto).ExecuteCommand();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 根据策城交易流水号查询付款记录
        /// </summary>
        /// <returns></returns>
        public ApiResultDto QuerySMPayLogByOutTradeNo(SMPayLogDto dto)
        {
            if (null == dto || string.IsNullOrEmpty(dto.out_trade_no))
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录不存在");
            }

            var resQry = DbScoped.Sugar.Queryable<SMPayLogEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.out_trade_no == dto.out_trade_no && x.Pay_amount > 0 && x.Refund_Amount <= 0)
                .Single();
            if (null != resQry)
                return ApiResultDto.ToResultSuccess(data: resQry);

            return ApiResultDto.ToResultFail(data: false, msg: "记录不存在");
        }

        /// <summary>
        /// 根据策城交易流水号查询已成功退款记录
        /// </summary>
        /// <returns></returns>
        public ApiResultDto<List<SMPayLogEntity>> QuerySMRefundLogByOutTradeNo(SMPayLogDto dto)
        {
            if (null == dto || string.IsNullOrEmpty(dto.out_trade_no))
            {
                return ApiResultDto<List<SMPayLogEntity>>.ToResultFail(data: null, msg: "记录不存在");
            }

            var resQry = DbScoped.Sugar.Queryable<SMPayLogEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.out_trade_no == dto.out_trade_no && x.IsActive == "Y" && x.Refund_Amount > 0)
                .ToList();
            if (null != resQry)
                return ApiResultDto<List<SMPayLogEntity>>.ToResultSuccess(data: resQry);

            return ApiResultDto<List<SMPayLogEntity>>.ToResultFail(data: null, msg: "记录不存在");
        }

        /// <summary>
        /// 查询扫码付款记录
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SMPayLogSearchResultDto>>> QuerySMPayLogAsync(SMPayLogSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and sm.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and sm.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.out_trade_no))
            {
                sWhere += " and sm.out_trade_no like '%' + @out_trade_no + '%'";
                listSqlParam.Add(new SugarParameter("@out_trade_no", dto.out_trade_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.trade_no))
            {
                sWhere += " and sm.trade_no like '%' + @trade_no + '%'";
                listSqlParam.Add(new SugarParameter("@trade_no", dto.trade_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_account_no))
            {
                sWhere += " and sm.s_account_no = @s_account_no";
                listSqlParam.Add(new SugarParameter("@s_account_no", dto.s_account_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_flag))
            {
                sWhere += " and sm.s_flag = @s_flag";
                listSqlParam.Add(new SugarParameter("@s_flag", dto.s_flag));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.Pay_workno))
            {
                sWhere += " and sm.Pay_workno = @Pay_workno";
                listSqlParam.Add(new SugarParameter("@Pay_workno", dto.Pay_workno));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.Refund_workno))
            {
                sWhere += " and sm.Refund_workno = @Refund_workno";
                listSqlParam.Add(new SugarParameter("@Refund_workno", dto.Refund_workno));
            }
            if (null != dto && dto.create_date_start.HasValue)
            {
                sWhere += " and sm.Create_date >= @create_date_start";
                listSqlParam.Add(new SugarParameter("@create_date_start", dto.create_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.create_date_end.HasValue)
            {
                sWhere += " and sm.Create_date <= @create_date_end";
                listSqlParam.Add(new SugarParameter("@create_date_end", dto.create_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.refund_date_start.HasValue)
            {
                sWhere += " and sm.Refund_date >= @refund_date_start";
                listSqlParam.Add(new SugarParameter("@refund_date_start", dto.refund_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.refund_date_end.HasValue)
            {
                sWhere += " and sm.Refund_date <= @refund_date_end";
                listSqlParam.Add(new SugarParameter("@refund_date_end", dto.refund_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            // 付款情况标识
            if (null != dto && !string.IsNullOrWhiteSpace(dto.IsActive))
            {
                sWhere += " and sm.IsActive = @IsActive";
                listSqlParam.Add(new SugarParameter("@IsActive", dto.IsActive));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   SM_Pay_log sm
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by sm.id desc) as row_no,
                                           sm.id, sm.s_flag, sm.s_message, sm.s_account_no, sm.out_trade_no, sm.trade_no, sm.Pay_workno, 
                                           sm.Refund_workno, sm.Pay_amount, sm.IsActive, sm.Create_date, sm.Refund_date, 
                                           sm.cardtype, sm.Phoneno, sm.s_name, sm.WeChatOpenID, sm.PolicyCode, sm.s_type, 
                                           sm.Refund_Amount, sm.s_group, sm.OrderType, sm.Tips_amount, sm.Extend, sm.PayType, 
                                           sm.Check_date, sm.BuyerID, sm.BuyerName, sm.s_OtaOrderno, sm.OutletNo, sm.terminal_code, 
                                           sm.istakefood, sm.d_autotime, sm.n_autonum, sm.s_branch_id, sm.pay_code, sm.depart
                                    from   SM_Pay_log sm
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SMPayLogSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SMPayLogSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除扫码付款记录
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSMPayLogAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  SM_Pay_log  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

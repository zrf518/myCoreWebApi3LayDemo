﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar.IOC;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 计量单位接口实现
    /// </summary>
    public class SysUnitService : ISysUnitInterface
    {
        /// <summary>
        /// 新增计量单位
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSysUnitAsync(SysUnitDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysUnitEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.unit_no == dto.unit_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<SysUnitEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑计量单位
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSysUnitAsync(SysUnitDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysUnitEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.unit_no == dto.unit_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<SysUnitEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<SysUnitEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询计量单位
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysUnitDto>>> QuerySysUnitAsync(SysUnitDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.unit_no))
            {
                sWhere += " and unit_no = @unit_no";
                listSqlParam.Add(new SugarParameter("@unit_no", dto.unit_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.unit_name))
            {
                sWhere += " and unit_name like '%' + @unit_name + '%'";
                listSqlParam.Add(new SugarParameter("@unit_name", dto.unit_name));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_sys_unit
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by id desc) as row_no,
                                            id, unit_no, unit_name, create_user_wno, create_date, update_user_wno, update_date, 
                                            is_active, s_branch_id
                                    from    s_sys_unit
                                    where   1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                   ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SysUnitDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SysUnitDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除计量单位
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSysUnitAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from s_sys_unit  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除计量单位
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveSysUnitAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from s_sys_unit  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}


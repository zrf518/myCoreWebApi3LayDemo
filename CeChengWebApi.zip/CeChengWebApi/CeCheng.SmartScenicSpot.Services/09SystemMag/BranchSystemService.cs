﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 分店系统接口实现
    /// </summary>
    public class BranchSystemService : IBranchSystemInterface
    {
        /// <summary>
        /// 新增分店系统
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddBranchSystemAsync(BranchSystemDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<BranchSystemEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "分店ID重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<BranchSystemEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑分店系统
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditBranchSystemAsync(BranchSystemDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<BranchSystemEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "分店ID重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<BranchSystemEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<BranchSystemEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询分店系统
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<BranchSystemSearchResultDto>>> QueryBranchSystemAsync(BranchSystemSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.id != 0)
            {
                sWhere += " and bs.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and bs.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.branch_no))
            {
                sWhere += " and br.branch_no = @branch_no";
                listSqlParam.Add(new SugarParameter("@branch_no", dto.branch_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.branch_name))
            {
                sWhere += " and br.branch_name like '%' + @branch_name + '%'";
                listSqlParam.Add(new SugarParameter("@branch_name", dto.branch_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sys_type))
            {
                sWhere += " and bs.sys_type = @sys_type";
                listSqlParam.Add(new SugarParameter("@sys_type", dto.sys_type));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sys_name))
            {
                sWhere += " and bs.sys_name = @sys_name";
                listSqlParam.Add(new SugarParameter("@sys_name", dto.sys_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.db_ip))
            {
                sWhere += " and bs.db_ip like '%' + @db_ip + '%'";
                listSqlParam.Add(new SugarParameter("@db_ip", dto.db_ip));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.db_name))
            {
                sWhere += " and bs.[db_name] like '%' + @db_name + '%'";
                listSqlParam.Add(new SugarParameter("@db_name", dto.db_name));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and bs.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_branch_system bs
                                           left join s_branch br on bs.s_branch_id= br.id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by bs.id) as row_no,
                                           bs.id, bs.branch_no, bs.branch_name, bs.is_active, bs.sys_type, bs.sys_name, 
                                           bs.create_date, bs.update_date, bs.create_user_wno, bs.update_user_wno, 
                                           bs.s_branch_id, bs.db_ip, bs.[db_name], 
                                           br.group_no, br.group_name,
                                           branch_no_fdb=case when br.Is_store='Y' then br.group_no else br.branch_no end,
                                           branch_name_fdb=case when br.Is_store='Y' then br.group_no else br.branch_name end
                                    from   s_branch_system bs
                                           left join s_branch br on bs.s_branch_id= br.id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<BranchSystemSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<BranchSystemSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除分店系统
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveBranchSystemAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_branch_system  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除分店系统
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveBranchSystemAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_branch_system  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

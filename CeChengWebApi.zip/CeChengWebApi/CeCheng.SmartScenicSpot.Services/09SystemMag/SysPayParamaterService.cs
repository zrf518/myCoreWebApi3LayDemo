﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 支付参数接口实现
    /// </summary>
    public class SysPayParamaterService : ISysPayParamaterInterface
    {
        /// <summary>
        /// 新增支付参数
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSysPayParamaterAsync(SysPayParamaterDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysPayParamaterEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.s_group == dto.s_group && x.Name == dto.Name)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }
            // 转大写
            dto.IsActive = dto.IsActive.ToUpper();
            dto.IsShow = dto.IsShow.ToUpper();
            // 执行添加
            var result = await DbScoped.Sugar.Insertable<SysPayParamaterEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑支付参数
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSysPayParamaterAsync(SysPayParamaterDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysPayParamaterEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.s_group == dto.s_group && x.Name == dto.Name)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<SysPayParamaterEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;
            // 转大写
            dto.IsActive = dto.IsActive.ToUpper();
            dto.IsShow = dto.IsShow.ToUpper();

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<SysPayParamaterEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询支付参数
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysPayParamaterDto>>> QuerySysPayParamaterAsync(SysPayParamaterDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.Name))
            {
                sWhere += " and Name = @Name";
                listSqlParam.Add(new SugarParameter("@Name", dto.Name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.Value))
            {
                sWhere += " and Value = @Value";
                listSqlParam.Add(new SugarParameter("@Value", dto.Value));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_group))
            {
                sWhere += " and s_group like '%' + @s_group + '%'";
                listSqlParam.Add(new SugarParameter("@s_group", dto.s_group));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   wxParameters
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by id desc) as row_no,
                                            id, Name, Value, Times, UpdateDate, Remark, IsActive, s_group, depart, IsShow, 
		                                    create_user_wno, create_date, update_user_wno, update_date, s_branch_id
                                    from    wxParameters
                                    where   1=1 
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                   ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SysPayParamaterDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SysPayParamaterDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除支付参数
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSysPayParamaterAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from wxParameters  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除支付参数
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveSysPayParamaterAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from wxParameters  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}


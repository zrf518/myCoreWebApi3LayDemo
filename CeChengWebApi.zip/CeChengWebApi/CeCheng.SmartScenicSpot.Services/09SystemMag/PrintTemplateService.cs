﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 消费类别接口实现
    /// </summary>
    public class PrintTemplateService : IPrintTemplateInterface
    {
        /// <summary>
        /// 新增消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddPrintTemplateAsync(PrintTemplateDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<PrintTemplateEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.s_template_code == dto.s_template_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<PrintTemplateEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditPrintTemplateAsync(PrintTemplateDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<PrintTemplateEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.s_template_code == dto.s_template_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<PrintTemplateEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<PrintTemplateEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<PrintTemplateSearchResultDto>>> QueryPrintTemplateAsync(PrintTemplateSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and pt.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and pt.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_template_code))
            {
                sWhere += " and pt.s_template_code = @s_template_code";
                listSqlParam.Add(new SugarParameter("@s_template_code", dto.s_template_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_template_name))
            {
                sWhere += " and pt.s_template_name like '%' + @s_template_name + '%'";
                listSqlParam.Add(new SugarParameter("@s_template_name", dto.s_template_name));
            }
            if (null != dto && dto.s_template_type_id.HasValue)
            {
                sWhere += " and pt.s_template_type_id = @s_template_type_id";
                listSqlParam.Add(new SugarParameter("@s_template_type_id", dto.s_template_type_id));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and pt.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_print_template pt
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by pt.id desc) as row_no,
                                           pt.id, pt.s_template_code, pt.s_template_name, pt.s_template_text, pt.s_template_type_id, 
                                           pt.create_user_wno, pt.create_date, pt.update_user_wno, pt.update_date, pt.s_branch_id, pt.is_active
                                    from   s_print_template pt
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<PrintTemplateSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<PrintTemplateSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemovePrintTemplateAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_print_template  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemovePrintTemplateAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_print_template  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

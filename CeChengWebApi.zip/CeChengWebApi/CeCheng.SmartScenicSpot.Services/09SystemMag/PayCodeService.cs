﻿using CeCheng.SmartScenicSpot.Models;
using SqlSugar.IOC;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models.Consts;
using Microsoft.CodeAnalysis.Operations;
using System.Linq;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 付款方式接口实现
    /// </summary>
    public class PayCodeService : IPayCodeInterface
    {
        /// <summary>
        /// 新增付款方式
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddPayCodeAsync(PayCodeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<PayCodeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.pay_code == dto.pay_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<PayCodeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑付款方式
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditPayCodeAsync(PayCodeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<PayCodeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.pay_code == dto.pay_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<PayCodeEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<PayCodeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询付款方式
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<PayCodeSearchResultDto>>> QueryPayCodeAsync(PayCodeSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and pc.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and pc.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.pay_code))
            {
                sWhere += " and pc.pay_code = @pay_code";
                listSqlParam.Add(new SugarParameter("@pay_code", dto.pay_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.describe))
            {
                sWhere += " and pc.describe like '%' + @describe + '%'";
                listSqlParam.Add(new SugarParameter("@describe", dto.describe));
            }
            if (null != dto && dto.s_pay_type_id.HasValue)
            {
                sWhere += " and pc.s_pay_type_id = @s_pay_type_id";
                listSqlParam.Add(new SugarParameter("@s_pay_type_id", dto.s_pay_type_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.pay_type_code))
            {
                sWhere += " and pt.pay_type_code = @pay_type_code";
                listSqlParam.Add(new SugarParameter("@pay_type_code", dto.pay_type_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.pay_type_name))
            {
                sWhere += " and pt.pay_type_name = @pay_type_name";
                listSqlParam.Add(new SugarParameter("@pay_type_name", dto.pay_type_name));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_pay_code pc
                                           left join  s_pay_type pt on pc.s_pay_type_id = pt.id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by pc.id desc) as row_no,
                                           pc.id, pc.pay_code, pc.describe, pc.exchange, pc.pay_charge, pc.pay_exchange, 
                                           pc.tax_rate, pc.currency, pc.sort, pc.s_pay_type_id,
                                           pc.coupons_money, pc.isuse, pc.[percent], pc.third_party_code, pc.tm_code, pc.create_date, 
                                           pc.update_date, pc.create_user_wno, pc.update_user_wno, pc.is_active, pc.s_branch_id,
                                           pc.app_pay_type, pc.point_pay_type, pc.member_card_type, pc.money_count, pc.business_income,
                                           pc.cc_proctype_id,
                                           pt.pay_type_code, pt.pay_type_name,
                                           cc_proctype_code=pg.code,
                                           cc_proctype_name=pg.name
                                    from   s_pay_code pc
                                           left join  s_pay_type  pt  on pc.s_pay_type_id = pt.id
                                           left join  CC_proctype pg  on pc.cc_proctype_id  = pg.id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<PayCodeSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<PayCodeSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除付款方式
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemovePayCodeAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from s_pay_code  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除付款方式
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemovePayCodeAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from s_pay_code  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// =====查询获取分店配置的支付类型信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto<List<QueryBranchPayCodeInfosToPage>>> QueryBarnchPayCodeInfos(QueryBranchPayCodeInfoDto dto)
        {
            string sql = @"select c.id,c.pay_code,c.describe,c.is_active, p.id as my_sysid,p.code as my_syscode,p.name as my_sysname,p.s_type as my_sys_paycode  from s_pay_code c left join CC_proctype p on c.cc_proctype_id=p.id where c.is_active='Y'  and c.s_branch_id=@branchid";
            if (dto.allpaycode == false)
                sql += " and p.s_type='YDZF'";
            var listdata = await DbScoped.Sugar.Ado.SqlQueryAsync<QueryBranchPayCodeInfosToPage>(sql, new { branchid = dto.s_branch_id });
            bool flag = (listdata == null || !listdata.Any()) ? false : true;
            string msg = flag == false ? "请先配置CC_proctype与s_pay_code表中对应的分店支付配置绑定数据" : "";
            return flag ? ApiResultDto<List<QueryBranchPayCodeInfosToPage>>.ToResultSuccess(data: listdata) : ApiResultDto<List<QueryBranchPayCodeInfosToPage>>.ToResultFail(data: listdata, msg: msg);
        }

    }
}

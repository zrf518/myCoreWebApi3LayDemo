﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 读卡器类型分组接口实现
    /// </summary>
    public class CtPcService : ICtPcInterface
    {
        /// <summary>
        /// 新增读卡器类型分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddCtPcAsync(CtPcDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<CtPcEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.s_ipaddress == dto.s_ipaddress)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "类型重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<CtPcEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑读卡器类型分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditCtPcAsync(CtPcDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<CtPcEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.s_ipaddress == dto.s_ipaddress)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "类型重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<CtPcEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<CtPcEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询读卡器类型分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<CtPcSearchResultDto>>> QueryCtPcAsync(CtPcSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and cp.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and cp.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_ipaddress))
            {
                sWhere += " and cp.s_ipaddress = @s_ipaddress";
                listSqlParam.Add(new SugarParameter("@s_ipaddress", dto.s_ipaddress));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_group))
            {
                sWhere += " and cp.s_group = @s_group";
                listSqlParam.Add(new SugarParameter("@s_group", dto.s_group));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sGroupNo))
            {
                sWhere += " and cp.sGroupNo = @sGroupNo";
                listSqlParam.Add(new SugarParameter("@sGroupNo", dto.sGroupNo));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and cp.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   ct_pc cp
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by cp.id desc) as row_no,
                                           cp.id, cp.s_ipaddress, cp.s_group, cp.sGroupNo, cp.is_active, cp.create_date, cp.update_date, 
                                           cp.create_user_wno, cp.update_user_wno, cp.s_branch_id
                                    from   ct_pc cp
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<CtPcSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<CtPcSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除读卡器类型分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveCtPcAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  ct_pc  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除读卡器类型分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveCtPcAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  ct_pc  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

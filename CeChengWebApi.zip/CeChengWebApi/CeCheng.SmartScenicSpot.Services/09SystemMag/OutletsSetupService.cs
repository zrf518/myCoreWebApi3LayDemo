﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar.IOC;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis.CSharp;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 营业点接口实现
    /// </summary>
    public class OutletsSetupService : IOutletsSetupInterface
    {
        /// <summary>
        /// 新增营业点
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddOutletsSetupAsync(OutletsSetupDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<OutletsSetupEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.outlet_no == dto.outlet_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<OutletsSetupEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑营业点
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditOutletsSetupAsync(OutletsSetupDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<OutletsSetupEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.outlet_no == dto.outlet_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<OutletsSetupEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<OutletsSetupEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询营业点
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<OutletsSetupDto>>> QueryOutletsSetupAsync(OutletsSetupDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.outlet_no))
            {
                sWhere += " and outlet_no = @outlet_no";
                listSqlParam.Add(new SugarParameter("@outlet_no", dto.outlet_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.outlet_name))
            {
                sWhere += " and outlet_name like '%' + @outlet_name + '%'";
                listSqlParam.Add(new SugarParameter("@outlet_name", dto.outlet_name));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   outlets_setup
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by id desc) as row_no,
                                            id, outlet_no, outlet_name, [type], rate, Pay_no, Pay_secret, i_sort, s_stock,
                                            s_department, s_type, MenuNo, create_user_wno, create_date, update_user_wno, update_date,
                                            is_active, s_branch_id
                                    from    outlets_setup
                                    where   1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                   ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<OutletsSetupDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<OutletsSetupDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除营业点
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveOutletsSetupAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from outlets_setup  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除营业点
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveOutletsSetupAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from outlets_setup  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

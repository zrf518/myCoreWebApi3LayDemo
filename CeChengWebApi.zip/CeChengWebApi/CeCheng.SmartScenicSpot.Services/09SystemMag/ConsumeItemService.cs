﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 消费项目接口实现
    /// </summary>
    public class ConsumeItemService: IConsumeItemInterface
    {
        /// <summary>
        /// 新增消费项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddConsumeItemAsync(ConsumeItemDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ConsumeItemEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.consume_item_no == dto.consume_item_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<ConsumeItemEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑消费项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditConsumeItemAsync(ConsumeItemDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ConsumeItemEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.consume_item_no == dto.consume_item_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<ConsumeItemEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<ConsumeItemEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询消费项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<ConsumeItemSearchResultDto>>> QueryConsumeItemAsync(ConsumeItemSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and sci.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and sci.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.consume_item_no))
            {
                sWhere += " and sci.consume_item_no = @consume_item_no";
                listSqlParam.Add(new SugarParameter("@consume_item_no", dto.consume_item_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.consume_item_name))
            {
                sWhere += " and sci.consume_item_name like '%' + @consume_item_name + '%'";
                listSqlParam.Add(new SugarParameter("@consume_item_name", dto.consume_item_name));
            }
            if (null != dto && dto.s_charge_code_id.HasValue)
            {
                sWhere += " and sci.s_charge_code_id = @s_charge_code_id";
                listSqlParam.Add(new SugarParameter("@s_charge_code_id", dto.s_charge_code_id.Value));
            }
            if (null != dto && dto.s_change_type_id.HasValue)
            {
                sWhere += " and sct.id = @s_change_type_id";
                listSqlParam.Add(new SugarParameter("@s_change_type_id", dto.s_change_type_id.Value));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.changeTypeCode))
            {
                sWhere += " and isnull(sct.type_code, '') = @changeTypeCode";
                listSqlParam.Add(new SugarParameter("@changeTypeCode", dto.changeTypeCode));
            }
            if (null != dto && dto.bigChangTypeID.HasValue)
            {
                sWhere += " and sct.[type] = @bigChangTypeID";
                listSqlParam.Add(new SugarParameter("@bigChangTypeID", dto.bigChangTypeID.Value));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_consume_item sci
                                           left join s_charge_code         scc   on sci.s_charge_code_id = scc.id
                                           left join s_charge_type         sct   on sct.id = scc.s_charge_type_id
                                           left join s_sys_dictionary_info ssd   on sct.type = ssd.dicid 
                                                                                and ssd.dictype = 1000 
                                                                                and ssd.dicid is not null
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by sci.id desc) as row_no,
                                            sci.id, sci.consume_item_no, sci.consume_item_name, sci.item_abbreviation, sci.unit, sci.price, 
                                            sci.member_price, sci.discount_price, sci.commission_price, sci.resist, sci.charge_type, 
                                            sci.discount, sci.add_service, sci.ardpay, sci.hour, sci.hour_long, sci.comb, sci.i_isstop, 
                                            sci.is_yuding, sci.is_sale, sci.is_isgq, sci.barcode, sci.lease_item, sci.lease_start_price, 
                                            sci.lease_overtime_pric, sci.lease_start_hour, sci.lease_overtime_pay, sci.sort, sci.n_jprice, 
                                            sci.n_num_max, sci.n_num_min, sci.s_spec, sci.s_stock, sci.n_rent_damage, sci.n_rent_deposit, 
                                            sci.create_date, sci.update_date, sci.create_user_wno, sci.update_user_wno, sci.memo, sci.s_branch_id, 
                                            sci.s_charge_code_id, sci.is_active,
                                            scc.charge_describe, 
                                            s_change_type_id = sct.id,
                                            changeTypeCode = isnull(sct.type_code, ''),
                                            changeTypeName = isnull(sct.sale_consume_name, ''),
                                            bigChangTypeID = sct.[type],
                                            bigChangeTypeName = isnull(ssd.dicname,'')
                                    from    s_consume_item sci
                                            left join s_charge_code         scc  on sci.s_charge_code_id = scc.id
                                            left join s_charge_type         sct  on sct.id = scc.s_charge_type_id
                                            left join s_sys_dictionary_info ssd  on sct.type = ssd.dicid 
                                                                                and ssd.dictype = 1000 
                                                                                and ssd.dicid is not null
                                    where   1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<ConsumeItemSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<ConsumeItemSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除消费项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveConsumeItemAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_consume_item  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除消费项目
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveConsumeItemAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql  = "delete from  s_consume_item  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

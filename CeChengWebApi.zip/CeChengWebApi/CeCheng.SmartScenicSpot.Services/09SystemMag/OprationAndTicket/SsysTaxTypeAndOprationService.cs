﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using SqlSugar.IOC;
using CeCheng.SmartScenicSpot.Commoms;
using NPOI.SS.Formula.Functions;
using System.Linq;
using Microsoft.AspNetCore.Http;
using AutoMapper.Configuration.Conventions;
using SqlSugar;

namespace CeCheng.SmartScenicSpot.Services
{
    public class SsysTaxTypeAndOprationService : SsysTaxTypeAndOprationInterface
    {
        private readonly IMapper _mapper;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private UserTokenInfo _userTokenInfo { get; set; }
        int systype = 0; int branchid = 0;
        public SsysTaxTypeAndOprationService(IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;
            _userTokenInfo = CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            systype = _userTokenInfo.SysType;
            branchid = _userTokenInfo.SBranchId;

        }

        #region 发票类型设置相关
        public async Task<ApiResultDto> AddSsysTaxType(AddSsysTaxTypeDto dto)
        {
            var entity = _mapper.Map<AddSsysTaxTypeDto, SsysTaxTypeEntity>(dto);
            entity.update_date = null;
            entity.update_user_wno = "";
            var intCount = await DbScoped.Sugar.Insertable<SsysTaxTypeEntity>(entity).ExecuteCommandAsync();
            return intCount > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        public async Task<ApiResultDto> EditSsysTaxType(EditSsysTaxTypeDto dto)
        {
            var entity = _mapper.Map<EditSsysTaxTypeDto, SsysTaxTypeEntity>(dto);
            var getdbdata = await DbScoped.Sugar.Queryable<SsysTaxTypeEntity>().FirstAsync(c => c.id == dto.id);
            int ucount = 0;
            if (getdbdata != null)
            {
                entity.create_date = getdbdata.create_date;
                entity.create_user_wno = getdbdata.create_user_wno;
                ucount = await DbScoped.Sugar.Updateable<SsysTaxTypeEntity>(entity).ExecuteCommandAsync();
            }
            return ucount > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        public async Task<ApiResultPageNationTDataDto<List<EditSsysTaxTypeDto>>> QuerySsysTaxType(QuerySsysTaxType dto)
        {
            var totalcount = new SqlSugar.RefAsync<int>();
            var dbData = await DbScoped.Sugar.Queryable<SsysTaxTypeEntity>().LeftJoin<SsysBigTaxTypeEntity>((c, b) => c.tax_big_type_id == b.id)
                 .WhereIF(systype <= 0, (c, b) => c.s_branch_id == branchid)
                 .WhereIF(!string.IsNullOrEmpty(dto.code), (c, b) => c.code.Contains(dto.code))
                 .WhereIF(!string.IsNullOrEmpty(dto.describe), (c, b) => c.code.Contains(dto.describe))
                 .WhereIF(dto.taxrate > 0, (c, b) => c.taxrate == dto.taxrate)
                 .WhereIF(!string.IsNullOrEmpty(dto.mcard), (c, b) => c.mcard.Contains(dto.mcard))
                 .Select((c, b) => new EditSsysTaxTypeDto
                 {
                     id = c.id,
                     code = c.code,
                     create_date = c.create_date,
                     create_user_wno = c.create_user_wno,
                     describe = c.describe,
                     is_active = c.is_active,
                     taxrate = c.taxrate,
                     mcard = c.mcard,
                     s_branch_id = c.s_branch_id,
                     tax_big_type_id = c.tax_big_type_id,
                     tax_big_type_name = b.describe,
                     update_date = c.update_date,
                     update_user_wno = c.update_user_wno
                 }).ToPageListAsync(dto.pageIndex, dto.pageSize, totalcount);
            return ApiResultPageNationTDataDto<List<EditSsysTaxTypeDto>>.ToResultSuccess(data: dbData, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: totalcount.Value);
        }
        public async Task<ApiResultDto> RemoveSsysTaxType(int id)
        {
            // var entity = await DbScoped.Sugar.Queryable<SsysTaxTypeEntity>().FirstAsync(c => c.id == id);
            int count = await DbScoped.Sugar.Deleteable<SsysTaxTypeEntity>(c => c.id == id).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        #endregion

        #region 发票大类设置相关
        public async Task<ApiResultDto> AddSsysBigTaxType(AddSsysBigTaxTypeDto dto)
        {
            var entity = _mapper.Map<AddSsysBigTaxTypeDto, SsysBigTaxTypeEntity>(dto);
            var intCount = await DbScoped.Sugar.Insertable<SsysBigTaxTypeEntity>(entity).ExecuteCommandAsync();
            return intCount > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }

        public async Task<ApiResultDto> EditSsysBigTaxType(EditSsysBigTaxTypeDto dto)
        {
            var getEntity = await DbScoped.Sugar.Queryable<SsysBigTaxTypeEntity>().FirstAsync(c => c.id == dto.id);
            if (getEntity != null)
            {
                dto.create_date = getEntity.create_date;
                dto.create_user_wno = getEntity.create_user_wno;
                var entity = _mapper.Map<EditSsysBigTaxTypeDto, SsysBigTaxTypeEntity>(dto);
                var intCount = await DbScoped.Sugar.Updateable<SsysBigTaxTypeEntity>(entity).ExecuteCommandAsync();
                return intCount > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
            {
                return ApiResultDto.ToResultFail();
            }
        }
        public async Task<ApiResultDto> RemoveSsysBigTaxType(int id)
        {
            int uCount = await DbScoped.Sugar.Deleteable<SsysBigTaxTypeEntity>(c => c.id == id).ExecuteCommandAsync();
            return uCount > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        public async Task<ApiResultPageNationTDataDto<List<EditSsysBigTaxTypeDto>>> QuerySsysBigTaxType(QuerySsysBigTaxType dto)
        {
            //var systype = _userTokenInfo.SysType;
            //var branchid = _userTokenInfo.SBranchId;
            var totalCount = new RefAsync<int>();
            var getlistdata = await DbScoped.Sugar.Queryable<SsysBigTaxTypeEntity>()
                 .WhereIF(systype <= 0, c => c.s_branch_id == branchid)
                 .WhereIF(!string.IsNullOrEmpty(dto.describe), c => c.describe.Contains(dto.describe))
                 .WhereIF(!string.IsNullOrEmpty(dto.tax_big_type_code), c => c.tax_big_type_code.Contains(dto.tax_big_type_code))
                 .ToPageListAsync(dto.pageIndex, dto.pageSize, totalCount);
            var resultData = new List<EditSsysBigTaxTypeDto>();
            if (getlistdata.Any())
                resultData = _mapper.Map<List<SsysBigTaxTypeEntity>, List<EditSsysBigTaxTypeDto>>(getlistdata);
            return ApiResultPageNationTDataDto<List<EditSsysBigTaxTypeDto>>.ToResultSuccess(data: resultData, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: totalCount.Value);
        }
        #endregion


        #region 操作员班次相关
        public async Task<ApiResultDto> AddSsysOperatorShift(AddSsysOperatorShiftDto dto)
        {
            var entity = _mapper.Map<AddSsysOperatorShiftDto, SsysOperatorShiftEntity>(dto);
            entity.create_date = DateTime.Now;
            entity.create_user_wno = _userTokenInfo.UserWorkNo;
            entity.s_branch_id = _userTokenInfo.SBranchId;
            int intCount = await DbScoped.Sugar.Insertable<SsysOperatorShiftEntity>(entity).ExecuteCommandAsync();
            return intCount > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }

        public async Task<ApiResultDto> EditSsysOperatorShift(EditSsysOperatorShiftDto dto)
        {
            var getentity = await DbScoped.Sugar.Queryable<SsysOperatorShiftEntity>().FirstAsync(c => c.id == dto.id);
            if (getentity != null)
            {
                dto.update_date = DateTime.Now;
                dto.update_user_wno = _userTokenInfo.UserWorkNo;
                dto.create_date = getentity.create_date;
                dto.create_user_wno = getentity.create_user_wno;
                var entity = _mapper.Map<EditSsysOperatorShiftDto, SsysOperatorShiftEntity>(dto);
                int uCount = await DbScoped.Sugar.Updateable(entity).ExecuteCommandAsync();
                return uCount > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
            {
                return ApiResultDto.ToResultFail();
            }
        }
        public async Task<ApiResultDto> RemoveSsysOperatorShift(int id)
        {
            var uCount = await DbScoped.Sugar.Deleteable<SsysOperatorShiftEntity>(c => c.id == id).ExecuteCommandAsync();
            return uCount > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        public async Task<ApiResultPageNationTDataDto<List<EditSsysOperatorShiftDto>>> QuerySsysOperatorShift(QuerySsysOpretorShiftDto dto)
        {
            //int systype = _userTokenInfo.SysType; dto.s_branch_id
            //int branchid = _userTokenInfo.SBranchId;
            var refCount = new RefAsync<int>();
            var entitys = await DbScoped.Sugar.Queryable<SsysOperatorShiftEntity>()
                .WhereIF(systype <= 0, c => c.s_branch_id == branchid)
                .WhereIF(dto.shift_no > 0, c => c.shift_no == dto.shift_no)
                .WhereIF(!string.IsNullOrEmpty(dto.shift_name), c => c.shift_name.Contains(dto.shift_name))
                .WhereIF(!string.IsNullOrEmpty(dto.start_time), c => c.start_time == dto.start_time)
                .WhereIF(!string.IsNullOrEmpty(dto.end_time), c => c.end_time == dto.end_time)
                .OrderBy(c => c.id, OrderByType.Desc).ToPageListAsync(dto.pageIndex, dto.pageSize, refCount);
            var dataList = new List<EditSsysOperatorShiftDto>();
            if (refCount.Value > 0)
            {
                dataList = _mapper.Map<List<SsysOperatorShiftEntity>, List<EditSsysOperatorShiftDto>>(entitys);
            }
            return ApiResultPageNationTDataDto<List<EditSsysOperatorShiftDto>>.ToResultSuccess(data: dataList, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: refCount.Value);
        }
        #endregion
    }
}

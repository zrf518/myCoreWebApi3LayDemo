﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 套餐分组接口实现
    /// </summary>
    public class SysCombGroupService : ISysCombGroupInterface
    {
        /// <summary>
        /// 新增套餐分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSysCombGroupAsync(SysCombGroupDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysCombGroupEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.comb_group_code == dto.comb_group_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<SysCombGroupEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑套餐分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSysCombGroupAsync(SysCombGroupDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysCombGroupEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.comb_group_code == dto.comb_group_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<SysCombGroupEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<SysCombGroupEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询套餐分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysCombGroupSearchResultDto>>> QuerySysCombGroupAsync(SysCombGroupSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and scg.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and scg.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.comb_group_code))
            {
                sWhere += " and scg.comb_group_code = @comb_group_code";
                listSqlParam.Add(new SugarParameter("@comb_group_code", dto.comb_group_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.comb_group_name))
            {
                sWhere += " and scg.comb_group_name like '%' + @comb_group_name + '%'";
                listSqlParam.Add(new SugarParameter("@comb_group_name", dto.comb_group_name));
            }
            if (null != dto && dto.s_sys_comb_id.HasValue)
            {
                sWhere += " and scg.s_sys_comb_id = @s_sys_comb_id";
                listSqlParam.Add(new SugarParameter("@s_sys_comb_id", dto.s_sys_comb_id));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.comb_code))
            {
                sWhere += " and scb.comb_code = @comb_code";
                listSqlParam.Add(new SugarParameter("@comb_code", dto.comb_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.comb_name))
            {
                sWhere += " and scb.comb_name like '%' + @comb_name + '%'";
                listSqlParam.Add(new SugarParameter("@comb_name", dto.comb_name));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_sys_comb_group scg
                                           left join s_sys_comb scb on scg.s_sys_comb_id = scb.id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by scg.id desc) as row_no,
                                           scg.id, scg.comb_group_code, scg.comb_group_name, scg.s_sys_comb_id, 
                                           scg.create_date, scg.update_date, scg.create_user_wno, 
                                           scg.update_user_wno, scg.s_branch_id, scg.is_active,
                                           scb.comb_code, scb.comb_name
                                    from   s_sys_comb_group scg
                                           left join s_sys_comb scb on scg.s_sys_comb_id = scb.id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SysCombGroupSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SysCombGroupSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除套餐分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSysCombGroupAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_sys_comb_group  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除套餐分组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveSysCombGroupAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_sys_comb_group  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}


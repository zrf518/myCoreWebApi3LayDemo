﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 部门类别接口实现
    /// </summary>
    public class SysDepartmentTypeService: ISysDepartmentTypeInterface
    {
        /// <summary>
        /// 新增部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSysDepartmentTypeAsync(SysDepartmentTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysDepartmentTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.dept_type_code == dto.dept_type_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<SysDepartmentTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSysDepartmentTypeAsync(SysDepartmentTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysDepartmentTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.dept_type_code == dto.dept_type_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<SysDepartmentTypeEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<SysDepartmentTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysDepartmentTypeDto>>> QuerySysDepartmentTypeAsync(SysDepartmentTypeDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.dept_type_code))
            {
                sWhere += " and dept_type_code = @dept_type_code";
                listSqlParam.Add(new SugarParameter("@dept_type_code", dto.dept_type_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.dept_type))
            {
                sWhere += " and dept_type like '%' + @dept_type + '%'";
                listSqlParam.Add(new SugarParameter("@dept_type", dto.dept_type));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_sys_department_type
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by id desc) as row_no,
                                           id, dept_type_code, dept_type, create_user_wno, create_date, 
                                           update_user_wno, update_date, is_active, s_branch_id
                                    from   s_sys_department_type
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SysDepartmentTypeDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SysDepartmentTypeDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSysDepartmentTypeAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from s_sys_department_type  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveSysDepartmentTypeAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from s_sys_department_type  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

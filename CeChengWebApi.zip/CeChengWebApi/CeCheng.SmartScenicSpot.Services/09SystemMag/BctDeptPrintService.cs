﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 消打印机设置接口实现
    /// </summary>
    public class BctDeptPrintService : IBctDeptPrintInterface
    {
        /// <summary>
        /// 新增消打印机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddBctDeptPrintAsync(BctDeptPrintDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<BctDeptPrintEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.CODE == dto.CODE)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<BctDeptPrintEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑消打印机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditBctDeptPrintAsync(BctDeptPrintDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<BctDeptPrintEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.CODE == dto.CODE)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<BctDeptPrintEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<BctDeptPrintEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询消打印机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<BctDeptPrintSearchResultDto>>> QueryBctDeptPrintAsync(BctDeptPrintSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and bdp.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and bdp.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.CODE))
            {
                sWhere += " and bdp.CODE = @CODE";
                listSqlParam.Add(new SugarParameter("@CODE", dto.CODE));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.NAME))
            {
                sWhere += " and bdp.[NAME] like '%' + @NAME + '%'";
                listSqlParam.Add(new SugarParameter("@NAME", dto.NAME));
            }
            // 根据部门信息查询
            if (null != dto && dto.DEPT_NO.HasValue)
            {
                sWhere += " and bdp.DEPT_NO = @DEPT_NO";
                listSqlParam.Add(new SugarParameter("@DEPT_NO", dto.DEPT_NO));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.dept_code))
            {
                sWhere += " and sdp.dept_no = @dept_code";
                listSqlParam.Add(new SugarParameter("@dept_code", dto.dept_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.dept_name))
            {
                sWhere += " and sdp.dept_name = @dept_name";
                listSqlParam.Add(new SugarParameter("@dept_name", dto.dept_name));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and bdp.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   bct_dept_print bdp
                                           left join  s_sys_department sdp on bdp.DEPT_NO = sdp.id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by bdp.id) as row_no,
	                                       bdp.id, bdp.CODE, bdp.[NAME], bdp.is_active, bdp.SHOWINDEX, bdp.PRINTERI, bdp.create_date, bdp.update_date, 
	                                       bdp.create_user_wno, bdp.update_user_wno, bdp.s_branch_id, bdp.PRINTERII, bdp.PRINTERIII, bdp.PRINTERIV, 
	                                       bdp.STANDBYPI, bdp.STANDBYPII, bdp.STANDBYPIII, bdp.STANDBYPIV, bdp.SENDMENUDEPT, bdp.NOTE, bdp.OPERATOR, 
	                                       bdp.OPER_DATE, bdp.PRINTER, bdp.SIGN_SEND, bdp.CPCC, bdp.HB, bdp.HB_PRINT, bdp.[floor], bdp.TRAN_FLAG, 
	                                       bdp.S_TRAN, bdp.TRAN_PRINT, bdp.PRINTERI3, bdp.PRINTERI4, bdp.SIGN_SEND3, bdp.SIGN_SEND4, bdp.isPrint, 
	                                       bdp.scom, bdp.[state], bdp.Is_PBarcode, bdp.s_billsize, bdp.DEPT_NO,
	                                       dept_code=sdp.dept_no, sdp.dept_name
                                    from   bct_dept_print bdp
                                           left join  s_sys_department sdp on bdp.DEPT_NO = sdp.id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<BctDeptPrintSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<BctDeptPrintSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除消打印机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveBctDeptPrintAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  bct_dept_print  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除消打印机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveBctDeptPrintAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  bct_dept_print  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

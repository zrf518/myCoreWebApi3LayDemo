﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 消费大类接口实现
    /// </summary>
    public class ChargeTypeService : IChargeTypeInterface
    {
        /// <summary>
        /// 新增消费大类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddChargeTypeAsync(ChargeTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ChargeTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.type_code == dto.type_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<ChargeTypeEntity>(dto).ExecuteCommandAsync();
            if(result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑消费大类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditChargeTypeAsync(ChargeTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ChargeTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.type_code == dto.type_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg:"编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<ChargeTypeEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<ChargeTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询消费大类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<ChargeTypeSearchResultDto>>> QueryChargeTypeAsync(ChargeTypeSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and sct.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and sct.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.type_code))
            {
                sWhere += " and sct.type_code = @type_code";
                listSqlParam.Add(new SugarParameter("@type_code", dto.type_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sale_consume_name))
            {
                sWhere += " and sct.sale_consume_name like '%' + @sale_consume_name + '%'";
                listSqlParam.Add(new SugarParameter("@sale_consume_name", dto.sale_consume_name));
            }
            if (null != dto && dto.type.HasValue)
            {
                sWhere += " and sct.type = @type";
                listSqlParam.Add(new SugarParameter("@type", dto.type));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_charge_type sct
                                            left join s_sys_dictionary_info ssd  on sct.type = ssd.dicid 
                                                                                and ssd.dictype = 1000 
                                                                                and ssd.dicid is not null
                                    where   1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by sct.id desc) as row_no,
                                            sct.id, sct.type_code, sct.sale_consume_name, sct.[type], sct.sort, 
		                                    sct.create_user_wno, sct.create_date, sct.update_user_wno, sct.update_date,
		                                    sct.is_active, sct.s_branch_id, 
                                            ssd.dicname
                                    from    s_charge_type sct
                                            left join s_sys_dictionary_info ssd  on sct.type = ssd.dicid 
                                                                                and ssd.dictype = 1000 
                                                                                and ssd.dicid is not null
                                    where   1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex* dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                   ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<ChargeTypeSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<ChargeTypeSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除消费大类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveChargeTypeAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_charge_type  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除消费大类
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveChargeTypeAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach(int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_charge_type  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

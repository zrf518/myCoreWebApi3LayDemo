﻿using AutoMapper;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Http;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    public class SBranchSystemInfosService : CeChengBaseWithMapperService, ISBranchSystemInfosInterface
    {
        public SBranchSystemInfosService(IHttpContextAccessor httpContextAccessor, IMapper mapper) : base(httpContextAccessor, mapper)
        {
        }
        /// <summary>
        /// 新增和编辑  分店系统表 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSystemBranchInfo(SBranchSystemInfosAddDto dto)
        {
            var entity = _Mapper.Map<SBranchSystemInfosAddDto, SBranchSystemEntity>(dto);
            if (entity != null)
            {
                entity.create_date = DateTime.Now;
                entity.create_user_wno = _UserTokenInfo.UserWorkNo;
                entity.is_active = IsActivityConstStr.Y;
                int count = await DbScoped.SugarScope.Insertable<SBranchSystemEntity>(entity).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
                return ApiResultDto.ToResultFail();
        }

        /// <summary>
        /// 编辑  分店系统表 修改时id必填
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSystemBranchInfo(SBranchSystemInfosEditDto dto)
        {
            var entity = _Mapper.Map<SBranchSystemInfosEditDto, SBranchSystemEntity>(dto);
            var getDbentity = await DbScoped.SugarScope.Queryable<SBranchSystemEntity>().Where(c => c.id == dto.id).FirstAsync();
            if (getDbentity != null && getDbentity.id > 0 && entity != null)
            {
                entity.update_date = DateTime.Now;
                entity.update_user_wno = _UserTokenInfo.UserWorkNo;
                entity.create_date = getDbentity.create_date;
                entity.create_user_wno = getDbentity.create_user_wno;
                int count = await DbScoped.SugarScope.Updateable<SBranchSystemEntity>(entity).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
                return ApiResultDto.ToResultFail();
        }


        /// <summary>
        /// 查询分店系统表
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SBranchSystemEntity>>> QuerySystemBranchInfo(SBranchSystemInfosQueryDto dto)
        {
            var tcount = new SqlSugar.RefAsync<int>();
            var _listdata = await DbScoped.Sugar.Queryable<SBranchSystemEntity>().WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                  .WhereIF(!string.IsNullOrEmpty(dto.branch_name), c => c.branch_name.Contains(c.branch_name))
                  .WhereIF(!string.IsNullOrEmpty(dto.branch_no), c => c.branch_no.Contains(c.branch_no))
                  .WhereIF(dto.s_branch_id > 0, c => c.s_branch_id == dto.s_branch_id)
                  .OrderByDescending(c => c.id)
                  .ToPageListAsync(dto.pageIndex, dto.pageSize, tcount);
            List<SBranchSystemEntity> data = new List<SBranchSystemEntity>();
            if (tcount.Value > 0)
                data = _listdata;
            return ApiResultPageNationTDataDto<List<SBranchSystemEntity>>.ToResultSuccess(PageIndex: dto.pageIndex, PageSize: dto.pageSize, data: data, TotalRow: tcount.Value);
        }
        /// <summary>
        /// 删除系统分店表
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSystemBranchInfo(QueryByIdDto dto)
        {

            return null;
        }
    }
}

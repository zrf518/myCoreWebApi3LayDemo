﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 消费类别接口实现
    /// </summary>
    public class ChargeCodeService : IChargeCodeInterface
    {
        /// <summary>
        /// 新增消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddChargeCodeAsync(ChargeCodeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ChargeCodeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.charge_code == dto.charge_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<ChargeCodeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditChargeCodeAsync(ChargeCodeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ChargeCodeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.charge_code == dto.charge_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<ChargeCodeEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<ChargeCodeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<ChargeCodeSearchResultDto>>> QueryChargeCodeAsync(ChargeCodeSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and scc.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and scc.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.charge_code))
            {
                sWhere += " and scc.charge_code = @charge_code";
                listSqlParam.Add(new SugarParameter("@charge_code", dto.charge_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.charge_describe))
            {
                sWhere += " and scc.charge_describe like '%' + @charge_describe + '%'";
                listSqlParam.Add(new SugarParameter("@charge_describe", dto.charge_describe));
            }
            if (null != dto && dto.s_charge_type_id.HasValue)
            {
                sWhere += " and scc.s_charge_type_id = @s_charge_type_id";
                listSqlParam.Add(new SugarParameter("@s_charge_type_id", dto.s_charge_type_id));
            }
            // 根据部门信息查询
            if (null != dto && dto.department_id.HasValue)
            {
                sWhere += " and scc.department_id = @department_id";
                listSqlParam.Add(new SugarParameter("@department_id", dto.department_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.dept_no))
            {
                sWhere += " and dp.dept_no = @dept_no";
                listSqlParam.Add(new SugarParameter("@dept_no", dto.dept_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.dept_name))
            {
                sWhere += " and dp.dept_name = @dept_name";
                listSqlParam.Add(new SugarParameter("@dept_name", dto.dept_name));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and scc.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_charge_code scc
                                           left join s_charge_type sct on scc.s_charge_type_id = sct.id
                                           left join s_sys_department dp on scc.department_id = dp.id
                                           left join s_sys_disc_type ds on scc.disc_type_id = ds.id
                                           left join s_sys_tax_type stt on scc.taxtype_id = stt.id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by scc.id desc) as row_no,
                                           scc.id, scc.charge_code, scc.charge_describe, scc.s_charge_type_id, scc.disc_type_id,  
                                           scc.department_id, scc.report_type_id, scc.taxtype_id, 
                                           scc.create_user_wno, scc.create_date, scc.update_user_wno, scc.update_date, 
                                           scc.is_active, scc.s_branch_id, 
                                           sct.sale_consume_name,
                                           dept_no=dp.dept_no, dept_name=dp.dept_name,
                                           disc_no=ds.s_no, disc_name=ds.s_desc,
                                           taxtype_code=stt.code, taxtype_name=stt.describe,
                                           report_type_code='', report_type_name=''
                                    from   s_charge_code scc
                                           left join s_charge_type sct on scc.s_charge_type_id = sct.id
                                           left join s_sys_department dp on scc.department_id = dp.id
                                           left join s_sys_disc_type ds on scc.disc_type_id = ds.id
                                           left join s_sys_tax_type stt on scc.taxtype_id = stt.id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<ChargeCodeSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<ChargeCodeSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveChargeCodeAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_charge_code  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除消费类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveChargeCodeAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_charge_code  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

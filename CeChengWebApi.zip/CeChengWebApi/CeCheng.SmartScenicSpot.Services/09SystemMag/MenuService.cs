﻿using AutoMapper;
using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using CeCheng.SmartScenicSpot.Models.Consts;
using Microsoft.AspNetCore.Http;
using Microsoft.CodeAnalysis.Operations;
using NPOI.SS.Formula.Functions;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    public class MenuService : IMenuRoleInterface
    {
        private IMapper _mapper;
        private readonly IHttpContextAccessor _httpContext;
        private UserTokenInfo _userTokenInfo;
        public MenuService(IHttpContextAccessor httpContext, IMapper mapper)
        {
            _httpContext = httpContext;
            _mapper = mapper;
            _userTokenInfo = CeChengTokenHelper.GetTockenUserInfo(_httpContext.HttpContext);
        }

        #region 菜单
        /// <summary>
        /// 主键 ，新增时该值为0：编辑值大于0
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<bool> AddMenu(SsysMenuEntity dto)
        {
            // var user = CeChengTokenHelper.GetTockenUserInfo(_httpContext.HttpContext);
            dto.is_active = IsActivityConstStr.Y;
            dto.create_date = DateTime.Now;
            dto.create_user_wno = _userTokenInfo.UserWorkNo;
            int insertCount = await DbScoped.Sugar.Insertable<SsysMenuEntity>(dto).ExecuteCommandAsync();
            return insertCount > 0 ? true : false;

        }
        public async Task<bool> EditMenu(SsysMenuEntity dto)
        {
            // var user = CeChengTokenHelper.GetTockenUserInfo(_httpContext.HttpContext);
            var editObj = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<SsysMenuEntity>("select  top 1 * from  s_sys_menu where menu_id=@menuid ;", new { menuid = dto.menu_id });
            if (editObj != null && editObj.menu_id > 0)
            {
                // editObj.button_info = dto.button_info;
                editObj.menu_name = dto.menu_name;
                editObj.order_number = dto.order_number;
                editObj.menu_url = dto.menu_url;
                editObj.parent_id = dto.parent_id;
                editObj.is_active = dto.is_active;
                editObj.update_date = DateTime.Now;
                editObj.update_user_wno = _userTokenInfo.UserWorkNo;
                editObj.menu_code = dto.menu_code;
                editObj.menu_icon = dto.menu_icon;
                editObj.menu_layout = dto.menu_layout;
                editObj.is_active = dto.is_active;
                await DbScoped.Sugar.Updateable<SsysMenuEntity>(editObj).ExecuteCommandAsync();
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 软删除菜单 -->修改为真删除， 存在关系就不可以删除 菜单或者按钮
        /// </summary>
        /// <param name="MenuId"></param>
        /// <returns></returns>
        public async Task<bool> RemoveMenu(int MenuId, bool isParentMenu)
        {
            //var ifhaveRoleInMenuUse = await DbScoped.Sugar.Queryable<SsysRoleMenuEntity>().AnyAsync(c => c.menu_id == MenuId);
            //if (ifhaveRoleInMenuUse)
            //{
            //    throw new Exception(SuccessFailConstStr.ThisDataHaveRerationCantRemove);
            //}
            if (!isParentMenu)//二级菜单
            {
                await DbScoped.Sugar.Deleteable<SsysMenuEntity>(c => c.menu_id == MenuId).ExecuteCommandAsync();
                return true;
            }
            else
            { //一级菜单
              //var getMenu = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<SsysMenuEntity>("select top 1 * from s_sys_menu where parent_id=@id", new { id = MenuId });
                var getMenu = await DbScoped.Sugar.Queryable<SsysMenuEntity>().FirstAsync(c => c.parent_id == MenuId);
                if (getMenu != null)
                    throw new Exception("该一级菜单下面存在子菜单数据,不可以删除");
                else
                {
                    //删除选择的一级菜单
                    var result = await DbScoped.Sugar.Deleteable<SsysMenuEntity>(c => c.menu_id == MenuId).ExecuteCommandAsync();
                    return result > 0 ? true : false;
                }
            }
        }

        /// <summary>
        /// 获取一个平面的查询列表数据  待重写,不使用该接口
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<EditMenuDto>>> GetMenus(GetMenuListDataByTenantId dto)
        {
            #region old
            //int start = (dto.pageIndex - 1) * dto.pageSize;
            //int end = dto.pageSize;
            //int tenantid = dto.s_branch_id;

            //string sqlCount = @"select count(1) from s_sys_menu  ";
            //string sqlStr = @"select menu_id  , menu_name ,parent_id , order_number, menu_url,create_user_wno, create_time, button_info, is_active,menu_icon,menu_code,menu_layout,menu_level_type,s_branch_id from(select   *,ROW_NUMBER() over(order by menu_id desc) as rm  from  s_sys_menu ";
            //if (tenantid > 0)
            //{
            //    sqlCount += " and s_branch_id=" + tenantid;
            //    sqlStr += " and s_branch_id=@tenantId ";
            //}
            //sqlStr += ") q where rm between @start and @end  ";

            //int totalCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount);
            //var listMenu = await DbScoped.Sugar.Ado.SqlQueryAsync<EditMenuDto>(sqlStr, new { start = start, end = end, tenantId = tenantid });

            ////await DbScoped.Sugar.Queryable<SsysMenuEntity>().

            //return ApiResultPageNationTDataDto<List<EditMenuDto>>.ToResultSuccess(data: listMenu, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: totalCount); 
            #endregion
            int systype = _userTokenInfo.SysType;
            int branchid = _userTokenInfo.SBranchId;
            var totalcount = new RefAsync<int>();
            var dbData = await DbScoped.Sugar.Queryable<SsysMenuEntity>().WhereIF(systype <= 0, c => c.s_branch_id == branchid)
                .ToPageListAsync(dto.pageIndex, dto.pageSize, totalcount);
            var data = new List<EditMenuDto>();
            if (totalcount.Value > 0)
                data = _mapper.Map<List<SsysMenuEntity>, List<EditMenuDto>>(dbData);

            return ApiResultPageNationTDataDto<List<EditMenuDto>>.ToResultSuccess(data: data, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: totalcount);
        }


        #endregion



        #region 角色CURD
        /// <summary>
        /// 新增角色
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<bool> AddRole(SsysRolesEntity dto)
        {
            var user = CeChengTokenHelper.GetTockenUserInfo(_httpContext.HttpContext);
            dto.is_active = IsActivityConstStr.Y;
            dto.create_date = DateTime.Now;
            dto.create_user_wno = user.UserWorkNo;
            int id = await DbScoped.Sugar.Queryable<SsysRolesEntity>().MaxAsync<int>("id");
            dto.role_id = ++id;
            int insertCount = await DbScoped.Sugar.Insertable<SsysRolesEntity>(dto).ExecuteCommandAsync();
            return insertCount > 0;
        }
        /// <summary>
        /// 修改角色
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<bool> EditRole(SsysRolesEntity dto)
        {
            //var user = CeChengTokenHelper.GetTockenUserInfo(_httpContext.HttpContext);
            var editObj = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<SsysRolesEntity>("select  top 1 * from  s_sys_roles where id=@id ;", new { id = dto.id });
            if (editObj != null || editObj.id > 0)
            {
                editObj.update_date = DateTime.Now;
                editObj.update_user_wno = _userTokenInfo.UserWorkNo;
                editObj.is_active = dto.is_active;
                editObj.role_name = dto.role_name;
                await DbScoped.Sugar.Updateable<SsysRolesEntity>(editObj).ExecuteCommandAsync();
                return true;
            }
            else
                return false;
        }
        /// <summary>
        /// 真删除角色
        /// </summary>
        /// <param name="id"></param>
        /// <param name="TenantId"></param>
        /// <returns></returns>
        public async Task<bool> RemoveRole(int id, int TenantId)
        {
            bool flag = await DbScoped.Sugar.Queryable<SsysRoleMenuEntity>().AnyAsync(c => c.role_id == id);
            if (flag)
                throw new Exception(SuccessFailConstStr.ThisDataHaveRerationCantRemove);
            int count = await DbScoped.Sugar.Deleteable<SsysRolesEntity>(c => c.id == id).ExecuteCommandAsync();
            return count > 0;
        }
        /// <summary>
        /// 获取角色列表数据  
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<EditRoleDto>>> GetRoles(QueryOneStrDtoWithPageNation dto)
        {
            int systype = _userTokenInfo.SysType;
            int branchid = _userTokenInfo.SBranchId;
            List<EditRoleDto> data = new List<EditRoleDto>();
            var refCount = new RefAsync<int>();
            var dbList = await DbScoped.Sugar.Queryable<SsysRolesEntity>()
                  .WhereIF(!string.IsNullOrEmpty(dto.RoleName), c => c.role_name.Contains(dto.RoleName))
                  // .WhereIF(!string.IsNullOrEmpty(RoleName), c => EF.Functions.Like.)
                  .WhereIF(systype <= 0, c => c.s_branch_id == branchid)
                  .ToPageListAsync(dto.pageIndex, dto.pageSize, refCount);
            if (refCount.Value > 0)
                data = _mapper.Map<List<SsysRolesEntity>, List<EditRoleDto>>(dbList);
            return ApiResultPageNationTDataDto<List<EditRoleDto>>.ToResultSuccess(data, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: refCount.Value);
        }
        #endregion

        #region 角色菜单关系

        /// <summary>
        /// 获取角色对应的菜单树形结构的数据
        /// </summary>
        /// <param name="TenantId">分店id</param>
        /// <param name="RoleId">查询全部角色数据；等于0：全部不打钩： 否则根据角色id来查询对应的菜单数据是否true打钩有权限 </param>
        /// <param name="onlyThisRoleMenusData">true:当前的角色菜单数据；false:全部菜单</param>
        /// <returns></returns>
        public async Task<List<RoleMenuRelation>> GetRoleMenusRelations(int TenantId, int RoleId, bool onlyThisRoleMenusData)
        {
            var listMenu = await DbScoped.Sugar.Queryable<SsysMenuEntity>().Where(c => c.s_branch_id == TenantId).ToListAsync();//&&c.order_number==100
            if (listMenu == null || !listMenu.Any())
            {
                return new List<RoleMenuRelation>();
            }
            //拿到该角色对应的所有菜单

            var rmEntitys = await DbScoped.Sugar.Queryable<SsysRoleMenuEntity>().Where(c => c.s_branch_id == TenantId).WhereIF(onlyThisRoleMenusData == true, c => c.role_id == RoleId).Select(c => c.menu_id).ToListAsync();

            //所有菜单
            listMenu = listMenu.WhereIF(onlyThisRoleMenusData == true && rmEntitys != null && rmEntitys.Any(), c => rmEntitys.Contains(c.menu_id)).ToList();

            var _listMenu = _mapper.Map<List<SsysMenuEntity>, List<EditMenuDto>>(listMenu);

            //一级菜单
            var _plistMenu = _listMenu.Where(c => c.s_branch_id == TenantId && c.parent_id == 0).ToList();//c.menu_level_type == 1 && c.parent_id == 0 && 

            //分店下所有的按钮列表 以及角色菜单按钮关系数据   menu_type='F' and
            var items = await DbScoped.Sugar.Ado.SqlQueryAsync<MenuButtonsInfoDto, IntStringDicDto>("select menu_id,menu_name,parent_id,order_number from s_sys_menu where  menu_level_type=-1 and  s_branch_id=@branchid order by menu_id desc;select role_id, menu_id from s_sys_role_menu where s_branch_id=@branchid  and role_id=@roleid order by id desc", new { branchid = TenantId, roleid = RoleId });
            List<MenuButtonsInfoDto> getMenuButtonsInfo = items.Item1;
            List<IntStringDicDto> rolemenubuids = items.Item2;
            if (onlyThisRoleMenusData == true && rmEntitys != null && rmEntitys.Any())
            {
                //当前角色下所有的按钮等相关数据
                if (_plistMenu != null)
                    _plistMenu = _plistMenu.Where(c => rmEntitys.Contains(c.menu_id)).ToList();
                if (items.Item1 != null)
                    getMenuButtonsInfo = getMenuButtonsInfo.Where(c => rmEntitys.Contains(c.menu_id)).ToList();
                if (rolemenubuids != null)
                    rolemenubuids = rolemenubuids.Where(c => c.role_id == RoleId && rmEntitys.Contains(c.menu_id)).ToList();
            }

            var tree = new List<RoleMenuRelation>();
            //角色菜单数据
            if (_plistMenu != null && _plistMenu.Any())
            {
                var rMenus = RoleId <= 0 ? new RoleMenuKvDto { MenuId = new List<int>(), RoleId = 0 } : await LoadRoleMens(RoleId, TenantId);
                var menuids = rMenus == null ? new List<int>() : rMenus.MenuId;//该角色对应的所有菜单

                foreach (var item in _plistMenu)
                {
                    RoleMenuRelation data = new RoleMenuRelation
                    {
                        Title = item.menu_name,
                        Path = item.menu_url,
                        AlwaysShow = item.is_active == "Y" ? true : false,
                        Component = item.menu_layout,
                        MenuId = item.menu_id,
                        Name = item.menu_code,
                        ParentId = item.parent_id,
                        Redirect = "",
                        Meta = new Meta { Title = item.menu_name, Icon = item.menu_code },
                        IfCheck = RoleId <= 0 ? false : IFCheck(rMenus, item.menu_id, RoleId),
                        Children = new List<RoleMenuRelation>(),
                        s_branch_id = TenantId,
                        isbutton = item.menu_level_type == -1 ? true : false,
                        lay_index = item.menu_level_type.Value==-1?4:item.menu_level_type.Value,
                    };
                    LoopFuncMenuData(_listMenu, data, rMenus, RoleId, getMenuButtonsInfo, rolemenubuids);
                    tree.Add(data);
                }
            }
            return tree;
        }

        private bool IFCheck(RoleMenuKvDto menuids, int MenuId, int roleId)
        {
            if (menuids == null) return false;
            bool flag = menuids.RoleId == roleId;
            bool flagmenu = menuids.MenuId.Any(c => c == MenuId);
            return (flagmenu && flag) ? true : false;
        }

        /// <summary>
        /// 递归获取角色菜单按钮树形数据
        /// </summary>
        /// <param name="plistMenu">所有菜单和按钮</param>
        /// <param name="item">所有一级菜单</param>
        /// <param name="rMenus"></param>
        /// <param name="RoleId"></param>
        /// <param name="menuButtonsInfos">菜单按钮表中的所有该分店的按钮id集合</param>
        private void LoopFuncMenuData(List<EditMenuDto> plistMenu, RoleMenuRelation item, RoleMenuKvDto rMenus, int RoleId, List<MenuButtonsInfoDto> menuButtonsInfos, List<IntStringDicDto> rolemenubuids)
        {
            var subitems = plistMenu.Where(c => c.parent_id == item.MenuId).ToList();
            item.Children = new List<RoleMenuRelation>();
            var _listR = new List<RoleMenuRelation>();
            foreach (var sb in subitems)
            {
                var rr = new RoleMenuRelation
                {
                    AlwaysShow = sb.is_active == "Y" ? true : false,
                    Children = new List<RoleMenuRelation>(),
                    Component = sb.menu_layout,
                    IfCheck = (rMenus == null || RoleId <= 0) ? false : IFCheck(rMenus, sb.menu_id, RoleId),
                    isbutton = plistMenu.Any(a => a.menu_id == sb.menu_id && a.menu_level_type == -1),// ? true : false,
                    MenuId = sb.menu_id,
                    Meta = new Meta { Icon = sb.menu_icon, Title = sb.menu_name },
                    Title = sb.menu_name,
                    Name = sb.menu_code,
                    ParentId = sb.menu_id,
                    Path = sb.menu_url,
                    Redirect = "",
                    s_branch_id = sb.s_branch_id.Value,
                    lay_index = sb.menu_level_type.Value == -1 ? 4 : sb.menu_level_type.Value
                };
                _listR.Add(rr);
            }
            item.Children.AddRange(_listR);
            foreach (var _item in _listR)
            {
                LoopFuncMenuData(plistMenu, _item, rMenus, RoleId, menuButtonsInfos, rolemenubuids);
            }
        }

        #region old

        ///// <summary>
        ///// 角色菜单是否有勾选
        ///// </summary>
        ///// <param name="roleId">角色id</param>
        ///// <param name="btnid">菜单或者按钮id</param>
        ///// <param name="rolemenubuids">角色菜单按钮数据</param>
        ///// <returns></returns>
        //private bool IfThisButtonCheck(int roleId, int btnid, List<IntStringDicDto> rolemenubuids)
        //{
        //    if (roleId <= 0 || rolemenubuids == null)
        //        return false;
        //    var haveRm = rolemenubuids.Where(c => c.role_id == roleId && c.menu_id == btnid).FirstOrDefault();
        //    return haveRm != null;
        //} 
        #endregion

        /// <summary>
        /// 加载角色对应的所有菜单
        /// </summary>
        /// <param name="roleId"></param>
        /// <param name="s_branch_id"></param>
        /// <returns></returns>
        private async Task<RoleMenuKvDto> LoadRoleMens(int roleId, int s_branch_id)
        {
            var datas = await DbScoped.Sugar.Queryable<SsysRoleMenuEntity>().Where(c => c.role_id == roleId && c.s_branch_id == s_branch_id).ToListAsync();
            if (datas.Any())
            {
                var dto = new RoleMenuKvDto
                {
                    RoleId = roleId,
                    MenuId = datas.Select(c => c.menu_id).ToList()
                };
                return dto;
            }
            else
                return null;
        }


        /// <summary>
        /// 新增或编辑角色对应的菜单等关系数据 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<int> AddRoleMenus(AddRoleMenuDto dto)
        {
            // var user = CeChengTokenHelper.GetTockenUserInfo(_httpContext.HttpContext);
            var flag = await DbScoped.Sugar.UseTranAsync(async () =>
            {
                //1：先删除之前的数据
                int count = await DbScoped.Sugar.Deleteable<SsysRoleMenuEntity>().Where(c => c.role_id == dto.RoleId && c.s_branch_id == dto.s_branch_id).ExecuteCommandAsync();
                //2：新增目前的数据
                int insertCount = 0;
                if (dto.MenuId.Any())
                {
                    var time = DateTime.Now;
                    var list = new List<SsysRoleMenuEntity>();
                    foreach (var item in dto.MenuId)
                    {
                        var entity = new SsysRoleMenuEntity
                        {
                            is_active = IsActivityConstStr.Y,
                            menu_id = item,
                            role_id = dto.RoleId,
                            s_branch_id = dto.s_branch_id,
                            create_date = time,
                            create_user_wno = _userTokenInfo.UserWorkNo
                        };
                        list.Add(entity);
                    }
                    insertCount = await DbScoped.Sugar.Insertable<SsysRoleMenuEntity>(list).ExecuteCommandAsync();
                }
                return insertCount > 0;
            });
            return flag.Data ? 1 : 0;
        }

        #endregion
    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 部门接口实现
    /// </summary>
    public class SysDepartmentService: ISysDepartmentInterface
    {
        /// <summary>
        /// 新增部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSysDepartmentAsync(SysDepartmentDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysDepartmentEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.dept_no == dto.dept_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<SysDepartmentEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSysDepartmentAsync(SysDepartmentDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysDepartmentEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.dept_no == dto.dept_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<SysDepartmentEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<SysDepartmentEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysDepartmentSearchResultDto>>> QuerySysDepartmentAsync(SysDepartmentSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and dp.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and dp.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.dept_no))
            {
                sWhere += " and dp.dept_no = @dept_no";
                listSqlParam.Add(new SugarParameter("@dept_no", dto.dept_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.dept_name))
            {
                sWhere += " and dp.dept_name like '%' + @dept_name + '%'";
                listSqlParam.Add(new SugarParameter("@dept_name", dto.dept_name));
            }
            if (null != dto && dto.s_sys_department_type_id.HasValue)
            {
                sWhere += " and dp.s_sys_department_type_id = @s_sys_department_type_id";
                listSqlParam.Add(new SugarParameter("@s_sys_department_type_id", dto.s_sys_department_type_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and dp.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_sys_department dp
                                           left join s_sys_department_type dt on dp.s_sys_department_type_id = dt.id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by dp.id desc) as row_no,
                                            dp.id, dp.dept_no, dp.dept_name, dp.s_sys_department_type_id, dp.i_sort, 
                                            dp.create_date, dp.update_date, dp.create_user_wno, dp.update_user_wno, dp.s_branch_id, dp.is_active,
                                            dt.dept_type
                                    from   s_sys_department dp
                                           left join s_sys_department_type dt on dp.s_sys_department_type_id = dt.id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SysDepartmentSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SysDepartmentSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSysDepartmentAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from s_sys_department  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除部门类别
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveSysDepartmentAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from s_sys_department  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 套餐明细接口实现
    /// </summary>
    public class SysCombDetailService : ISysCombDetailInterface
    {
        /// <summary>
        /// 新增套餐明细
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSysCombDetailAsync(SysCombDetailDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysCombDetailEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.comb_detail_code == dto.comb_detail_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<SysCombDetailEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑套餐明细
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSysCombDetailAsync(SysCombDetailDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysCombDetailEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.comb_detail_code == dto.comb_detail_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<SysCombDetailEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<SysCombDetailEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询套餐明细
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysCombDetailSearchResultDto>>> QuerySysCombDetailAsync(SysCombDetailSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and scd.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and scd.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.comb_detail_code))
            {
                sWhere += " and scd.comb_detail_code = @comb_detail_code";
                listSqlParam.Add(new SugarParameter("@comb_detail_code", dto.comb_detail_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.comb_detail_type))
            {
                sWhere += " and scd.comb_detail_type like '%' + @comb_detail_type + '%'";
                listSqlParam.Add(new SugarParameter("@comb_detail_type", dto.comb_detail_type));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.item_no))
            {
                sWhere += " and scd.item_no = @item_no";
                listSqlParam.Add(new SugarParameter("@item_no", dto.item_no));
            }
            if (null != dto && dto.type.HasValue)
            {
                sWhere += " and scd.type = @type ";
                listSqlParam.Add(new SugarParameter("@type", dto.type));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_need))
            {
                sWhere += " and scd.is_need = @is_need";
                listSqlParam.Add(new SugarParameter("@is_need", dto.is_need));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and scd.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            if (null != dto && dto.s_sys_comb_id.HasValue)
            {
                sWhere += " and scd.s_sys_comb_id = @s_sys_comb_id";
                listSqlParam.Add(new SugarParameter("@s_sys_comb_id", dto.s_sys_comb_id));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_sys_comb_detail scd
                                           left join s_sys_comb scb on scd.s_sys_comb_id = scb.id
                                           left join s_consume_item ci on ci.s_branch_id = scd.s_branch_id and ci.consume_item_no = scd.item_no
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by scd.id desc) as row_no,
                                           scd.id, scd.s_sys_comb_id, scd.comb_detail_code, scd.comb_detail_type, scd.item_no, 
                                           scd.charge, scd.[type], scd.num, scd.is_need, scd.create_date, scd.update_date, 
                                           scd.create_user_wno, scd.update_user_wno, scd.is_active, scd.s_branch_id,
                                           scb.comb_code, scb.comb_name,
                                           consume_item_name = isnull(ci.consume_item_name, '')
                                    from   s_sys_comb_detail scd
                                           left join s_sys_comb scb on scd.s_sys_comb_id = scb.id
                                           left join s_consume_item ci on ci.s_branch_id = scd.s_branch_id and ci.consume_item_no = scd.item_no
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SysCombDetailSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SysCombDetailSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除套餐明细
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSysCombDetailAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_sys_comb_detail  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除套餐明细
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveSysCombDetailAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_sys_comb_detail  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

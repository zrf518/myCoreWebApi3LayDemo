﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 闸机类型接口实现
    /// </summary>
    public class ZaJiInfoTypeService : IZaJiInfoTypeInterface
    {
        /// <summary>
        /// 新增闸机类型
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddZaJiInfoTypeAsync(ZaJiInfoTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ZaJiInfoTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.i_port == dto.i_port && x.code == dto.code && x.s_type == dto.s_type)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编号、类型代码、方向组合重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<ZaJiInfoTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑闸机类型
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditZaJiInfoTypeAsync(ZaJiInfoTypeDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ZaJiInfoTypeEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.i_port == dto.i_port && x.code == dto.code && x.s_type == dto.s_type)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编号、类型代码、方向组合重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<ZaJiInfoTypeEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<ZaJiInfoTypeEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询闸机类型
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<ZaJiInfoTypeSearchResultDto>>> QueryZaJiInfoTypeAsync(ZaJiInfoTypeSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and zjt.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and zjt.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.i_port.HasValue)
            {
                sWhere += " and zjt.i_port = @i_port";
                listSqlParam.Add(new SugarParameter("@i_port", dto.i_port));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.code))
            {
                sWhere += " and zjt.code = @code ";
                listSqlParam.Add(new SugarParameter("@code", dto.code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_type))
            {
                sWhere += " and zjt.s_type = @s_type ";
                listSqlParam.Add(new SugarParameter("@s_type", dto.s_type));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.reader))
            {
                sWhere += " and zjt.reader = @reader ";
                listSqlParam.Add(new SugarParameter("@reader", dto.reader));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and zjt.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   zajinfo_type zjt
                                           left join s_sys_dictionary_info dic on dic.dictype=1002 and zjt.code=dic.diclabel
										   left join s_sys_dictionary_info dir on dir.dictype=1003 and zjt.s_type=dir.diclabel
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by zjt.id desc) as row_no,
                                           zjt.id, zjt.i_port, zjt.code, zjt.is_active, zjt.s_type, zjt.reader, zjt.create_date, 
                                           zjt.update_date, zjt.create_user_wno, zjt.update_user_wno, zjt.s_branch_id,
                                           code_name=dic.dicname,
                                           s_type_name=dir.dicname
                                    from   zajinfo_type zjt
                                           left join s_sys_dictionary_info dic on dic.dictype=1002 and zjt.code=dic.diclabel
										   left join s_sys_dictionary_info dir on dir.dictype=1003 and zjt.s_type=dir.diclabel
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<ZaJiInfoTypeSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<ZaJiInfoTypeSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除闸机类型
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveZaJiInfoTypeAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  zajinfo_type  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除闸机类型
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveZaJiInfoTypeAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  zajinfo_type  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

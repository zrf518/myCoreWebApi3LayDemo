﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 闸机设置接口实现
    /// </summary>
    public class ZaJiInfoService : IZaJiInfoInterface
    {
        /// <summary>
        /// 新增闸机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddZaJiInfoAsync(ZaJiInfoDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ZaJiInfoEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.i_port == dto.i_port)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编号重复");
            }

            var flag = await DbScoped.Sugar.UseTranAsync(async () =>
            {
                // 执行添加
                var result = await DbScoped.Sugar.Insertable<ZaJiInfoEntity>(dto).ExecuteCommandAsync();
                if (result < 1)
                    throw new Exception("闸机设置信息保存异常");

                // 删除可能存在的闸机类型数据
                var resDelType = await DbScoped.Sugar.Deleteable<ZaJiInfoTypeEntity>()
                    .Where(x => x.s_branch_id == dto.s_branch_id && x.i_port == dto.i_port)
                    .ExecuteCommandAsync();

                // 查询字典表里的“闸机类型设置表中的类型”
                var resQryZjType = await DbScoped.Sugar.Queryable<SysDictionaryInfoEntity>()
                    .Where(x => x.dictype == 1002 && x.isdelete == 0)
                    .ToListAsync();

                // 查询字典表里的“闸机类型设置表中的读头”
                var resQryReader = await DbScoped.Sugar.Queryable<SysDictionaryInfoEntity>()
                    .Where(x => x.dictype == 1006 && x.isdelete == 0)
                    .ToListAsync();

                // 要是数据不为空，就插入对应的默认的闸机类型数据
                if (null != resQryZjType && 0 < resQryZjType.Count 
                    && null != resQryReader && 0 < resQryReader.Count)
                {
                    List<ZaJiInfoTypeEntity> li = new List<ZaJiInfoTypeEntity>();
                    SysDictionaryInfoEntity objDefaultReader = resQryReader[0];
                    foreach (SysDictionaryInfoEntity objZjType in resQryZjType)
                    {
                        ZaJiInfoTypeEntity objZaJiInfoTypeEntity_in = new ZaJiInfoTypeEntity();
                        objZaJiInfoTypeEntity_in.create_date = DateTime.Now;
                        objZaJiInfoTypeEntity_in.create_user_wno = dto.create_user_wno;
                        objZaJiInfoTypeEntity_in.s_branch_id = dto.s_branch_id;
                        objZaJiInfoTypeEntity_in.i_port = dto.i_port;
                        objZaJiInfoTypeEntity_in.code = objZjType.diclabel;
                        objZaJiInfoTypeEntity_in.s_type = "I";
                        objZaJiInfoTypeEntity_in.reader = objDefaultReader.diclabel;
                        objZaJiInfoTypeEntity_in.is_active = "N";
                        li.Add(objZaJiInfoTypeEntity_in);

                        ZaJiInfoTypeEntity objZaJiInfoTypeEntity_out = new ZaJiInfoTypeEntity();
                        objZaJiInfoTypeEntity_out.create_date = DateTime.Now;
                        objZaJiInfoTypeEntity_out.create_user_wno = dto.create_user_wno;
                        objZaJiInfoTypeEntity_out.s_branch_id = dto.s_branch_id;
                        objZaJiInfoTypeEntity_out.i_port = dto.i_port;
                        objZaJiInfoTypeEntity_out.code = objZjType.diclabel;
                        objZaJiInfoTypeEntity_out.s_type = "O";
                        objZaJiInfoTypeEntity_out.reader = objDefaultReader.diclabel;
                        objZaJiInfoTypeEntity_out.is_active = "N";
                        li.Add(objZaJiInfoTypeEntity_out);
                    }
                    // 批量插入
                    var resInsertTye = await DbScoped.Sugar.Insertable<ZaJiInfoTypeEntity>(li.ToArray())
                        .ExecuteCommandAsync();
                    if (resInsertTye < 1)
                        throw new Exception("闸机类型信息保存异常");
                }
            });

            if (flag.Data)
                return ApiResultDto.ToResultSuccess(data: true);
            else
                throw new Exception(flag.ErrorMessage);

            //return ApiResultDto.ToResultFail(data: false, msg: flag.ErrorMessage);
        }
        /// <summary>
        /// 编辑闸机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditZaJiInfoAsync(ZaJiInfoEditDto dto2)
        {
            // 闸机设置对象
            ZaJiInfoDto objZjInfoDto = dto2.objZaJiInfoDto;
            // 闸机类型设置对象
            List<ZaJiInfoTypeDto> objListZjTypeDto = dto2.objListZaJiInfoTypeDto;

            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<ZaJiInfoEntity>()
                    .Where(x => x.s_branch_id == objZjInfoDto.s_branch_id && x.id != objZjInfoDto.id && x.i_port == objZjInfoDto.i_port)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编号重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<ZaJiInfoEntity>().Where(x => x.id == objZjInfoDto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            objZjInfoDto.create_date = resQry.create_date;
            objZjInfoDto.create_user_wno = resQry.create_user_wno;
            objZjInfoDto.s_branch_id = resQry.s_branch_id;

            var flag = await DbScoped.Sugar.UseTranAsync(async () => 
            {
                // 执行更新
                var result = await DbScoped.Sugar.Updateable<ZaJiInfoEntity>(objZjInfoDto).ExecuteCommandAsync();
                if (result < 1)
                    throw new Exception("闸机设置信息更新异常");

                // 闸机类型更新
                if (null != objListZjTypeDto && 0 < objListZjTypeDto.Count)
                {
                    int i = 0;
                    string sSQL = string.Empty;
                    List<SugarParameter> listSqlParam = new List<SugarParameter>();
                    foreach (ZaJiInfoTypeDto objTypeDto in objListZjTypeDto)
                    {
                        i += 1;
                        if (objTypeDto.id > 0)
                        {
                            sSQL += $@"update zajinfo_type
                                       set    i_port=@i_port{i}, code=@code{i}, is_active=@is_active{i}, s_type=@s_type{i}, reader=@reader{i},
                                              update_date=getdate(), update_user_wno='{objZjInfoDto.update_user_wno}'
                                       where  id={objTypeDto.id};";
                        }
                        else // 新增的数据
                        {
                            sSQL += $@"insert into zajinfo_type(i_port, code, is_active, s_type, reader, create_date, create_user_wno, s_branch_id)
                                       values(@i_port{i}, @code{i}, @is_active{i}, @s_type{i}, @reader{i}, getdate(), '{objZjInfoDto.update_user_wno}', {objZjInfoDto.s_branch_id});";
                        }

                        listSqlParam.Add(new SugarParameter($@"@i_port{i}", objTypeDto.i_port));
                        listSqlParam.Add(new SugarParameter($@"@code{i}", objTypeDto.code));
                        listSqlParam.Add(new SugarParameter($@"@is_active{i}", objTypeDto.is_active));
                        listSqlParam.Add(new SugarParameter($@"@s_type{i}", objTypeDto.s_type));
                        listSqlParam.Add(new SugarParameter($@"@reader{i}", objTypeDto.reader));
                    }

                    var resUpdateType = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sSQL, listSqlParam);
                    if (resUpdateType < 1)
                        throw new Exception("闸机类型设置信息更新异常");
                }
            });

            if (flag.Data)
                return ApiResultDto.ToResultSuccess(data: true);
            else
                throw new Exception(flag.ErrorMessage);

            //return ApiResultDto.ToResultFail(data: false, msg:flag.ErrorMessage);
        }
        /// <summary>
        /// 查询闸机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<ZaJiInfoSearchResultDto>>> QueryZaJiInfoAsync(ZaJiInfoSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and zj.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and zj.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.i_port.HasValue)
            {
                sWhere += " and zj.i_port = @i_port";
                listSqlParam.Add(new SugarParameter("@i_port", dto.i_port));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_remark))
            {
                sWhere += " and zj.s_remark like '%' + @s_remark + '%'";
                listSqlParam.Add(new SugarParameter("@s_remark", dto.s_remark));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.s_ip))
            {
                sWhere += " and zj.s_ip like '%' + @s_ip + '%'";
                listSqlParam.Add(new SugarParameter("@s_ip", dto.s_ip));
            }
            if (null != dto && dto.s_no.HasValue)
            {
                sWhere += " and zj.s_no = @s_no";
                listSqlParam.Add(new SugarParameter("@s_no", dto.s_no));
            }
            // 根据过闸机录入项目信息查询 
            if(null != dto && !string.IsNullOrWhiteSpace(dto.consume_item_name))
            {
                sWhere += " and ci.consume_item_name like '%' + @consume_item_name + '%'";
                listSqlParam.Add(new SugarParameter("@consume_item_name", dto.consume_item_name));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and zj.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   zajinfo zj
	                                       left join s_sys_dictionary_info sdi on sdi.dictype = 1003 and zj.s_type = sdi.diclabel
	                                       left join s_consume_item ci on zj.s_no = ci.id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by zj.id desc) as row_no,
                                           zj.id, zj.s_no, zj.s_ip, zj.s_type, zj.s_remark, zj.i_port, zj.IsDinner, zj.screen_token_in, zj.screen_token_out, 
                                           zj.is_active, zj.create_date, zj.update_date, zj.create_user_wno, zj.update_user_wno, zj.s_branch_id,
	                                       s_type_name=sdi.dicname,
	                                       ci.consume_item_no,
	                                       ci.consume_item_name
                                    from   zajinfo zj
	                                       left join s_sys_dictionary_info sdi on sdi.dictype = 1003 and zj.s_type = sdi.diclabel
	                                       left join s_consume_item ci on zj.s_no = ci.id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<ZaJiInfoSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<ZaJiInfoSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除闸机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveZaJiInfoAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from zajinfo_type where i_port in (select i_port from  zajinfo where id= " + id + "); delete from  zajinfo  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除闸机设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveZaJiInfoAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from zajinfo_type where i_port in (select i_port from zajinfo where id in (" + sWhere + ")); delete from  zajinfo  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

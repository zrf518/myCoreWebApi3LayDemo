﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 读卡器设置接口实现
    /// </summary>
    public class CardReaderService : ICardReaderInterface
    {
        /// <summary>
        /// 新增读卡器设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddCardReaderAsync(CardReaderDto dto)
        {
            // 执行添加
            var result = await DbScoped.Sugar.Insertable<CardReaderEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑读卡器设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditCardReaderAsync(CardReaderDto dto)
        {
            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<CardReaderEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<CardReaderEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询读卡器设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<CardReaderSearchResultDto>>> QueryCardReaderAsync(CardReaderSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and cr.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and cr.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.s_ipaddress.HasValue)
            {
                sWhere += " and cr.s_ipaddress = @s_ipaddress";
                listSqlParam.Add(new SugarParameter("@s_ipaddress", dto.s_ipaddress));
            }
            if (null != dto && dto.CardReader.HasValue)
            {
                sWhere += " and cr.CardReader = @CardReader";
                listSqlParam.Add(new SugarParameter("@CardReader", dto.CardReader));
            }
            if (null != dto && dto.ReaderType.HasValue)
            {
                sWhere += " and cr.ReaderType = @ReaderType";
                listSqlParam.Add(new SugarParameter("@ReaderType", dto.ReaderType));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and cr.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   CardReader cr
                                           left join s_sys_dictionary_info dic on dic.dictype=1004 and cr.CardReader = dic.dicid
                                           left join s_sys_dictionary_info dim on dim.dictype=1005 and cr.ReaderType = dim.dicid
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by cr.id desc) as row_no,
                                           cr.id, cr.s_ipaddress, cr.CardReader, cr.ReaderType, cr.Point, cr.is_active, cr.create_date, 
                                           cr.update_date, cr.create_user_wno, cr.update_user_wno, cr.s_branch_id,
                                           sIpAddressName  = cp.s_ipaddress,
                                           sCardReaderName = dic.dicname,
                                           sReaderTypeName = dim.dicname
                                    from   CardReader cr
                                           left join ct_pc cp on cr.s_ipaddress = cp.id
                                           left join s_sys_dictionary_info dic on dic.dictype=1004 and cr.CardReader = dic.dicid
                                           left join s_sys_dictionary_info dim on dim.dictype=1005 and cr.ReaderType = dim.dicid
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<CardReaderSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<CardReaderSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除读卡器设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveCardReaderAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  CardReader  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除读卡器设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveCardReaderAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  CardReader  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

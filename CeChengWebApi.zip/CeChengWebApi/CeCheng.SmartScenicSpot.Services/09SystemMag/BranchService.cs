﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 分店接口实现
    /// </summary>
    public class BranchService : IBranchInterface
    {
        /// <summary>
        /// 新增分店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddBranchAsync(BranchDto dto)
        {
            if ("Y" == dto.is_store) // 不允许直接插入总店的表，总店的表由集团接口那边生成
            {
                return ApiResultDto.ToResultFail(data: false, msg: "不允许直接插入总店的表，总店表由注册集团信息的时候自动生成");
            }

            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<BranchEntity>()
                .Where(x => ("Y" == dto.is_store && x.is_store == dto.is_store && x.branch_no == dto.branch_no) // 插入的总店号不能和已有的其它公司的总店号相同 
                         || ("N" == dto.is_store && x.group_id == dto.group_id && x.branch_no == dto.branch_no) // 插入的分店号不能和已有的本公司的店号相同（包括总店的） 
                )
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            if("Y" != dto.is_store) // 分店时候，查看总店是否存在，不存在就不让插入
            {
                var resFdQry = await DbScoped.Sugar.Queryable<BranchEntity>().
                    Where(x => "Y" == x.is_store && x.group_id == dto.group_id)
                    .SingleAsync();
                if (null == resFdQry)
                {
                    return ApiResultDto.ToResultFail(data: false, msg: "总店信息不存在");
                }
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<BranchEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑分店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditBranchAsync(BranchDto dto)
        {
            // 是否有总店变分店、分店变成总店的情况判断
            var resQryTestZd = await DbScoped.Sugar.Queryable<BranchEntity>()
                .Where(x => x.id == dto.id && x.is_store != dto.is_store)
                .SingleAsync();
            if (null != resQryTestZd)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "“是否是总店”这个字段值不能改变");
            }

            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<BranchEntity>()
                .Where(x => ("Y" == dto.is_store && x.is_store == dto.is_store && x.id != dto.id && x.branch_no == dto.branch_no) // 插入的总店号不能和已有的其它公司的总店号相同                                                                                                      //        
                         || (x.group_id == dto.group_id && x.id != dto.id && x.branch_no == dto.branch_no) // 插入的(总)分店号不能和已有的本公司的店号相同（包括总店的） 
                )
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<BranchEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }

            // 更新语句
            string sqlUpdate = $@"
                                update s_branch
                                set    group_id=@group_id, 
                                       branch_no=@branch_no, branch_name=@branch_name, branch_telephone=@branch_telephone, branch_address=@branch_address,
                                       latitude=@latitude, longitude=@longitude, update_user_wno=@update_user_wno, update_date=getdate(),
                                       is_active=@is_active, interface_url=@Interface_url, reg_code=@reg_code
                                where  id=@id
                                ;
                            ";

            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            listSqlParam.Add(new SugarParameter("@id", dto.id));
            listSqlParam.Add(new SugarParameter("@group_id", dto.group_id));
            listSqlParam.Add(new SugarParameter("@branch_no", dto.branch_no));
            listSqlParam.Add(new SugarParameter("@branch_name", dto.branch_name));
            listSqlParam.Add(new SugarParameter("@branch_telephone", dto.branch_telephone));
            listSqlParam.Add(new SugarParameter("@branch_address", dto.branch_address));
            listSqlParam.Add(new SugarParameter("@latitude", dto.latitude));
            listSqlParam.Add(new SugarParameter("@longitude", dto.longitude));
            listSqlParam.Add(new SugarParameter("@is_store", dto.is_store));
            listSqlParam.Add(new SugarParameter("@update_user_wno", dto.update_user_wno));
            listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            listSqlParam.Add(new SugarParameter("@interface_url", dto.interface_url));
            listSqlParam.Add(new SugarParameter("@reg_code", dto.reg_code));

            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sqlUpdate, listSqlParam);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 查询分店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<BranchSearchResultDto>>> QueryBranchAsync(BranchSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.id != 0)
            {
                sWhere += " and br.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.group_id.HasValue)
            {
                sWhere += " and br.group_id = @group_id";
                listSqlParam.Add(new SugarParameter("@group_id", dto.group_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.group_no))
            {
                sWhere += " and gp.group_no = @group_no";
                listSqlParam.Add(new SugarParameter("@group_no", dto.group_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.group_name))
            {
                sWhere += " and gp.group_name like '%' + @group_name + '%'";
                listSqlParam.Add(new SugarParameter("@group_name", dto.group_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.group_telephone))
            {
                sWhere += " and gp.group_telephone like '%' + @group_telephone + '%'";
                listSqlParam.Add(new SugarParameter("@group_telephone", dto.group_telephone));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.group_address))
            {
                sWhere += " and gp.group_address like '%' + @group_address + '%'";
                listSqlParam.Add(new SugarParameter("@group_address", dto.group_address));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.branch_no))
            {
                sWhere += " and br.branch_no = @branch_no";
                listSqlParam.Add(new SugarParameter("@branch_no", dto.branch_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.branch_name))
            {
                sWhere += " and br.branch_name like '%' + @branch_name + '%'";
                listSqlParam.Add(new SugarParameter("@branch_name", dto.branch_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.branch_telephone))
            {
                sWhere += " and br.branch_telephone like '%' + @branch_telephone + '%'";
                listSqlParam.Add(new SugarParameter("@branch_telephone", dto.branch_telephone));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.branch_address))
            {
                sWhere += " and br.branch_address like '%' + @branch_address + '%'";
                listSqlParam.Add(new SugarParameter("@branch_address", dto.branch_address));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_store))
            {
                sWhere += " and br.is_store = @is_store";
                listSqlParam.Add(new SugarParameter("@is_store", dto.is_store));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and br.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select  iCount = count(*)
                                    from    s_branch br
                                            left join s_group gp on br.group_id = gp.id
                                    where   1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by br.id desc) as row_no,
                                            br.id, br.group_id,
                                            gp.group_no, gp.group_name, gp.group_telephone, gp.group_address, 
                                            br.branch_no, br.branch_name, br.branch_telephone, br.branch_address, 
                                            br.latitude, br.longitude, br.is_store, br.create_user_wno, br.create_date, 
                                            br.update_user_wno, br.update_date, br.is_active, br.Interface_url, br.reg_code
                                    from    s_branch br
                                            left join s_group gp on br.group_id = gp.id
                                    where   1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                            order by row_no  
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<BranchSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<BranchSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除分店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveBranchAsync(string sUserWorkNo, int id)
        {
            // 分店的，只改状态，不删除
            string sql = "delete from s_branch  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除分店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveBranchAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            // 分店的，只改状态，不删除
            string sql = "delete from s_branch  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}


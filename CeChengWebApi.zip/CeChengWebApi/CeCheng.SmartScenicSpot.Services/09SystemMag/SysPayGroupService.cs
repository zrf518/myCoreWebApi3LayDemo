﻿using AutoMapper;
using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using CeCheng.SmartScenicSpot.Models.Data.KeyValueDtos;
using Microsoft.AspNetCore.Http;
using NPOI.SS.Formula.Functions;
using NPOI.SS.UserModel;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 支付组接口实现
    /// </summary>
    public class SysPayGroupService : CeChengBaseWithMapperService, ISysPayGroupInterface
    {
        public SysPayGroupService(IHttpContextAccessor httpContextAccessor, IMapper mapper) : base(httpContextAccessor, mapper)
        {
        }
        /// <summary>
        /// 新增支付组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSysPayGroupAsync(SysPayGroupDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysPayGroupEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.code == dto.code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<SysPayGroupEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑支付组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSysPayGroupAsync(SysPayGroupDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysPayGroupEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.code == dto.code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<SysPayGroupEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<SysPayGroupEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询支付组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysPayGroupDto>>> QuerySysPayGroupAsync(SysPayGroupDto dto)
        {
            var listdata = new List<SysPayGroupDto>();//SysPayGroupDto, SysPayGroupEntity
            var tcount = new RefAsync<int>();
            var _data = await DbScoped.Sugar.Queryable<SysPayGroupEntity>()
                   .WhereIF(dto.name.IsNotNullOrEmpty(), c => c.name.Contains(dto.name))
                   .WhereIF(dto.code.IsNotNullOrEmpty(), c => c.code == dto.code)
                   .WhereIF(dto.depart.IsNotNullOrEmpty(), c => c.depart.Contains(dto.depart))
                   .WhereIF(dto.IsActive.IsNotNullOrEmpty(), c => c.IsActive == dto.IsActive)
                   .WhereIF(dto.s_stype.IsNotNullOrEmpty(), c => c.s_stype == dto.s_stype)
                   .WhereIF(dto.s_type.IsNotNullOrEmpty(), c => c.s_type.Contains(dto.s_type))
                   .WhereIF(dto.IsActive.IsNotNullOrEmpty(), c => c.IsActive == dto.IsActive)
                   .ToPageListAsync(dto.pageIndex, dto.pageSize, tcount);
            if (tcount.Value > 0)
            {
                var _entity = _Mapper.Map<List<SysPayGroupEntity>, List<SysPayGroupDto>>(_data);

                listdata.AddRange(_entity);
                listdata = listdata.OrderBy(c => c.s_type).ThenBy(c => c.s_stype).ToList();
            }
            return ApiResultPageNationTDataDto<List<SysPayGroupDto>>.ToResultSuccess(PageIndex: dto.pageIndex, PageSize: dto.pageSize, data: listdata, TotalRow: tcount.Value);
        }

        /// <summary>
        /// 获取我们支付类型，方便页面绑定下拉关系
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> GetPayGroup()
        {
            var getPayGroups = await DbScoped.Sugar.Queryable<SysPayGroupEntity>().WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .Where(c => c.IsActive == IsActivityConstStr.Y).Select(c => new DicKeyValueDto { id = c.id, name = c.code+" "+c.name }).ToListAsync();
            return ApiResultDto.ToResultSuccess(data: getPayGroups);
        }



        /// <summary>
        /// 删除支付组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSysPayGroupAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from CC_proctype  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除支付组
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveSysPayGroupAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from CC_proctype  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 根据付款方式代码，查对应的付款方式组
        /// </summary>
        /// <returns></returns>
        public List<ZongHeSysPayGroupDto> QuerySysPayGroupByPayCode(PayCodeDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and pc.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.pay_code))
            {
                sWhere += " and pc.pay_code = @pay_code";
                listSqlParam.Add(new SugarParameter("@pay_code", dto.pay_code));
            }
            #endregion

            #region 查询语句
            // 查询明细
            string sqlQuery = $@"
                                    select pg.id, pg.code, pg.name, pg.s_type, pg.s_stype, pg.depart, pg.n_sort, pg.IsActive, 
                                           pg.create_date, pg.update_date, pg.create_user_wno, pg.update_user_wno, pg.s_branch_id,
                                           pay_code=pc.pay_code,
		                                   pay_code_name=pc.describe,
		                                   pay_code_group=''
                                    from   CC_proctype pg
                                           inner join s_pay_code pc on pc.cc_proctype_id = pg.id 
                                    where  pg.IsActive = 'Y' 
                                           {sWhere}
                                ";
            #endregion

            var result = DbScoped.Sugar.Ado.SqlQuery<ZongHeSysPayGroupDto>(sqlQuery, listSqlParam);
            return result;
        }

        /// <summary>
        /// 根据支付组代码，查对应的支付组组
        /// </summary>
        /// <returns></returns>
        public List<SysPayGroupEntity> QuerySysPayGroupByCode(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return null;
            }
            var resQry = DbScoped.Sugar.Queryable<SysPayGroupEntity>().Where(c => c.IsActive == "Y" && c.code == code).ToList();
            return resQry;
        }
    }
}

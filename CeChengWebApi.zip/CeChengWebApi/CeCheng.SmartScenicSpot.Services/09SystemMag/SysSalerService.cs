﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 销售员接口实现
    /// </summary>
    public class SysSalerService : ISysSalerInterface
    {
        /// <summary>
        /// 新增销售员
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSysSalerAsync(SysSalerDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysSalerEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.sale_work_no == dto.sale_work_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "销售员编号重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<SysSalerEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑销售员
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSysSalerAsync(SysSalerDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysSalerEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.sale_work_no == dto.sale_work_no)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "销售员编号重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<SysSalerEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<SysSalerEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询销售员
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysSalerSearchResultDto>>> QuerySysSalerAsync(SysSalerSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and ss.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and ss.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sale_work_no))
            {
                sWhere += " and ss.sale_work_no = @sale_work_no";
                listSqlParam.Add(new SugarParameter("@sale_work_no", dto.sale_work_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sale_name))
            {
                sWhere += " and ss.sale_name like '%' + @sale_name + '%'";
                listSqlParam.Add(new SugarParameter("@sale_name", dto.sale_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.webchart_id))
            {
                sWhere += " and ss.webchart_id like '%' + @webchart_id + '%'";
                listSqlParam.Add(new SugarParameter("@webchart_id", dto.webchart_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.webchart_name))
            {
                sWhere += " and ss.webchart_name like '%' + @webchart_name + '%'";
                listSqlParam.Add(new SugarParameter("@webchart_name", dto.webchart_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.telephone))
            {
                sWhere += " and ss.telephone like '%' + @telephone + '%'";
                listSqlParam.Add(new SugarParameter("@telephone", dto.telephone));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.address))
            {
                sWhere += " and ss.address like '%' + @address + '%'";
                listSqlParam.Add(new SugarParameter("@address", dto.address));
            }

            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_state))
            {
                sWhere += " and ss.is_state = @is_state";
                listSqlParam.Add(new SugarParameter("@is_state", dto.is_state));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.sex))
            {
                sWhere += " and ss.sex = @sex";
                listSqlParam.Add(new SugarParameter("@sex", dto.sex));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and ss.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_sys_saler ss
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by ss.id desc) as row_no,
		                                   ss.id, ss.is_active, ss.create_date, ss.update_date, ss.create_user_wno, ss.update_user_wno, 
		                                   ss.s_branch_id, ss.sale_work_no, ss.sale_name, ss.webchart_id, ss.webchart_name, ss.telephone, 
		                                   ss.sex, ss.[address], ss.is_state, ss.memo
                                    from   s_sys_saler ss
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SysSalerSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SysSalerSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除销售员
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSysSalerAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_sys_saler  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除销售员
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveSysSalerAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_sys_saler  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}


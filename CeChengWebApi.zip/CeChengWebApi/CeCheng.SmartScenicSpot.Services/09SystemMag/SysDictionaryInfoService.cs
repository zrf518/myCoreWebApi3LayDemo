﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 字典信息接口实现
    /// </summary>
    public class SysDictionaryInfoService: ISysDictionaryInfoInterface
    {
        /// <summary>
        /// 查询字典信息
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysDictionaryInfoDto>>> QuerySysDictionaryInfoAsync(SysDictionaryInfoDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.id != 0)
            {
                sWhere += " and id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.dicid.HasValue)
            {
                sWhere += " and dicid = @dicid";
                listSqlParam.Add(new SugarParameter("@dicid", dto.dicid));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.diclabel))
            {
                sWhere += " and diclabel = @diclabel";
                listSqlParam.Add(new SugarParameter("@diclabel", dto.diclabel));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.dicname))
            {
                sWhere += " and dicname like '%' + @dicname + '%'";
                listSqlParam.Add(new SugarParameter("@dicname", dto.dicname));
            }
            if (null != dto && dto.dictype.HasValue)
            {
                sWhere += " and dictype = @dictype";
                listSqlParam.Add(new SugarParameter("@dictype", dto.dictype));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.remark))
            {
                sWhere += " and remark like '%' + @remark + '%'";
                listSqlParam.Add(new SugarParameter("@remark", dto.remark));
            }
            if (null != dto && dto.isdelete.HasValue)
            {
                sWhere += " and isdelete = @isdelete";
                listSqlParam.Add(new SugarParameter("@isdelete", dto.isdelete));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.parames01))
            {
                sWhere += " and parames01 like '%' + @parames01 + '%'";
                listSqlParam.Add(new SugarParameter("@parames01", dto.parames01));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.parames02))
            {
                sWhere += " and parames02 like '%' + @parames02 + '%'";
                listSqlParam.Add(new SugarParameter("@parames02", dto.parames02));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_sys_dictionary_info
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by id desc) as row_no,
                                            id, dicid, diclabel, dicname, dictype, remark, isdelete, parames01, parames02
                                    from    s_sys_dictionary_info
                                    where   1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                   ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SysDictionaryInfoDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SysDictionaryInfoDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
    }
}

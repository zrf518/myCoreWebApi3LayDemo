﻿using AutoMapper;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Http;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using SqlSugar;
using System.Linq;
using CeCheng.SmartScenicSpot.Models.Data.KeyValueDtos;
using NPOI.SS.Formula.Functions;
using CeCheng.SmartScenicSpot.Commoms;
using Microsoft.AspNetCore.Mvc;

namespace CeCheng.SmartScenicSpot.Services
{
    public class RestaurantHolidaySpecialMainteService : CeChengBaseWithMapperService, IRestaurantHolidaySpecialMainteInterface
    {
        public RestaurantHolidaySpecialMainteService(IHttpContextAccessor httpContextAccessor, IMapper mapper) : base(httpContextAccessor, mapper)
        {
        }


        #region 餐厅设置
        /// <summary>
        /// 新增 餐厅设置
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> AddResauranData(SsysRestaurantAddDto dto)
        {
            var userinfo = base._UserTokenInfo;
            dto.create_date = DateTime.Now;
            dto.create_user_wno = userinfo.UserWorkNo;
            dto.s_branch_id = userinfo.SBranchId;
            dto.is_active = IsActivityConstStr.Y;
            var entityobj = base._Mapper.Map<SsysRestaurantAddDto, SsysRestaurantEntity>(dto);
            int count = await DbScoped.SugarScope.Insertable(entityobj).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        /// <summary>
        /// 编辑 餐厅设置
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> EditResauranData(SsysRestaurantEditDto dto)
        {
            var userinfo = base._UserTokenInfo;
            var getdbentity = await DbScoped.Sugar.Queryable<SsysRestaurantEntity>().WhereIF(userinfo.SysType <= 0, c => c.s_branch_id == userinfo.SBranchId).FirstAsync(c => c.id == dto.id);
            if (getdbentity != null)
            {
                dto.update_date = DateTime.Now;
                dto.update_user_wno = userinfo.UserWorkNo;
                dto.s_branch_id = userinfo.SBranchId;
                var entityobj = base._Mapper.Map<SsysRestaurantEditDto, SsysRestaurantEntity>(dto);
                entityobj.create_date = getdbentity.create_date;
                entityobj.create_user_wno = getdbentity.create_user_wno;
                int count = await DbScoped.SugarScope.Updateable(entityobj).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
                return ApiResultDto.ToResultFail(msg: "请检查编辑的id是否存在");
        }

        /// <summary>
        /// 查询 餐厅设置
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SsysRestaurantQueryDto>>> QueryResauranData(SsysRestaurantInputDto dto)
        {
            var totalcount = new RefAsync<int>();
            var _listdata = await DbScoped.Sugar.Queryable<SsysRestaurantEntity>()
                .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .WhereIF(dto.id > 0, c => c.id == dto.id)
                .WhereIF(!string.IsNullOrEmpty(dto.code), c => c.code == dto.code)
                .WhereIF(!string.IsNullOrEmpty(dto.restaurant_name), c => c.restaurant_name.Contains(dto.code))
                .WhereIF(dto.s_sys_department_id != null && dto.s_sys_department_id > 0, c => c.s_sys_department_id == dto.s_sys_department_id)
                .OrderBy(c => c.id, OrderByType.Desc)
                .ToPageListAsync(dto.pageIndex, dto.pageSize, totalcount);
            List<SsysRestaurantQueryDto> listdata = new List<SsysRestaurantQueryDto>();
            if (totalcount.Value > 0)
            {
                listdata = base._Mapper.Map<List<SsysRestaurantEntity>, List<SsysRestaurantQueryDto>>(_listdata);
                List<int> arryids = listdata.Select(c => c.s_sys_department_id.Value).Distinct().ToList();
                var getDepartNames = await DbScoped.Sugar.Queryable<SysDepartmentEntity>().Where(c => arryids.Contains(c.id)).Select(c => new DicKeyValueDto { id = c.id, name = c.dept_name }).ToListAsync();
                foreach (var item in listdata)
                    item.department_name = getDepartNames.FirstOrDefault(c => c.id == item.s_sys_department_id.Value)?.name;
            }
            return ApiResultPageNationTDataDto<List<SsysRestaurantQueryDto>>.ToResultSuccess(data: listdata, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: totalcount.Value);
        }
        /// <summary>
        /// 删除 餐厅设置
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveResauranData(QueryByIdDto dto)
        {
            int branchid = base._UserTokenInfo.SBranchId;
            int count = await DbScoped.Sugar.Deleteable<SsysRestaurantEntity>(c => c.id == dto.id && c.s_branch_id == branchid).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail(msg: "请检查id是否存在，或者分店ID错误");
        }
        #endregion


        #region 假日设置
        public async Task<ApiResultPageNationTDataDto<List<SsyssHoliDayEntity>>> QueryHoliday(SsyssHoliDayQueryInputDto dto)
        {
            var totalcount = new RefAsync<int>();
            var _listdata = await DbScoped.Sugar.Queryable<SsyssHoliDayEntity>()
                .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .WhereIF(!string.IsNullOrEmpty(dto.describe), c => c.describe.Contains(dto.describe))
                .WhereIF(!string.IsNullOrEmpty(dto.type), c => c.type.Contains(dto.type))
                .WhereIF(dto.start_date != null, c => c.start_date >= dto.start_date)
                .WhereIF(dto.end_date != null, c => c.end_date >= dto.end_date)
                .ToPageListAsync(dto.pageIndex, dto.pageSize, totalcount);
            return ApiResultPageNationTDataDto<List<SsyssHoliDayEntity>>.ToResultSuccess(data: _listdata, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: totalcount.Value);
        }
        public async Task<ApiResultDto> AddHoliday(SsyssHoliDayAddDto dto)
        {
            var userinfo = base._UserTokenInfo;
            dto.is_active = IsActivityConstStr.Y;
            var entityobj = base._Mapper.Map<SsyssHoliDayAddDto, SsyssHoliDayEntity>(dto);
            entityobj.create_date = DateTime.Now;
            entityobj.create_user_wno = userinfo.UserWorkNo;
            entityobj.s_branch_id = userinfo.SBranchId;

            int count = await DbScoped.SugarScope.Insertable(entityobj).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        public async Task<ApiResultDto> EditHoliday(SsyssHoliDayEditDto dto)
        {
            var userinfo = base._UserTokenInfo;
            var getdbentity = await DbScoped.Sugar.Queryable<SsyssHoliDayEntity>().WhereIF(userinfo.SysType <= 0, c => c.s_branch_id == userinfo.SBranchId).FirstAsync(c => c.id == dto.id);
            if (getdbentity != null)
            {
                var entityobj = base._Mapper.Map<SsyssHoliDayEditDto, SsyssHoliDayEntity>(dto);
                entityobj.update_date = DateTime.Now;
                entityobj.update_user_wno = userinfo.UserWorkNo;
                entityobj.s_branch_id = userinfo.SBranchId;
                entityobj.create_date = getdbentity.create_date;
                entityobj.create_user_wno = getdbentity.create_user_wno;
                int count = await DbScoped.SugarScope.Updateable(entityobj).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
                return ApiResultDto.ToResultFail(msg: "请检查编辑的id是否存在");
        }
        public async Task<ApiResultDto> RemoveHoliday(QueryByIdDto dto)
        {
            int branchid = base._UserTokenInfo.SBranchId;
            int count = await DbScoped.Sugar.Deleteable<SsyssHoliDayEntity>(c => c.id == dto.id && c.s_branch_id == branchid).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail(msg: "请检查id是否存在，或者分店ID错误");
        }

        #endregion

        #region 时段优惠设置
        public async Task<ApiResultDto> AddTimeDiscount(SayDiscTypeDto dto)
        {
            var userinfo = base._UserTokenInfo;
            var entityobj = base._Mapper.Map<SayDiscTypeDto, SayDiscTypeEntity>(dto);
            entityobj.is_active = IsActivityConstStr.Y;
            entityobj.create_date = DateTime.Now;
            entityobj.create_user_wno = userinfo.UserWorkNo;
            entityobj.s_branch_id = userinfo.SBranchId;

            int count = await DbScoped.SugarScope.Insertable(entityobj).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }

        public async Task<ApiResultDto> EditTimeDiscount(SayDiscTypeDto dto)
        {
            var userinfo = base._UserTokenInfo;
            var getdbentity = await DbScoped.Sugar.Queryable<SayDiscTypeEntity>().WhereIF(userinfo.SysType <= 0, c => c.s_branch_id == userinfo.SBranchId).FirstAsync(c => c.id == dto.id);
            if (getdbentity != null)
            {
                var entityobj = base._Mapper.Map<SayDiscTypeDto, SayDiscTypeEntity>(dto);
                entityobj.update_date = DateTime.Now;
                entityobj.update_user_wno = userinfo.UserWorkNo;
                entityobj.s_branch_id = userinfo.SBranchId;
                entityobj.create_date = getdbentity.create_date;
                entityobj.create_user_wno = getdbentity.create_user_wno;
                int count = await DbScoped.SugarScope.Updateable(entityobj).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
                return ApiResultDto.ToResultFail(msg: "请检查编辑的id是否存在");
        }

        public async Task<ApiResultDto> RemoveTimeDiscount(QueryByIdDto dto)
        {
            int branchid = base._UserTokenInfo.SBranchId;
            int count = await DbScoped.Sugar.Deleteable<SayDiscTypeEntity>(c => c.id == dto.id && c.s_branch_id == branchid).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail(msg: "请检查id是否存在，或者分店ID错误");
        }

        public async Task<ApiResultPageNationTDataDto<List<SayDiscTypeDto>>> QueryTimeDiscount(TimeDisCountInputQuery dto)
        {
            var totalcount = new RefAsync<int>();
            var _listdata = await DbScoped.Sugar.Queryable<SayDiscTypeEntity>()
                .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .WhereIF(dto.s_beg != null, c => c.s_beg >= dto.s_beg)
                .WhereIF(dto.s_end != null, c => c.s_end <= dto.s_end)
                .WhereIF(!string.IsNullOrEmpty(dto.s_beg_time), c => c.s_beg_time == dto.s_beg_time)
                .WhereIF(!string.IsNullOrEmpty(dto.s_end_time), c => c.s_end_time == dto.s_end_time)
                .WhereIF(!string.IsNullOrEmpty(dto.s_week), c => c.s_week.Contains(dto.s_week))
                .WhereIF(dto.disc_rate != null, c => c.disc_rate == dto.disc_rate)
                .WhereIF(dto.d_set_date != null, c => c.d_set_date >= dto.d_set_date && c.d_set_date <= dto.d_set_date.Value.GetCeChengEndTime())  // todo
                .ToPageListAsync(dto.pageIndex, dto.pageSize, totalcount);
            var listdata = new List<SayDiscTypeDto>();
            if (totalcount.Value > 0)
            {
                listdata = _Mapper.Map<List<SayDiscTypeEntity>, List<SayDiscTypeDto>>(_listdata);
            }
            return ApiResultPageNationTDataDto<List<SayDiscTypeDto>>.ToResultSuccess(data: listdata, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: totalcount.Value);
        }
        #endregion

        #region Week营销管理，周末设置
        /// <summary>
        /// 周末设置 新增
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> WeekSetAdd(SysWeekSetAddDto obj)
        {
            var entity = _Mapper.Map<SysWeekSetAddDto, SysWeekSetEntity>(obj);
            entity.create_date = DateTime.Now;
            entity.create_user_wno = _UserTokenInfo.UserWorkNo;
            entity.is_active = IsActivityConstStr.Y;
            int count = await DbScoped.SugarScope.Insertable<SysWeekSetEntity>(entity).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }

        /// <summary>
        /// 周末设置 修改
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> WeekSetEdit(SysWeekSetEditDto obj)
        {
            var getEntity = await DbScoped.SugarScope.Queryable<SysWeekSetEntity>().Where(c => c.auto_id == obj.auto_id).FirstAsync();
            if (getEntity != null && getEntity.auto_id > 0)
            {
                var entity = _Mapper.Map<SysWeekSetEditDto, SysWeekSetEntity>(obj);
                entity.update_date = DateTime.Now;
                entity.update_user_wno = _UserTokenInfo.UserWorkNo;
                entity.create_date = getEntity.create_date;
                entity.create_user_wno = getEntity.create_user_wno;
                int count = await DbScoped.SugarScope.Updateable<SysWeekSetEntity>(entity).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
                return ApiResultDto.ToResultFail();
        }

        /// <summary>
        /// 周末设置 查询
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysWeekSetEntity>>> WeekSetQuery(BasePageDto dto)
        {
            var totalcount = new RefAsync<int>();
            var _listdata = await DbScoped.Sugar.Queryable<SysWeekSetEntity>()
                .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .ToPageListAsync(dto.pageIndex, dto.pageSize, totalcount);
            return ApiResultPageNationTDataDto<List<SysWeekSetEntity>>.ToResultSuccess(data: _listdata, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: totalcount.Value);
        }

        /// <summary>
        /// 周末设置 删除
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> WeekSetRemove(QueryByIdDto obj)
        {
            var getEntity = await DbScoped.SugarScope.Queryable<SysWeekSetEntity>().Where(c => c.auto_id == obj.id).FirstAsync();
            if (getEntity != null && getEntity.auto_id > 0)
            {
                int count = await DbScoped.SugarScope.Deleteable<SysWeekSetEntity>(getEntity).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
                return ApiResultDto.ToResultFail();
        }

        #endregion
    }
}

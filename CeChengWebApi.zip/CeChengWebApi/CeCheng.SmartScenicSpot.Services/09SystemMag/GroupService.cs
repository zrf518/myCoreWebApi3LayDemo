﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 集团总店接口实现
    /// </summary>
    public class GroupService : IGroupInterface
    {
        /// <summary>
        /// 新增集团总店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddGroupAsync(GroupDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<GroupEntity>()
                .Where(x => x.group_no == dto.group_no) // 插入的总店号不能和已有的其它公司的总店号相同 
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            var flag = await DbScoped.Sugar.UseTranAsync(async () =>
            {
                // 执行添加
                var result = await DbScoped.Sugar.Insertable<GroupEntity>(dto).ExecuteCommandAsync();
                if (result < 1)
                    throw new Exception("集团总店信息保存异常");

                // 查看生成的ID
                var resQryID = await DbScoped.Sugar.Queryable<GroupEntity>()
                    .Where(x => x.group_no == dto.group_no)
                    .ToListAsync();

                BranchEntity objBranchEntity = new BranchEntity();
                objBranchEntity.create_date = DateTime.Now;
                objBranchEntity.create_user_wno = dto.create_user_wno;
                objBranchEntity.group_id = resQryID[0].id;
                objBranchEntity.branch_no = dto.group_no;
                objBranchEntity.branch_name = dto.group_name;
                objBranchEntity.branch_telephone = dto.group_telephone;
                objBranchEntity.branch_address = dto.group_address;
                objBranchEntity.latitude = dto.latitude;
                objBranchEntity.longitude = dto.longitude;
                objBranchEntity.is_store = "Y";
                objBranchEntity.is_active = dto.is_active;
                objBranchEntity.interface_url = dto.interface_url;
                objBranchEntity.reg_code = dto.reg_code;

                // 执行添加
                var resInsertBranch = await DbScoped.Sugar.Insertable<BranchEntity>(objBranchEntity).ExecuteCommandAsync();
                if (resInsertBranch < 1)
                    throw new Exception("集团总店总店信息生成保存异常");
            });

            if (flag.Data)
                return ApiResultDto.ToResultSuccess(data: true);
            else
                throw new Exception(flag.ErrorMessage);
        }

        /// <summary>
        /// 编辑集团总店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditGroupAsync(GroupDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<GroupEntity>()
                .Where(x => x.id != dto.id && x.group_no == dto.group_no) // 插入的总店号不能和已有的其它公司的总店号相同                                                                                                      //        
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<GroupEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }

            // 更新语句
            string sqlUpdate = $@"
                                    update s_Group
                                    set    group_no=@group_no, Group_name=@Group_name, Group_telephone=@Group_telephone, Group_address=@Group_address,
                                           latitude=@latitude, longitude=@longitude, update_user_wno=@update_user_wno, update_date=getdate(),
                                           is_active=@is_active, interface_url=@Interface_url, reg_code=@reg_code
                                    where  id=@id;

                                    update s_branch
                                    set    branch_no=@group_no, branch_name=@Group_name, branch_telephone=@Group_telephone, branch_address=@Group_address,
                                           latitude=@latitude, longitude=@longitude, update_user_wno=@update_user_wno, update_date=getdate(),
                                           is_active=@is_active, interface_url=@Interface_url, reg_code=@reg_code
                                    where  is_store='Y' and group_id=@id ;
                                    ;
                                ";

            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            listSqlParam.Add(new SugarParameter("@id", dto.id));
            listSqlParam.Add(new SugarParameter("@group_no", dto.group_no));
            listSqlParam.Add(new SugarParameter("@Group_name", dto.group_name));
            listSqlParam.Add(new SugarParameter("@Group_telephone", dto.group_telephone));
            listSqlParam.Add(new SugarParameter("@Group_address", dto.group_address));
            listSqlParam.Add(new SugarParameter("@latitude", dto.latitude));
            listSqlParam.Add(new SugarParameter("@longitude", dto.longitude));
            listSqlParam.Add(new SugarParameter("@update_user_wno", dto.update_user_wno));
            listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            listSqlParam.Add(new SugarParameter("@interface_url", dto.interface_url));
            listSqlParam.Add(new SugarParameter("@reg_code", dto.reg_code));
            listSqlParam.Add(new SugarParameter("@group_id", dto.id));

            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sqlUpdate, listSqlParam);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }

        /// <summary>
        /// 查询集团总店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<GroupSearchResultDto>>> QueryGroupAsync(GroupSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.id != 0)
            {
                sWhere += " and gp.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.group_no))
            {
                sWhere += " and gp.group_no = @group_no";
                listSqlParam.Add(new SugarParameter("@group_no", dto.group_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.group_name))
            {
                sWhere += " and gp.group_name like '%' + @group_name + '%'";
                listSqlParam.Add(new SugarParameter("@group_name", dto.group_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.group_telephone))
            {
                sWhere += " and gp.group_telephone like '%' + @group_telephone + '%'";
                listSqlParam.Add(new SugarParameter("@group_telephone", dto.group_telephone));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.group_address))
            {
                sWhere += " and gp.group_address like '%' + @group_address + '%'";
                listSqlParam.Add(new SugarParameter("@Group_address", dto.group_address));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and gp.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select  iCount = count(*)
                                    from    s_group gp
                                    where   1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select  row_number() over(order by gp.id desc) as row_no,
                                            gp.id,
                                            gp.group_no, gp.group_name, gp.group_telephone, gp.group_address, 
                                            gp.latitude, gp.longitude, gp.create_user_wno, gp.create_date, 
                                            gp.update_user_wno, gp.update_date, gp.is_active, gp.Interface_url, gp.reg_code
                                    from    s_group gp
                                    where   1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                            order by row_no  
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<GroupSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<GroupSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除集团总店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveGroupAsync(string sUserWorkNo, int id)
        {
            // 判断当前总店下是否有分店，有的话就不让删除
            var resQryTestFd = await DbScoped.Sugar.Queryable<BranchEntity>()
                .Where(x => x.group_id == id && x.is_store != "Y")
                .ToListAsync();
            if (null != resQryTestFd && 0 < resQryTestFd.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "总店下面还存在分店，不能直接删除总店");
            }
            // 删除集团总店及分店里面的总店信息
            string sql = "delete from s_group  where id=" + id + "; "
                       + "delete from s_branch where group_id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除集团总店
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveGroupAsync(string sUserWorkNo, List<int> ids)
        {
            // 判断当前总店下是否有分店，有的话就不让删除
            var resQryTestFd = await DbScoped.Sugar.Queryable<BranchEntity>()
                .Where(x => ids.Contains(x.group_id.Value) && x.is_store != "Y")
                .ToListAsync();
            if (null != resQryTestFd && 0 < resQryTestFd.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "总店下面还存在分店，不能直接删除总店");
            }
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            // 删除集团总店及分店里面的总店信息
            string sql = "delete from s_group  where id        in (" + sWhere + ");"
                       + "delete from s_branch where group_id  in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}



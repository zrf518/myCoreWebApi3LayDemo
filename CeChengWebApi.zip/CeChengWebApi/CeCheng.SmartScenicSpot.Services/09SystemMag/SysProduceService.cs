﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar.IOC;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 出品说明接口实现
    /// </summary>
    public class SysProduceService : ISysProduceInterface
    {
        /// <summary>
        /// 新增出品说明
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSysProduceAsync(SysProduceDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysProduceEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.produce_code == dto.produce_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<SysProduceEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑出品说明
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSysProduceAsync(SysProduceDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<SysProduceEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.produce_code == dto.produce_code)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<SysProduceEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user_wno = resQry.create_user_wno;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<SysProduceEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询出品说明
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<SysProduceSearchResultDto>>> QuerySysProduceAsync(SysProduceSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and sp.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and sp.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.produce_code))
            {
                sWhere += " and sp.produce_code = @produce_code";
                listSqlParam.Add(new SugarParameter("@produce_code", dto.produce_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.describe))
            {
                sWhere += " and sp.describe like '%' + @describe + '%'";
                listSqlParam.Add(new SugarParameter("@describe", dto.describe));
            }
            if (null != dto && dto.s_sys_produce_type_id.HasValue)
            {
                sWhere += " and sp.s_sys_produce_type_id = @s_sys_produce_type_id";
                listSqlParam.Add(new SugarParameter("@s_sys_produce_type_id", dto.s_sys_produce_type_id));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_sys_produce sp 
                                           left join s_sys_produce_type pt on sp.s_sys_produce_type_id = pt.id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by sp.id desc) as row_no,
                                           sp.id, sp.produce_code, sp.describe, sp.s_sys_produce_type_id, sp.create_date, sp.update_date, 
                                           sp.create_user_wno, sp.update_user_wno, sp.is_active, sp.s_branch_id,
                                           pt.produce_big_code, pt.produce_big_name
                                    from   s_sys_produce sp 
                                           left join s_sys_produce_type pt on sp.s_sys_produce_type_id = pt.id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<SysProduceSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<SysProduceSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除出品说明
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSysProduceAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from s_sys_produce  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除出品说明
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveSysProduceAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from s_sys_produce  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 门票设置接口实现
    /// </summary>
    public class TicketSetService : ITicketSetInterface
    {
        /// <summary>
        /// 新增门票设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddTicketSetAsync(TicketSetDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<TicketSetEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.ticket_code == dto.ticket_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<TicketSetEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑门票设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditTicketSetAsync(TicketSetDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<TicketSetEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.ticket_code == dto.ticket_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<TicketSetEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<TicketSetEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询门票设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<TicketSetSearchResultDto>>> QueryTicketSetAsync(TicketSetSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and ts.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and ts.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.ticket_code))
            {
                sWhere += " and ts.ticket_code = @ticket_code";
                listSqlParam.Add(new SugarParameter("@ticket_code", dto.ticket_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.ticket_name))
            {
                sWhere += " and ts.ticket_name like '%' + @ticket_name + '%'";
                listSqlParam.Add(new SugarParameter("@ticket_name", dto.ticket_name));
            }
            // 门票类型信息查询
            if (null != dto && dto.s_ticket_category_id.HasValue)
            {
                sWhere += " and ts.s_ticket_category_id = @s_ticket_category_id";
                listSqlParam.Add(new SugarParameter("@s_ticket_category_id", dto.s_ticket_category_id));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.category_code))
            {
                sWhere += " and tc.category_code = @category_code";
                listSqlParam.Add(new SugarParameter("@category_code", dto.category_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.category_name))
            {
                sWhere += " and tc.category_name like '%' + @category_name + '%'";
                listSqlParam.Add(new SugarParameter("@category_name", dto.category_name));
            }
            // 消费项目信息查询
            if (null != dto && dto.s_consume_item_id.HasValue)
            {
                sWhere += " and ts.s_consume_item_id = @s_consume_item_id";
                listSqlParam.Add(new SugarParameter("@s_consume_item_id", dto.s_consume_item_id));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.consume_item_no))
            {
                sWhere += " and ti.consume_item_no = @consume_item_no";
                listSqlParam.Add(new SugarParameter("@consume_item_no", dto.consume_item_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.item_name))
            {
                sWhere += " and ti.consume_item_name like '%' + @item_name + '%'";
                listSqlParam.Add(new SugarParameter("@item_name", dto.item_name));
            }
            // 付款方式
            if (null != dto && dto.s_pay_code_id.HasValue)
            {
                sWhere += " and ts.s_pay_code_id = @s_pay_code_id";
                listSqlParam.Add(new SugarParameter("@s_pay_code_id", dto.s_pay_code_id));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.pay_type))
            {
                sWhere += " and pc.pay_code = @pay_type";
                listSqlParam.Add(new SugarParameter("@pay_type", dto.pay_type));
            }
            // 营业点
            if (null != dto && dto.s_business_set_id.HasValue)
            {
                sWhere += " and oc.outlets_setup_id = @s_business_set_id";
                listSqlParam.Add(new SugarParameter("@s_business_set_id", dto.s_business_set_id));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.business_code))
            {
                sWhere += " and os.outlet_no = @business_code";
                listSqlParam.Add(new SugarParameter("@business_code", dto.business_code));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and ts.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_ticket_set ts
                                           left join s_ticket_category  tc on ts.s_ticket_category_id = tc.id
                                           left join s_ticket_item      ti on ts.s_ticket_category_id = ti.id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by ts.id desc) as row_no,
                                           ts.id, ts.ticket_code, ts.ticket_name, ts.s_ticket_category_id,  
                                           ts.face_value, ts.price, ts.amount_total, ts.amount_sale, ts.amount_use, ts.use_amount, 
                                           ts.send_amount, ts.s_consume_item_id, ts.begin_date, ts.end_date, 
                                           ts.[start_date], ts.use_end_date, ts.validate_date, ts.validate_day, ts.is_active, 
                                           ts.is_limite, ts.limite_amount, ts.s_pay_code_id, ts.[service], ts.is_cash, 
                                           ts.is_back, ts.s_week, ts.number, ts.use_today, ts.is_change_price, ts.is_send, ts.s_isiozj, 
                                           ts.is_show_automach, ts.sex, ts.price_weekday, ts.price_weekend, ts.price_holiday, ts.s_pyjm, 
                                           ts.begin_time, ts.end_time, ts.s_business_set_id, ts.ota_menu_no, 
                                           ts.s_branch_id, ts.create_date, ts.update_date, ts.create_user, ts.update_user, ts.memo, ts.sort,
	                                       tc.category_code, category_name = tc.category_name,
	                                       ti.consume_item_no, item_name = ti.consume_item_name,
                                           pay_type = pc.pay_code,
                                           s_pay_code_name = pc.describe,
                                           business_code = os.outlet_no,
                                           business_name = os.outlet_name
                                    from   s_ticket_set ts
                                           left join s_ticket_category  tc on ts.s_ticket_category_id = tc.id
                                           left join s_consume_item     ti on ts.s_consume_item_id = ti.id
                                           left join s_pay_code         pc on ts.s_pay_code_id = pc.id
                                           left join outlets_consume_item_set  oc on ts.id = oc.s_consume_item_id and oc.n_type = 1
                                           left join outlets_setup             os on os.id = oc.outlets_setup_id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<TicketSetSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<TicketSetSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除门票设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveTicketSetAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_ticket_set  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除门票设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveTicketSetAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_ticket_set  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}
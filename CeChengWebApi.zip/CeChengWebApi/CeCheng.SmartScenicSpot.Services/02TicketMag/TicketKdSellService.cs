﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using SqlSugar;
using SqlSugar.IOC;
using System.Linq;
using CeCheng.SmartScenicSpot.Commoms;
using AutoMapper;
using NPOI.POIFS.FileSystem;
using System.Runtime.InteropServices;
using NPOI.SS.Formula.Functions;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 02 票务管理相关模块  开单销售门票
    /// </summary>
    public class TicketKdSellService : CeChengBaseService, ITicketKdSellInterface
    {
        private readonly IMapper _mapper;
        public TicketKdSellService(IHttpContextAccessor httpContextAccessor, IMapper mapper) : base(httpContextAccessor)
        {
            this._mapper = mapper;
        }

        /// <summary>
        /// 获取开单 订单编号
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> CreateKdTicketSellNo()
        {
            var sellno = await CeChengBusinessFunctionHelper.GetSysNextNo(NextNumberIdentityEnum.ticket_sell_no);
            if (string.IsNullOrEmpty(sellno))
                return ApiResultDto.ToResultFail(msg: $"请检查该分店id:{_UserTokenInfo.SBranchId}没有配置系统相关参数");
            return ApiResultDto.ToResultSuccess(data: sellno);
        }

        /// <summary>
        ///销售门票 --开单新增  
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> AddKdTicket(STicketSellAddDto entity)
        {
            if (entity.n_KdType.HasValue && - 1 == entity.n_KdType.Value) // 开退票单
            {
                if (string.IsNullOrEmpty(entity.quit_sell_no))
                {
                    return ApiResultDto.ToResultFail(msg: "原被退票的单号不能为空");
                }
                if (null == entity.ticket_infos || 0 == entity.ticket_infos.Count || string.IsNullOrEmpty(entity.ticket_infos[0].ticket_code))
                {
                    return ApiResultDto.ToResultFail(msg: "被退的票信息不能为空");
                }
                var hisQuit = await DbScoped.SugarScope.Queryable<STicketSellRecordEntity>()
                    .InnerJoin<STitcketSellEntity>((c ,o) => c.s_titcket_sell_id == o.id 
                                                        && o.account_status == IsActivityConstStr.N 
                                                        && o.status != IsActivityConstStr.canselOrder 
                                                        && o.quit_sell_no == entity.quit_sell_no
                                                        && o.sell_no != entity.sell_no
                                                   )
                    .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                    .Where(c => c.pay_type == "D" && c.amount < 0 && c.ticket_code == entity.ticket_infos[0].ticket_code )
                    .ToListAsync();
                if (null != hisQuit && 0 < hisQuit.Count)
                {
                    return ApiResultDto.ToResultFail(msg: "还有退票单据未结");
                }
            }
            var ctime = DateTime.Now;
            var btime = await CeChengBusinessFunctionHelper.GetBusinessDateByBranchId(_UserTokenInfo.SBranchId);//营业日期
            var outName = await CeChengBusinessFunctionHelper.GetOutNameByOutId(_UserTokenInfo.outletId);
            var flag = await DbScoped.SugarScope.UseTranAsync<int>(async () =>
            {

                #region 查看是否包含预定单的信息，要是包含了，就检查使用的预定单是否有对应未处理好的单
                if (entity.s_ticket_booking_id.HasValue && entity.s_ticket_booking_id.Value > 0)
                {
                    // 判断预定单是否存在
                    var resQryBooking = await DbScoped.Sugar.Queryable<STicketsBookingEntity>()
                                        .Where(c => c.id == entity.s_ticket_booking_id && c.status.Value != 3)
                                        .ToListAsync();
                    if (null == resQryBooking || 0 == resQryBooking.Count)
                    {
                        throw new Exception("对应的可用的预定单不存在");
                    }
                    // 判断预定单的出票数量是否已经出完
                    var resQryBookingRecord = await DbScoped.Sugar.Queryable<STicketBookingRecordEntity>()
                                        .Where(c => c.s_ticket_booking_id == entity.s_ticket_booking_id)
                                        .ToListAsync();
                    if (null == resQryBookingRecord || 0 == resQryBookingRecord.Count)
                    {
                        throw new Exception("预定单里没有门票");
                    }
                    int iBookNum = 0; // 预定数量
                    int iGetOutNum = 0; // 已用的预定数量
                    foreach (STicketBookingRecordEntity oneBRecord in resQryBookingRecord)
                    {
                        iBookNum += oneBRecord.amount.HasValue ? oneBRecord.amount.Value : 0;
                        iGetOutNum += oneBRecord.ticket_numer.HasValue ? oneBRecord.ticket_numer.Value : 0;
                    }
                    if (iBookNum == 0 || iBookNum <= iGetOutNum)
                    {
                        throw new Exception("预定票已用完");
                    }
                    // 判断使用的预订单是否有未出票的单，有的话就先不让开新单
                    var resQryLinkBook = await DbScoped.SugarScope.Queryable<STitcketSellEntity>()
                                    .Where(c => c.s_ticket_booking_id == entity.s_ticket_booking_id && c.status == "N")
                                    .ToListAsync();
                    if (null != resQryLinkBook && 0 < resQryLinkBook.Count)
                    {
                        throw new Exception("当前使用的预定单还有未出票的单，不能开新单");
                    }
                }
                #endregion
                int gmainid = 0;
                var enrityM = await DbScoped.SugarScope.Queryable<STitcketSellEntity>().Where(c => c.sell_no == entity.sell_no).FirstAsync();
                if (enrityM != null && enrityM.id > 0)
                {
                    if (enrityM.status == IsActivityConstStr.canselOrder || enrityM.status == IsActivityConstStr.Y || enrityM.account_status == IsActivityConstStr.Y)//已付款或者已经出票
                        throw new Exception("已付款或者已经出票、已取消的订单不可以修改等操作");
                    await DbScoped.SugarScope.Deleteable<STicketSellRecordEntity>().Where(c => c.s_titcket_sell_id == enrityM.id && c.pay_type.ToUpper() != "C").ExecuteCommandAsync();

                    // 修改单据总金额信息
                    await DbScoped.SugarScope.Updateable<STitcketSellEntity>(enrityM).ExecuteCommandAsync();
                }
                else
                {
                    var main_entity = new STitcketSellEntity
                    {
                        booking_no = entity.booking_no,//缺少页面原型
                        cancel_date = entity.cancel_date,
                        Is_acctont_uecret = entity.Is_acctont_uecret,
                        Is_ticket_secret = entity.Is_ticket_secret,
                        regcard_id = entity.regcard_id,//会员卡id ，后续会员支付的才会有 ??
                        memo = entity.memo,//当着总票数来使用 entity.memo,
                        order_amount = entity.order_amount,//订单金额 应该是一个总的金额 必填
                        order_date = ctime,// entity.order_date,
                        ota_ordername = entity.ota_ordername,
                        ota_order_id = entity.ota_order_id,
                        ota_telephone = entity.ota_telephone,
                        pay_amount = 0,// entity.pay_amount,
                        pay_date = null,// entity.pay_date,
                        pay_type = IsActivityConstStr.xf,//默认消费D D:表示还没有支付, 该字段冗余了
                        platform_code = entity.platform_code,
                        platform_name = entity.platform_name,
                        refound_amount = entity.refound_amount,
                        s_ticket_booking_id = entity.s_ticket_booking_id,
                        wechat_Id = entity.wechat_Id,
                        create_date = ctime,
                        create_user = _UserTokenInfo.UserWorkNo,
                        s_branch_id = _UserTokenInfo.SBranchId,
                        s_business_set_id = _UserTokenInfo.outletId,
                        sell_no = entity.sell_no,//订单号
                        business_date = btime,
                        business_name = outName,
                        status = IsActivityConstStr.N,
                        account_status = IsActivityConstStr.N,
                        quit_sell_no = (entity.n_KdType.HasValue && -1 == entity.n_KdType) ? entity.quit_sell_no : "",// 买票的单，这个单号就为空，退票的单，就存被退票的单号
                    };
                    gmainid = await DbScoped.SugarScope.Insertable<STitcketSellEntity>(main_entity).ExecuteReturnIdentityAsync();
                    gmainid = gmainid <= 0 ? main_entity.id : gmainid;
                }
                var listRecord = new List<STicketSellRecordEntity>();
                foreach (var item in entity.ticket_infos)
                {
                    var recordEntity = new STicketSellRecordEntity
                    {
                        create_date = ctime,
                        create_user = _UserTokenInfo.UserWorkNo,
                        s_branch_id = _UserTokenInfo.SBranchId,
                        outlet_name = outName,//查询
                        s_titcket_sell_id = gmainid <= 0 ? enrityM.id : gmainid,//必填

                        ticket_code = item.ticket_code,//应该修改为票的id
                        amount = item.count, //该票类型的总数量
                        price = item.price,//该票类型的单价

                        business_date = item.valid_date, //根据页面传过来的有效期
                        sell_no = entity.sell_no,// 单号
                        ota_ticketname = "",
                        pay_type = IsActivityConstStr.xf,// 默认D：消费 ； C：付款
                        pay_date = null,//支付时间
                        n_fen = 0, //积分值
                        other_amount = 0,
                        pay_amount = 0,//支付金额
                        valid_date = item.valid_date,//有效期

                        refound = 0,//退票数量
                        print_type = item.print_type,//打印类型: 0每张套票打印一张; 1每张票打印一张; 2每种票打印一张
                        ticket_number = 0,//出票数量  预订相关
                        ticket_amount = item.price//门票金额  预订相关
                    };
                    listRecord.Add(recordEntity);
                }
                int count = await DbScoped.SugarScope.Insertable<STicketSellRecordEntity>(listRecord).ExecuteCommandAsync();
                return gmainid <= 0 ? enrityM.id : gmainid;
            });
            return flag.IsSuccess ? ApiResultDto.ToResultSuccess(data: flag.Data) : ApiResultDto.ToResultError(msg: flag.ErrorMessage);
        }


        /// <summary>
        ///  销售门票  --付款写入到记录表
        /// </summary>
        /// <param name="s_titcket_sell_id">门票销售主表的id</param>
        /// <returns></returns>
        public ApiResultDto InsertPayTicket(STicketSellRecordDto dto)
        {
            var ctime = DateTime.Now;
            var btime = CeChengBusinessFunctionHelper.GetBusinessDateByBranchIdByTb(_UserTokenInfo.SBranchId);//营业日期
            var outName = CeChengBusinessFunctionHelper.GetOutNameByOutIdByTb(_UserTokenInfo.outletId);

            var ticketSell = DbScoped.Sugar.Queryable<STitcketSellEntity>()
                .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .Where(c => c.id == dto.s_titcket_sell_id)
                .First();
            if (ticketSell != null)
            {
                if (ticketSell.order_amount == 0)
                    return ApiResultDto.ToResultFail(msg: "当前订单金额是0，不需要付款！");

                if (ticketSell.account_status == IsActivityConstStr.Y)
                    return ApiResultDto.ToResultFail("该单已结账");

                if ((ticketSell.order_amount.Value > 0 && ticketSell.order_amount.Value < (ticketSell.pay_amount.Value + dto.pay_amount.Value))
                    || (ticketSell.order_amount.Value < 0 && ticketSell.order_amount.Value > (ticketSell.pay_amount.Value + dto.pay_amount.Value))
                    )
                {
                    return ApiResultDto.ToResultFail("支付金额不能大于订单金额");
                }

                var flag = DbScoped.Sugar.UseTran<int>(() =>
                {
                    dto.create_date = ctime;
                    dto.create_user = _UserTokenInfo.UserWorkNo;
                    dto.s_branch_id = _UserTokenInfo.SBranchId;
                    dto.outlet_name = outName;
                    dto.amount = 0; //该票类型的总数量
                    dto.price = 0;//该票类型的单价

                    dto.business_date = btime; // 营业日期
                    dto.sell_no = ticketSell.sell_no;
                    dto.ota_ticketname = "";
                    dto.pay_type = IsActivityConstStr.payMoney;// 默认D：消费 ； C：付款
                    dto.pay_date = ctime;//支付时间
                    dto.valid_date = null;//有效期

                    dto.refound = 0;//退票数量
                    dto.print_type = 0;//打印类型: 0每张套票打印一张; 1每张票打印一张; 2每种票打印一张
                    dto.ticket_number = 0;//出票数量  预订相关
                    dto.ticket_amount = 0;//门票金额  预订相关

                    //写入一条付款的记录
                    int count = DbScoped.Sugar.Insertable<STicketSellRecordEntity>(dto).ExecuteCommand();

                    // 更新订单中的支付金额
                    ticketSell.pay_amount += dto.pay_amount.Value;
                    count = DbScoped.Sugar.Updateable<STitcketSellEntity>(ticketSell).ExecuteCommand();

                    return count;
                });
                return flag.IsSuccess && flag.Data > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail(msg: flag.ErrorMessage);
            }
            else
                return ApiResultDto.ToResultFail("未找到该订单主表信息，请检查id是否正确");
        }

        /// <summary>
        /// 结账 -- 改销售表的状态，改成结账状态
        /// </summary>
        /// <param name="sell_id"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> JieZhangTicket(QueryByIdDto sell_id)
        {
            var sell_main = await DbScoped.Sugar.Queryable<STitcketSellEntity>().Where(c => c.id == sell_id.id)
                .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .FirstAsync();
            if (sell_main != null)
            {
                if (sell_main.account_status == IsActivityConstStr.Y)
                    return ApiResultDto.ToResultFail("该单已结账");
                if (sell_main.order_amount.HasValue && sell_main.order_amount.Value != sell_main.pay_amount.Value)
                {
                    return ApiResultDto.ToResultFail("该单付款金额（积分）不等于消费金额（积分），不允许结账结账");
                }

                // 更改为结账状态
                sell_main.account_status = IsActivityConstStr.Y;
                int count = await DbScoped.Sugar.Updateable(sell_main).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
                return ApiResultDto.ToResultFail(msg: "未找到对应的订单，请检查订单id是否正确");
        }

        /// <summary>
        /// 根据 开单生成的出票的主键id来删除选择的出票信息 
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveChoseTicket(QueryByIdDto dto)
        {
            int count = 0;
            var rentity = await DbScoped.Sugar.Queryable<STicketSellRecordEntity>().WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId).Where(c => c.id == dto.id).FirstAsync();
            if (rentity != null)
            {
                var mainEntity = await DbScoped.Sugar.Queryable<STitcketSellEntity>().WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId).Where(c => c.id == rentity.s_titcket_sell_id && c.account_status == IsActivityConstStr.Y).FirstAsync();
                if (mainEntity != null && mainEntity.id > 0)
                    return ApiResultDto.ToResultFail("对已经付款的订单不可以删除票信息");
                count = await DbScoped.Sugar.Deleteable<STicketSellRecordEntity>(rentity).ExecuteCommandAsync();
            }
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }

        /// <summary>
        /// 取消开单 只修改 主表的状态，和令工有确认
        /// </summary>
        /// <param name="sell_id"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> CancelKdTicket(QueryByIdDto sell_id)
        {
            var sell_main = await DbScoped.Sugar.Queryable<STitcketSellEntity>().Where(c => c.id == sell_id.id).WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId).FirstAsync();
            if (sell_main != null)
            {
                if(sell_main.pay_amount.HasValue && 0 != sell_main.pay_amount.Value)
                    return ApiResultDto.ToResultFail("该单已有付款数据，不可以取消");

                if (sell_main.status == IsActivityConstStr.Y)
                    return ApiResultDto.ToResultFail("该单已出票不可以取消");

                if (sell_main.account_status == IsActivityConstStr.Y)
                    return ApiResultDto.ToResultFail("该单已经付款不可以取消");

                sell_main.status = IsActivityConstStr.canselOrder;
                int count = await DbScoped.Sugar.Updateable(sell_main).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            else
                return ApiResultDto.ToResultFail(msg: "未找到对应的订单，请检查订单id是否正确");
        }



        /// <summary>
        /// 查询开单列表 主单列表 信息  if_all_pay：true 未结的单
        /// </summary>
        /// <param name="dto"></param> 
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<STitcketSellEntity>>> QueryKdTicket(STicketSellQueryDto dto)
        {
            int? n_sell_id = 0;
            // 门票号不为空就查对应的单号
            if (!string.IsNullOrEmpty(dto.ticket_no))
            {
                var listDetail = await DbScoped.Sugar.Queryable<STicketSellRecordDetailEntity>()
                    .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                    .Where(c => c.ticket_no == dto.ticket_no)
                    .ToListAsync();
                if (null != listDetail && 0 < listDetail.Count)
                {
                    var listRecord = await DbScoped.Sugar.Queryable<STicketSellRecordEntity>()
                    .Where(c => c.id == listDetail[0].s_ticket_sell_record_id)
                    .ToListAsync();
                    if (null != listRecord && 0 < listRecord.Count)
                    {
                        n_sell_id = listRecord[0].s_titcket_sell_id;
                    }
                }
            }
            var tcount = new RefAsync<int>();
            var listData = await DbScoped.Sugar.Queryable<STitcketSellEntity>()
                  .LeftJoin<STicketsBookingEntity>((c, d) => c.s_ticket_booking_id == d.id)
                  .WhereIF(!string.IsNullOrEmpty(dto.agreement_cust_no), (c, d) => d.agreement_cust_no == dto.agreement_cust_no)
                  .Select(c => c)
                  .WhereIF(n_sell_id.HasValue && n_sell_id.Value > 0, c => c.id == n_sell_id)
                  .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                  .WhereIF(dto.business_date_start != null, c => c.business_date >= dto.business_date_start)
                  .WhereIF(dto.business_date_end != null, c => c.business_date <= dto.business_date_end.GetCeChengEndTime())
                  .WhereIF(dto.s_business_set_id > 0, c => c.s_business_set_id == dto.s_business_set_id)
                  .WhereIF(dto.order_date != null, c => c.order_date >= dto.order_date && c.order_date <= dto.order_date.GetCeChengEndTime())
                  .WhereIF(dto.pay_type.IsNotNullOrEmpty(), c => c.pay_type == dto.pay_type)
                  .WhereIF(dto.booking_no.IsNotNullOrEmpty(), c => c.booking_no == dto.booking_no)
                  .WhereIF(dto.platform_code.IsNotNullOrEmpty(), c => c.platform_code == dto.platform_code)
                  .WhereIF(dto.create_user.IsNotNullOrEmpty(), c => c.create_user == dto.create_user)
                  .WhereIF(dto.if_all_pay, c => c.account_status == IsActivityConstStr.N && c.status != IsActivityConstStr.canselOrder)
                  .Where(c => c.pay_type != "3")//排查赠送的，不需要付款
                  .WhereIF(!string.IsNullOrEmpty(dto.sell_no),c=>c.sell_no==dto.sell_no)
                  .WhereIF(dto.n_KdType.HasValue, c => (-1 == dto.n_KdType.Value && false == string.IsNullOrEmpty(c.quit_sell_no))
                                                       || (-1 != dto.n_KdType.Value && string.IsNullOrEmpty(c.quit_sell_no))
                                                       )
                  .ToPageListAsync(dto.pageIndex, dto.pageSize, tcount);
            var data = new List<STitcketSellEntity>();
            if (tcount.Value > 0)
                data = listData;
            return ApiResultPageNationTDataDto<List<STitcketSellEntity>>.ToResultSuccess(data: data, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: tcount.Value);
        }

        /// <summary>
        /// 根据开单列表的id来查询记录表的数据  就是所有的具体的票
        /// </summary>
        /// <param name="dto">开单的主键id</param>
        /// <returns></returns>
        public async Task<ApiResultDto<List<GetSTicketSellRecordDetailEntity>>> QueryKdRecordDetailTicket(QueryByIdWithPageNationDto dto)
        {
            var tcount = new RefAsync<int>();
            var listData = await DbScoped.Sugar.Queryable<STicketSellRecordEntity>()
                .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .Where(c => c.s_titcket_sell_id == dto.id).ToListAsync();
            var listdata = new List<GetSTicketSellRecordDetailEntity>();
            if (listData.Any())
            {
                List<int> rdid = listData.Select(c => c.id).ToList();
                listdata = await DbScoped.Sugar.Queryable<STicketSellRecordDetailEntity>()
                    .LeftJoin<ConsumeItemEntity>((c, o) => c.s_branch_id == o.s_branch_id && c.s_no == o.consume_item_no)
                    .Where((c, o) => rdid.Contains(c.s_ticket_sell_record_id.Value))
                    .Select((c, o) => new GetSTicketSellRecordDetailEntity
                    {
                        id = c.id,
                        s_ticket_sell_record_id = c.s_ticket_sell_record_id,
                        ticket_orcode = c.ticket_orcode,
                        valid_date = c.valid_date,
                        Is_used = c.Is_used,
                        cancel_date = c.cancel_date,
                        use_date = c.use_date,
                        ticket_no = c.ticket_no,
                        ticket_price = c.ticket_price,
                        wechat_id = c.wechat_id,
                        member_name = c.member_name,
                        use_account = c.use_account,
                        user_number = c.user_number,
                        cancel_user = c.cancel_user,
                        price_ticket = c.price_ticket,
                        ticket_secret = c.ticket_secret,
                        is_print = c.is_print,
                        use_work_no = c.use_work_no,
                        use_shift = c.use_shift,
                        business_date = c.business_date,
                        ticket_main = c.ticket_main,
                        create_date = c.create_date,
                        create_user = c.create_user,
                        update_date = c.update_date,
                        update_user = c.update_user,
                        s_branch_id = c.s_branch_id,
                        s_AuthCode = c.s_AuthCode,
                        s_no = c.s_no,
                        ticket_voucher = c.ticket_voucher,
                        consume_item_name = o.consume_item_name,
                        n_consume_item_price = o.price
                    })
                    .ToListAsync();
            }
            return ApiResultDto<List<GetSTicketSellRecordDetailEntity>>.ToResultSuccess(data: listdata);
        }

        /// <summary>
        /// 修改出票的具体一张票的有效期时间接口 待确认是否需要修改基础票的数据的有效期等
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> UpdateOutTicketValidateTime(UpdateTicketValidateTimeDto ticketid)
        {
            var tsetEntity = await DbScoped.Sugar.Queryable<TicketSetEntity>().Where(c => c.id == ticketid.ticketid).FirstAsync();
            if (tsetEntity != null && tsetEntity.id > 0)
                tsetEntity.validate_date = ticketid.valid_date;
            await DbScoped.Sugar.Updateable<TicketSetEntity>(tsetEntity).ExecuteCommandAsync();
            return ApiResultDto.ToResultSuccess();
        }


        /// <summary>
        /// 取票、退票时会使用到 根据订单号 查询所有的票的类型  record信息  
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto<List<GetSTicketSellRecord>>> QueryKdRecordTicket(QueryTicketRecordBySellNo dto)
        {
            var mainOrder = await DbScoped.Sugar.Queryable<STitcketSellEntity>()
                .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .Where(c => c.sell_no == dto.sell_no)
                .FirstAsync();
            var listRcord = new List<GetSTicketSellRecord>();
            if (mainOrder != null && mainOrder.id > 0)
            {
                var ticketEntitys = await DbScoped.Sugar.Queryable<STicketSellRecordEntity>()
                    .Where(c => c.s_titcket_sell_id == mainOrder.id)
                    .WhereIF(!string.IsNullOrEmpty(dto.pay_type), c => c.pay_type == dto.pay_type)
                    .ToListAsync();
                listRcord = _mapper.Map<List<STicketSellRecordEntity>, List<GetSTicketSellRecord>>(ticketEntitys);
                if (listRcord.Count > 0)
                {
                    List<string> tickcode = listRcord.Select(c => c.ticket_code).ToList();
                    var listTicketInfo = await DbScoped.Sugar.Queryable<TicketSetEntity>().Where(c => tickcode.Contains(c.ticket_code)).Select(c => new { c.ticket_code, c.ticket_name, c.is_change_price }).ToListAsync();
                    foreach (var item in listRcord)
                    {
                        item.ticket_name = listTicketInfo.FirstOrDefault(c => c.ticket_code == item.ticket_code)?.ticket_name;
                        item.is_change_price = listTicketInfo.FirstOrDefault(c => c.ticket_code == item.ticket_code)?.is_change_price;
                    }
                }
            }
            return ApiResultDto<List<GetSTicketSellRecord>>.ToResultSuccess(data: listRcord);
        }


        /// <summary>
        /// 根据票号，查询对应可退的票号
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto<GetSTicketSellRecord>> QueryKdRecordTicketByTicketNoToQuit(QueryTicketRecordByTicketNo dto)
        {
            if (string.IsNullOrEmpty(dto.ticket_no))
            {
                return ApiResultDto<GetSTicketSellRecord>.ToResultFail(data: null, msg: "退票票号不能为空");
            }

            var listRcord = await DbScoped.Sugar.Queryable<STicketSellRecordEntity>()
                .InnerJoin<STicketSellRecordDetailEntity>((c, o) => c.s_branch_id == o.s_branch_id
                                                                    && c.id == o.s_ticket_sell_record_id
                                                                    && o.ticket_no == dto.ticket_no
                                                                    && o.Is_used == "N"
                                                                    && c.amount > c.refound
                                                                    && c.pay_type == "D"
                                                        )
                .Select(c => c)
                .ToListAsync();

            if (listRcord.Count > 0)
            {
                var ticketEntitys = _mapper.Map<STicketSellRecordEntity, GetSTicketSellRecord>(listRcord[0]);
                var listTicketInfo = await DbScoped.Sugar.Queryable<TicketSetEntity>()
                    .Where(c => c.ticket_code == ticketEntitys.ticket_code)
                    .Select(c => new { c.ticket_code, c.ticket_name, c.is_change_price })
                    .ToListAsync();

                ticketEntitys.ticket_name = listTicketInfo.FirstOrDefault(c => c.ticket_code == ticketEntitys.ticket_code)?.ticket_name;
                ticketEntitys.is_change_price = listTicketInfo.FirstOrDefault(c => c.ticket_code == ticketEntitys.ticket_code)?.is_change_price;

                return ApiResultDto<GetSTicketSellRecord>.ToResultSuccess(data: ticketEntitys);
            }

            return ApiResultDto<GetSTicketSellRecord>.ToResultFail(data: null, msg:"已没有可退的票");
        }

        #region 待业务确认 ==============取票 退票
        /// <summary>
        /// 查询出准备取票的列表数据
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<ApiResultDto<List<STicketSellRecordDetailEntity>>> QueryOutTicketInfoAsync(QueryByIdDto entity)
        {
            //查询出所有的票列表数据
            var datalist = await DbScoped.Sugar.Queryable<STitcketSellEntity>().LeftJoin<STicketSellRecordEntity>((m, c) => m.id == c.s_titcket_sell_id)
                .LeftJoin<STicketSellRecordDetailEntity>((m, c, d) => d.s_ticket_sell_record_id == c.id)
                .WhereIF(_UserTokenInfo.SysType <= 0, (m, c, d) => m.s_branch_id == _UserTokenInfo.SBranchId)
                .Where((m, c, d) => c.id == entity.id).Select((m, c, d) => new STicketSellRecordDetailEntity
                {
                    id = d.id,
                    ticket_orcode = d.ticket_orcode,//票二维码
                    business_date = d.business_date,
                    s_branch_id = d.s_branch_id,
                    is_print = d.is_print,//微信出票标识
                    cancel_user = d.cancel_user,
                    Is_used = d.Is_used,//是否使用
                    member_name = d.member_name,
                    price_ticket = d.price_ticket,
                    s_ticket_sell_record_id = d.s_ticket_sell_record_id,
                    ticket_main = d.ticket_main,
                    ticket_no = d.ticket_no,
                    ticket_price = d.ticket_price,
                    ticket_secret = d.ticket_secret,
                    user_number = d.user_number,
                    use_account = d.use_account,
                    use_date = d.use_date,
                    use_shift = d.use_shift,
                    use_work_no = d.use_work_no,
                    valid_date = d.valid_date,
                    wechat_id = d.wechat_id,

                    update_date = d.update_date,
                    update_user = d.update_user,
                    cancel_date = d.cancel_date,
                    create_date = d.create_date,
                    create_user = d.create_user
                }).ToListAsync();
            return ApiResultDto<List<STicketSellRecordDetailEntity>>.ToResultSuccess(data: datalist);
        }

        /// <summary>
        ///销售门票 --取票  更新门票的相关状态时间等
        /// （这个出票只是更改明细表里面的票的出票状态，也就是更新is_print的值）
        /// </summary>
        /// <param name="record_detail_id">根据选择的票id来取票 目前缺少打印票等操作</param>
        /// <returns></returns>
        public async Task<ApiResultDto> OutTicketAsync(List<int> record_detail_id)
        {
            var rdenity = await DbScoped.SugarScope.Queryable<STicketSellRecordDetailEntity>().WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .Where(c => record_detail_id.Contains(c.id) && c.is_print == IsActivityConstStr.N).ToListAsync();
            if (rdenity.Any())
            {
                var ytime = DateTime.Now;
                foreach (var item in rdenity)
                {
                    item.is_print = IsActivityConstStr.Y;
                    item.update_date = ytime;
                    item.update_user = _UserTokenInfo.UserWorkNo;
                }
                await DbScoped.SugarScope.Updateable(rdenity).ExecuteCommandAsync();
                return ApiResultDto.ToResultSuccess();
            }
            else
                return ApiResultDto.ToResultFail();
        }


        #endregion

        /// <summary>
        /// --出票 有两种情况 1：手动写入到详情表，2：付款触发写入(更新主表状态为付款时) 目前会议规定使用触发器
        /// （这个出票是生成当前单据的所有的票到detail明细表里）
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> OutKdTicketToDetail(QueryByIdDto entity)
        {
            //查询是否已经出票或者结账
            var mainEntity = await DbScoped.SugarScope.Queryable<STitcketSellEntity>().Where(c => c.id == entity.id).FirstAsync();
            if (mainEntity != null && mainEntity.id > 0)
            {
                if (mainEntity.status == IsActivityConstStr.Y || mainEntity.account_status == IsActivityConstStr.Y)
                    return ApiResultDto.ToResultFail("已经出票或者结账的订单不能重复出票操作");
                mainEntity.status = IsActivityConstStr.Y;
                mainEntity.update_date = DateTime.Now;

                int count = await DbScoped.SugarScope.Updateable<STitcketSellEntity>(mainEntity).ExecuteCommandAsync();
                return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();

                #region old
                //var recodEntitys = await DbScoped.SugarScope.Queryable<STicketSellRecordEntity>().Where(c => c.s_titcket_sell_id == mainEntity.id && c.pay_type == IsActivityConstStr.xf).ToListAsync();

                //var btime = await CeChengBusinessFunctionHelper.GetBusinessDateByBranchId(_UserTokenInfo.SBranchId);//营业日期
                //var outName = await CeChengBusinessFunctionHelper.GetOutNameByOutId(_UserTokenInfo.outletId);
                //var flag = await DbScoped.SugarScope.UseTranAsync<bool>(async () =>
                //{
                //    if (recodEntitys.Any())
                //    {
                //        //查询票的价格
                //        //Dictionary<int, string> list = recodEntitys.ToDictionary(a => a.id, a => a.ticket_code);
                //        List<string> codeList = recodEntitys.Select(c => c.ticket_code).ToList();
                //        var tickPriceInfos = await DbScoped.SugarScope.Queryable<TicketSetEntity>().Where(c => codeList.Contains(c.ticket_code)).Select(c => new { c.ticket_code, c.price }).ToListAsync();

                //        //写入到明细表
                //        var ctime = DateTime.Now;
                //        var rdlist = new List<STicketSellRecordDetailEntity>();
                //        foreach (var item in recodEntitys)
                //        {
                //            int ticketCount = item.amount.Value;
                //            for (int i = 0; i < ticketCount; i++)
                //            {
                //                var rdEntity = new STicketSellRecordDetailEntity
                //                {
                //                    s_ticket_sell_record_id = item.id,
                //                    ticket_orcode = "",//票二维码
                //                    ticket_main = "",//针对套票而言的唯一码
                //                    ticket_no = "",// 票号,自动 生成唯一 号
                //                    business_date = btime,
                //                    s_branch_id = _UserTokenInfo.SBranchId,
                //                    is_print = IsActivityConstStr.N,//微信出票标识 默认N
                //                    Is_used = IsActivityConstStr.N,//是否使用 使用：Y，未使用：N ，退票：C
                //                    valid_date = item.valid_date,
                //                    create_user = _UserTokenInfo.UserWorkNo,
                //                    create_date = ctime,

                //                    member_name = "",//领票人
                //                    price_ticket = tickPriceInfos?.FirstOrDefault(c => c.ticket_code == item.ticket_code)?.price,//需要查询出来 门票价
                //                    cancel_user = "",
                //                    ticket_price = 0,
                //                    ticket_secret = "",
                //                    use_account = "",//
                //                    user_number = 0,
                //                    use_date = null,
                //                    use_shift = "",
                //                    use_work_no = "",
                //                    wechat_id = "",
                //                    update_date = null,
                //                    update_user = "",
                //                    cancel_date = null
                //                };
                //                rdlist.Add(rdEntity);
                //            }
                //        }
                //        await DbScoped.SugarScope.Insertable(rdlist).ExecuteCommandAsync();
                //        //更新主表出票的状态
                //        mainEntity.status = IsActivityConstStr.Y;
                //        await DbScoped.SugarScope.Updateable(mainEntity).ExecuteCommandAsync();
                //        return true;
                //    }
                //    else
                //        throw new Exception("未能查找到记录表相关的数据!");
                //});
                //return flag.Data ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail(); 
                #endregion
            }
            else
                return ApiResultDto.ToResultFail("请检查订单号是否存在");
        }

        /// <summary>
        /// 调证出票前，票的有效时间
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditTicketValidate(EditTicketValidateTimeDto dto)
        {
            var ticketRecord = await DbScoped.Sugar.Queryable<STicketSellRecordEntity>().WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId).Where(c => c.id == dto.id).FirstAsync();
            if (ticketRecord != null && ticketRecord.id > 0)
            {
                var ticketMain = await DbScoped.Sugar.Queryable<STitcketSellEntity>().Where(c => c.id == ticketRecord.s_titcket_sell_id).FirstAsync();
                if (ticketMain != null && ticketMain.status != IsActivityConstStr.N)
                    return ApiResultDto.ToResultFail("已经出票的有效期不可以修改");
                ticketRecord.valid_date = dto.valid_date;
                await DbScoped.Sugar.Updateable<STicketSellRecordEntity>(ticketRecord).ExecuteCommandAsync();
                return ApiResultDto.ToResultSuccess();
            }
            else
                return ApiResultDto.ToResultFail("请检查数据是否存在");
        }


        #region 团体的预订单基础curd接口
        /// <summary>
        /// 新增 预订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> AddSTicketsBooking(STicketsBookingAddDto dto)
        {
            var entity = _mapper.Map<STicketsBookingAddDto, STicketsBookingEntity>(dto);
            entity.create_date = DateTime.Now;
            entity.create_user = _UserTokenInfo.UserWorkNo;
            entity.s_branch_id = _UserTokenInfo.SBranchId;
            //entity.flag = IsActivityConstStr.N;
            entity.audit_state = IsActivityConstStr.N;
            entity.status = 0;// 预订单状态 0：正常；1：取消

            int count = await DbScoped.SugarScope.Insertable<STicketsBookingEntity>(entity).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        /// <summary>
        /// 修改 预订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> EditSTicketsBooking(STicketsBookingEditDto dto)
        {
            var getentity = await DbScoped.SugarScope.Queryable<STicketsBookingEntity>()
                .WhereIF(_UserTokenInfo.SysType <= 0, c => c.s_branch_id == _UserTokenInfo.SBranchId)
                .Where(c => c.id == dto.id)
                .FirstAsync();
            if (getentity == null || getentity.id <= 0)
                return ApiResultDto.ToResultFail("请检查编辑的id是否存在");
            var entity = _mapper.Map<STicketsBookingEditDto, STicketsBookingEntity>(dto);
            entity.update_date = DateTime.Now;
            entity.update_user = _UserTokenInfo.UserWorkNo;
            entity.create_date = getentity.create_date;
            entity.create_user = getentity.create_user;
            entity.s_branch_id = _UserTokenInfo.SBranchId;
            int count = await DbScoped.SugarScope.Insertable<STicketsBookingEntity>(entity).ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        /// <summary>
        /// 删除 预订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveSTicketsBooking(QueryByIdDto dto)
        {
            int count = await DbScoped.SugarScope.Deleteable<STicketsBookingEntity>()
                .Where(c => c.id == dto.id && (c.status == 2 || c.status == 3))
                .ExecuteCommandAsync();
            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }
        /// <summary>
        /// 取消预定门票
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> CancelSTicketsBooking(CancelSTicketsBookingParamDto dto)
        {
            var listBooking = await DbScoped.SugarScope.Queryable<STicketsBookingEntity>()
                .Where(c => c.id == dto.id)
                .ToListAsync();

            if (null == listBooking || 0 == listBooking.Count)
            {
                return ApiResultDto.ToResultFail(msg: "预定单不存在");
            }
            if (1 == listBooking[0].status)
            {
                return ApiResultDto.ToResultFail(msg: "人员已到，不能再取消");
            }

            listBooking[0].status = 3;
            listBooking[0].cancel_date = DateTime.Now;
            listBooking[0].cancel_user = _UserTokenInfo.UserWorkNo;
            listBooking[0].cancel_reason = dto.cancel_reason;
            int count = await DbScoped.SugarScope.Updateable<STicketsBookingEntity>(listBooking[0])
                .ExecuteCommandAsync();

            return count > 0 ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
        }

        /// <summary>
        /// 分页查询 预订单
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<STicketsBookingPageQueryDto>>> QuerySTicketsBooking(STicketsBookingQueryDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (_UserTokenInfo.SBranchId > 0)
            {
                sWhere += " and bk.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", _UserTokenInfo.SBranchId));
            }
            if (null != dto && dto.id.HasValue && dto.id.Value != 0)
            {
                sWhere += " and bk.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id.Value));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.team_reserve_no))
            {
                sWhere += " and bk.team_reserve_no = @team_reserve_no";
                listSqlParam.Add(new SugarParameter("@team_reserve_no", dto.team_reserve_no));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.team_reserve_name))
            {
                sWhere += " and bk.team_reserve_name like '%' + @team_reserve_name + '%'";
                listSqlParam.Add(new SugarParameter("@team_reserve_name", dto.team_reserve_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.userdefinded_reserve_no))
            {
                sWhere += " and bk.userdefinded_reserve_no = @userdefinded_reserve_no";
                listSqlParam.Add(new SugarParameter("@userdefinded_reserve_no", dto.userdefinded_reserve_no));
            }
            if (null != dto && dto.status.HasValue && dto.status.Value != 0)
            {
                sWhere += " and bk.status = @status";
                listSqlParam.Add(new SugarParameter("@status", dto.status));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.audit_state))
            {
                sWhere += " and bk.audit_state = @audit_state";
                listSqlParam.Add(new SugarParameter("@audit_state", dto.audit_state));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.company_name))
            {
                sWhere += " and bk.company_name like '%' + @company_name + '%'";
                listSqlParam.Add(new SugarParameter("@company_name", dto.company_name));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.cust_source_type))
            {
                sWhere += " and bk.cust_source_type = @cust_source_type";
                listSqlParam.Add(new SugarParameter("@cust_source_type", dto.cust_source_type));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.cust_type))
            {
                sWhere += " and bk.cust_type = @cust_type";
                listSqlParam.Add(new SugarParameter("@cust_type", dto.cust_type));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.team_type))
            {
                sWhere += " and bk.team_type = @team_type";
                listSqlParam.Add(new SugarParameter("@team_type", dto.team_type));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.agreement_cust_no))
            {
                sWhere += " and bk.agreement_cust_no = @agreement_cust_no";
                listSqlParam.Add(new SugarParameter("@agreement_cust_no", dto.agreement_cust_no));
            }

            if (null != dto && !string.IsNullOrWhiteSpace(dto.arrive_date_start))
            {
                sWhere += " and bk.arrive_date >= @arrive_date_start";
                listSqlParam.Add(new SugarParameter("@arrive_date_start", dto.arrive_date_start));
            }
            if (null != dto && !string.IsNullOrEmpty(dto.arrive_date_end))
            {
                sWhere += " and bk.arrive_date <= @arrive_date_end";
                listSqlParam.Add(new SugarParameter("@arrive_date_end", dto.arrive_date_end));
            }
            if (null != dto && dto.create_date_start.HasValue)
            {
                sWhere += " and convert(varchar(19), bk.create_date, 120)  >= @create_date_start";
                listSqlParam.Add(new SugarParameter("@create_date_start", dto.create_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.create_date_end.HasValue)
            {
                sWhere += " and convert(varchar(19), bk.create_date, 120)  <= @create_date_end";
                listSqlParam.Add(new SugarParameter("@create_date_end", dto.create_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.cancel_date_start.HasValue)
            {
                sWhere += " and convert(varchar(19), bk.cancel_date, 120)  >= @cancel_date_start";
                listSqlParam.Add(new SugarParameter("@cancel_date_start", dto.cancel_date_start.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            if (null != dto && dto.cancel_date_end.HasValue)
            {
                sWhere += " and convert(varchar(19), bk.cancel_date, 120)  <= @cancel_date_end";
                listSqlParam.Add(new SugarParameter("@cancel_date_end", dto.cancel_date_end.Value.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    FROM   s_ticket_booking bk
                                           left join s_cust_source_type  cst on cst.s_branch_id = bk.s_branch_id  and cst.cust_source_code = bk.cust_source_type
                                           left join s_sys_cust_type     sct on sct.s_branch_id = bk.s_branch_id  and sct.cust_code = bk.cust_type
                                           left join s_agreement_cust     ac on ac.s_branch_id  = bk.s_branch_id  and ac.agreement_cust_account_no = bk.agreement_cust_no
                                           left join s_team_type          tt on tt.s_branch_id  = bk.s_branch_id  and tt.team_no = bk.team_type
                                           left join s_sys_saler          ss on ss.s_branch_id  = bk.s_branch_id  and ss.sale_work_no = bk.s_sys_saler_no
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by bk.id) as row_no,
                                           bk.id, bk.team_reserve_no, bk.team_reserve_name, bk.userdefinded_reserve_no, bk.company_name, 
                                           bk.arrive_date, bk.arrive_time, bk.cust_source_type, bk.cust_type, bk.team_type, bk.cust_count, 
                                           bk.guide_count, bk.escort_count, bk.agreement_cust_no, bk.[status], bk.audit_state, bk.s_sys_saler_no, 
                                           bk.telephone, bk.contact, bk.ticket_secret_flag, bk.account_secret_flag, bk.cancel_reason, bk.cancel_user, 
                                           bk.cancel_date, bk.memo, bk.business_date, bk.create_date, bk.update_date, bk.create_user, bk.update_user, 
                                           bk.s_branch_id,
                                           cust_source_name = isnull(cst.cust_source_desc, ''),
                                           cust_type_name = isnull(sct.cust_name, ''),
                                           agreement_cust_name = isnull(ac.agreement_cust_name, ''),
                                           team_name = isnull(tt.tean_name, ''),
                                           saler_name=isnull(ss.sale_name,'')
                                    FROM   s_ticket_booking bk
                                           left join s_cust_source_type  cst on cst.s_branch_id = bk.s_branch_id  and cst.cust_source_code = bk.cust_source_type
                                           left join s_sys_cust_type     sct on sct.s_branch_id = bk.s_branch_id  and sct.cust_code = bk.cust_type
                                           left join s_agreement_cust     ac on ac.s_branch_id  = bk.s_branch_id  and ac.agreement_cust_account_no = bk.agreement_cust_no
                                           left join s_team_type          tt on tt.s_branch_id  = bk.s_branch_id  and tt.team_no = bk.team_type
                                           left join s_sys_saler          ss on ss.s_branch_id  = bk.s_branch_id  and ss.sale_work_no = bk.s_sys_saler_no
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<STicketsBookingPageQueryDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<STicketsBookingPageQueryDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);

        }

        /// <summary>
        /// 查询单个预定单的整单信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto<STicketsBookingOneQueryDto>> QueryOneSTicketsBookingInfo(QueryByIdDto dto)
        {
            // 返回对象信息
            STicketsBookingOneQueryDto dtoOneQuery = new STicketsBookingOneQueryDto();

            #region 查询预订单主单信息
            var resQryBooking = await DbScoped.Sugar.Queryable<STicketsBookingEntity>()
                .Where(c => c.id == dto.id)
                .ToListAsync();
            if (null == resQryBooking || resQryBooking.Count < 1)
            {
                return ApiResultDto<STicketsBookingOneQueryDto>.ToResultFail(msg: "预定单信息查询为空");
            }

            #region 主单信息赋值
            STicketsBookingEntity oneBooking = resQryBooking[0];
            STicketsBookingDto dtoTicketsBooking = new STicketsBookingDto();
            dtoTicketsBooking.id = oneBooking.id;
            dtoTicketsBooking.team_reserve_no = oneBooking.team_reserve_no;
            dtoTicketsBooking.team_reserve_name = oneBooking.team_reserve_name;
            dtoTicketsBooking.userdefinded_reserve_no = oneBooking.userdefinded_reserve_no;
            dtoTicketsBooking.company_name = oneBooking.company_name;
            dtoTicketsBooking.arrive_date = oneBooking.arrive_date;
            dtoTicketsBooking.arrive_time = oneBooking.arrive_time;
            dtoTicketsBooking.cust_source_type = oneBooking.cust_source_type;
            dtoTicketsBooking.cust_type = oneBooking.cust_type;
            dtoTicketsBooking.team_type = oneBooking.team_type;
            dtoTicketsBooking.cust_count = oneBooking.cust_count;
            dtoTicketsBooking.guide_count = oneBooking.guide_count;
            dtoTicketsBooking.escort_count = oneBooking.escort_count;
            dtoTicketsBooking.agreement_cust_no = oneBooking.agreement_cust_no;
            dtoTicketsBooking.status = oneBooking.status;
            dtoTicketsBooking.audit_state = oneBooking.audit_state;
            dtoTicketsBooking.s_sys_saler_no = oneBooking.s_sys_saler_no;
            dtoTicketsBooking.telephone = oneBooking.telephone;
            dtoTicketsBooking.contact = oneBooking.contact;
            dtoTicketsBooking.ticket_secret_flag = oneBooking.ticket_secret_flag;
            dtoTicketsBooking.account_secret_flag = oneBooking.account_secret_flag;
            dtoTicketsBooking.cancel_reason = oneBooking.cancel_reason;
            dtoTicketsBooking.cancel_user = oneBooking.cancel_user;
            dtoTicketsBooking.cancel_date = oneBooking.cancel_date;
            dtoTicketsBooking.memo = oneBooking.memo;
            dtoTicketsBooking.business_date = oneBooking.business_date;
            dtoTicketsBooking.create_date = oneBooking.create_date;
            dtoTicketsBooking.update_date = oneBooking.update_date;
            dtoTicketsBooking.create_user = oneBooking.create_user;
            dtoTicketsBooking.update_user = oneBooking.update_user;
            dtoTicketsBooking.s_branch_id = oneBooking.s_branch_id;
            dtoOneQuery.dtoTicketsBooking = dtoTicketsBooking;
            #endregion
            #endregion

            #region 查询预订单门票信息
            var resQryRecord = await DbScoped.Sugar.Queryable<STicketBookingRecordEntity>()
                .Where(c => c.s_ticket_booking_id == dto.id)
                .ToListAsync();
            // 若门票信息不存在就返回（这种情况项目信息可以不用查了）
            if (null == resQryRecord || resQryRecord.Count < 1)
            {
                return ApiResultDto<STicketsBookingOneQueryDto>.ToResultSuccess(data: dtoOneQuery);
            }
            // 根据门票编码，查门票具体设置
            List<string> tickcode = resQryRecord.Select(c => c.ticket_code).ToList();
            var listTicketInfo = await DbScoped.Sugar.Queryable<TicketSetEntity>()
                .Where(c => tickcode.Contains(c.ticket_code) && c.s_branch_id == resQryBooking[0].s_branch_id)
                .Select(c => new { c.id, c.ticket_code, c.ticket_name })
                .ToListAsync();
            #region 给返回的门票列表信息赋值
            List<STicketBookingRecordByJoinDto> listTicketsBookingRecordDtos = new List<STicketBookingRecordByJoinDto>();
            foreach (var item in resQryRecord)
            {
                STicketBookingRecordByJoinDto oneRecord = new STicketBookingRecordByJoinDto();
                oneRecord.id = item.id;
                oneRecord.s_ticket_booking_id = item.s_ticket_booking_id;
                oneRecord.team_reserve_no = item.team_reserve_no;
                oneRecord.ticket_code = item.ticket_code;
                oneRecord.amount = item.amount;
                oneRecord.price = item.price;
                oneRecord.refound = item.refound;
                oneRecord.ticket_numer = item.ticket_numer;
                oneRecord.business_date = item.business_date;
                oneRecord.create_date = item.create_date;
                oneRecord.update_date = item.update_date;
                oneRecord.create_user = item.create_user;
                oneRecord.update_user = item.update_user;
                oneRecord.s_branch_id = item.s_branch_id;
                oneRecord.ticket_set_id = listTicketInfo.FirstOrDefault(c => c.ticket_code == item.ticket_code)?.id;
                oneRecord.ticket_name = listTicketInfo.FirstOrDefault(c => c.ticket_code == item.ticket_code)?.ticket_name;
                listTicketsBookingRecordDtos.Add(oneRecord);
            }
            dtoOneQuery.listTicketsBookingRecordDtos = listTicketsBookingRecordDtos;
            #endregion
            #endregion

            #region 查询预订单项目信息
            var listConsumeItemInfo = await DbScoped.Sugar.Queryable<ConsumeItemEntity>()
                .Where(c => c.s_branch_id == resQryBooking[0].s_branch_id)
                .Select(c => new { c.id, c.consume_item_no, c.consume_item_name })
                .ToListAsync();

            #region 按门票分别查询对应的门票项目信息，然后设置返回的门票项目列表信息
            // 当前单据所有门票的项目明细列表
            List<STicketsBookingDeatailQueryDto> ListTicketsBookingDeatailQueryDto = new List<STicketsBookingDeatailQueryDto>();
            foreach (var oneRecord in listTicketsBookingRecordDtos) // 遍历当前预定单下的门票信息，按门票信息查询对应的项目信息
            {
                // 当前门票信息
                STicketsBookingDeatailQueryDto dtoSTicketsBookingDeatailQuery = new STicketsBookingDeatailQueryDto();
                dtoSTicketsBookingDeatailQuery.ticket_set_id = oneRecord.ticket_set_id;
                dtoSTicketsBookingDeatailQuery.ticket_set_code = oneRecord.ticket_code;
                dtoSTicketsBookingDeatailQuery.ticket_set_name = oneRecord.ticket_name;

                // 按门票信息查询对应的项目信息
                var listDetailInfo = await DbScoped.Sugar.Queryable<STicketBookingDetailEntity>()
                .Where(c => c.s_ticket_booking_record_id == oneRecord.id)
                .ToListAsync();
                // 转换对象，赋值，返回
                // 一种门票的项目明细列表
                List<STicketsBookingDeatailByJoinDto> listSTicketBookingDetailDto = new List<STicketsBookingDeatailByJoinDto>();
                foreach (var itemResQryDetail in listDetailInfo) 
                {
                    STicketsBookingDeatailByJoinDto oneDeatil = new STicketsBookingDeatailByJoinDto();
                    oneDeatil.id = itemResQryDetail.id;
                    oneDeatil.team_reserve_no = itemResQryDetail.team_reserve_no;
                    oneDeatil.s_ticket_booking_record_id = itemResQryDetail.s_ticket_booking_record_id;
                    oneDeatil.s_code = itemResQryDetail.s_code;
                    oneDeatil.s_no = itemResQryDetail.s_no;
                    oneDeatil.s_desc = itemResQryDetail.s_desc;
                    oneDeatil.n_count = itemResQryDetail.n_count;
                    oneDeatil.n_price = itemResQryDetail.n_price;
                    oneDeatil.n_count_stand = itemResQryDetail.n_count_stand;
                    oneDeatil.create_date = itemResQryDetail.create_date;
                    oneDeatil.update_date = itemResQryDetail.update_date;
                    oneDeatil.create_user = itemResQryDetail.create_user;
                    oneDeatil.update_user = itemResQryDetail.update_user;
                    oneDeatil.s_branch_id = itemResQryDetail.s_branch_id;
                    oneDeatil.consume_item_id = listConsumeItemInfo.FirstOrDefault(c => c.consume_item_no == itemResQryDetail.s_no)?.id;
                    oneDeatil.consume_item_name = listConsumeItemInfo.FirstOrDefault(c => c.consume_item_no == itemResQryDetail.s_no)?.consume_item_name;
                    // 加入返回列表
                    listSTicketBookingDetailDto.Add(oneDeatil);
                }
                dtoSTicketsBookingDeatailQuery.listSTicketBookingDetailDto = listSTicketBookingDetailDto;

                // 加入大返回列表
                ListTicketsBookingDeatailQueryDto.Add(dtoSTicketsBookingDeatailQuery);
            }
            dtoOneQuery.ListTicketsBookingDeatailQueryDto = ListTicketsBookingDeatailQueryDto;
            #endregion
            #endregion

            return ApiResultDto<STicketsBookingOneQueryDto>.ToResultSuccess(data: dtoOneQuery);
        }

        /// <summary>
        /// 新增、编辑保存预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<ApiResultDto<STicketsBookingDto>> SaveSTicketsBooking(STicketsBookingSaveDto dto)
        {
            // 主单信息对象
            STicketsBookingDto dtoTicketsBooking = dto.dtoTicketsBooking;
            if (dtoTicketsBooking.status.HasValue == false || dtoTicketsBooking.status.Value != (byte)2)
            {
                return ApiResultDto<STicketsBookingDto>.ToResultError(msg: "预定单状态不正确");
            }
            var flag = await DbScoped.SugarScope.UseTranAsync<int>(async () =>
            {
                int res_count = 0;
                #region  处理主单信息
                if (dtoTicketsBooking.id > 0) // 更新主单信息
                {
                    #region  更新主单信息
                    if (string.IsNullOrEmpty(dtoTicketsBooking.team_reserve_no))
                    {
                        throw new Exception("编辑的时候，预定订单号不能为空");
                    }
                    var his_booking = await DbScoped.SugarScope.Queryable<STicketsBookingEntity>().Where(c => c.id == dtoTicketsBooking.id).FirstAsync();
                    if (null == his_booking)
                    {
                        throw new Exception("预定订单信息查询为空");
                    }
                    if (his_booking.status != 2) // 只有未到的才能修改
                    {
                        throw new Exception("预定订单不是未到状态，不允许再修改");
                    }
                    dtoTicketsBooking.create_date = his_booking.create_date;
                    dtoTicketsBooking.create_user = his_booking.create_user;
                    dtoTicketsBooking.s_branch_id = his_booking.s_branch_id;
                    res_count = await DbScoped.SugarScope.Updateable<STicketsBookingEntity>(dtoTicketsBooking).ExecuteCommandAsync();
                    if (res_count < 1)
                    {
                        throw new Exception("主单信息更新异常");
                    }
                    #endregion

                    #region  删除预定明细信息
                    // 删除旧的已选的门票
                    var his_record = await DbScoped.SugarScope.Queryable<STicketBookingRecordEntity>()
                        .Where(c => c.s_ticket_booking_id == dtoTicketsBooking.id)
                        .ToListAsync();
                    if (null != his_record && 0 < his_record.Count)
                    {
                        for (int i = 0; i < his_record.Count; i++)
                        {
                            // 删除旧的明细
                            res_count = await DbScoped.SugarScope.Deleteable<STicketBookingDetailEntity>()
                                .Where(c => c.s_ticket_booking_record_id == his_record[i].id)
                                .ExecuteCommandAsync();
                        }

                        // 删除旧的已选的门票
                        res_count = await DbScoped.SugarScope.Deleteable<STicketBookingRecordEntity>()
                            .Where(c => c.s_ticket_booking_id == dtoTicketsBooking.id)
                            .ExecuteCommandAsync();
                        if (res_count < 1)
                        {
                            throw new Exception("历史选择门票删除异常");
                        }
                    }
                    #endregion
                }
                else 
                {
                    #region  新增主单信息
                    // 生成预定单号
                    string sNewBookNo = await CeChengBusinessFunctionHelper.GetSysNextNo(NextNumberIdentityEnum.ticket_booking_no);
                    dtoTicketsBooking.team_reserve_no = sNewBookNo;
                    dtoTicketsBooking.create_date = DateTime.Now;
                    dtoTicketsBooking.create_user = _UserTokenInfo.UserWorkNo;
                    dtoTicketsBooking.s_branch_id = _UserTokenInfo.SBranchId;

                    STicketsBookingEntity new_Booking = await DbScoped.SugarScope.Insertable<STicketsBookingEntity>(dtoTicketsBooking).ExecuteReturnEntityAsync();
                    if (null == new_Booking)
                    {
                        throw new Exception("插入主单信息更新异常");
                    }
                    dtoTicketsBooking.id = new_Booking.id;
                    #endregion
                }
                #endregion

                #region  处理选的门票信息（记录信息）
                // 选择的门票信息没传过来的，就直接返回
                if (null == dto.listTicketsBookingRecordDtos || 0 == dto.listTicketsBookingRecordDtos.Count)
                {
                    return res_count;
                }
                foreach (STicketBookingRecordDto objRecordDto in dto.listTicketsBookingRecordDtos)
                {
                    objRecordDto.s_ticket_booking_id = dtoTicketsBooking.id;
                    objRecordDto.team_reserve_no = dtoTicketsBooking.team_reserve_no;
                    objRecordDto.create_date = DateTime.Now;
                    objRecordDto.create_user = _UserTokenInfo.UserWorkNo;
                    objRecordDto.s_branch_id = _UserTokenInfo.SBranchId;

                    STicketBookingRecordEntity resRecordEntity = await DbScoped.SugarScope.Insertable<STicketBookingRecordEntity>(objRecordDto).ExecuteReturnEntityAsync();
                    if (null == resRecordEntity)
                    {
                        throw new Exception("门票记录信息插入异常");
                    }
                    objRecordDto.id = resRecordEntity.id;
                }
                #endregion

                #region  处理选的门票项目信息（明细信息）
                // 选择的门票项目信息没传过来的，就直接返回
                if (null == dto.ListTicketsBookingDeatailSaveDto || 0 == dto.ListTicketsBookingDeatailSaveDto.Count)
                {
                    return res_count;
                }
                foreach (STicketsBookingDeatailSaveDto objDeatailSave in dto.ListTicketsBookingDeatailSaveDto)
                {
                    // 判断当前门票的项目明细是否为空，为空就返回
                    if (null == objDeatailSave.listSTicketBookingDetailDto || 0 == objDeatailSave.listSTicketBookingDetailDto.Count)
                    {
                        continue;
                    }
                    // 找对应的记录的ID
                    int record_id = 0;
                    foreach (STicketBookingRecordDto objRecordDto in dto.listTicketsBookingRecordDtos)
                    {
                        if (objDeatailSave.ticket_set_code == objRecordDto.ticket_code)
                        {
                            record_id = objRecordDto.id;
                            break;
                        }
                    }
                    // 循环把门票项目明细插入到数据库钟
                    foreach (STicketBookingDetailDto objDetailDto in objDeatailSave.listSTicketBookingDetailDto)
                    {
                        objDetailDto.s_ticket_booking_record_id = record_id;
                        objDetailDto.team_reserve_no = dtoTicketsBooking.team_reserve_no;
                        objDetailDto.create_date = DateTime.Now;
                        objDetailDto.create_user = _UserTokenInfo.UserWorkNo;
                        objDetailDto.s_branch_id = _UserTokenInfo.SBranchId;

                        STicketBookingDetailEntity resDetailEntity = await DbScoped.SugarScope.Insertable<STicketBookingDetailEntity>(objDetailDto).ExecuteReturnEntityAsync();
                        if (null == resDetailEntity)
                        {
                            throw new Exception("门票项目明细信息插入异常");
                        }
                    }
                    
                }
                #endregion

                return res_count;
            });

            return flag.IsSuccess ? ApiResultDto<STicketsBookingDto>.ToResultSuccess(data: dtoTicketsBooking) : ApiResultDto<STicketsBookingDto>.ToResultError(msg: flag.ErrorMessage);
        }
        #endregion


        /// <summary>
        /// 批量修改票的而有效期
        /// </summary>
        /// <param name="sell_id"></param>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchUpdateValidDate(BattchUpdateValidDateDto dto)
        {
            if (null == dto || null == dto.listTicketDetailID || 0 == dto.listTicketDetailID.Count || false == dto.new_viladdate.HasValue)
            {
                return ApiResultDto.ToResultFail(msg: "项目ID列表、有效期不能为空");
            }

            string sWhere = string.Empty;
            foreach (int id in dto.listTicketDetailID)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }

            string sql = $"update s_ticket_sell_record_detail  set valid_date = '{dto.new_viladdate.Value.ToString("yyyy-MM-dd HH:mm:ss")}' where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }


        /// <summary>
        /// 执行退票
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public async Task<ApiResultDto> ExecQuitTicket(QuitTicketDto dto)
        {
            // 判断退票单的ID是否传过来
            if (null == dto || false == dto.sell_id_now.HasValue || 0 == dto.sell_id_now.Value)
            {
                return ApiResultDto.ToResultFail(msg: "单号ID不能为空");
            }
            // 判断退票单据是否存在
            var listQuitSell = await DbScoped.SugarScope.Queryable<STitcketSellEntity>()
                    .Where(o => o.id == dto.sell_id_now.Value && o.account_status == IsActivityConstStr.N)
                    .ToListAsync();
            if (null == listQuitSell || 0 == listQuitSell.Count)
            {
                return ApiResultDto.ToResultFail(msg: "未找到未结退票单据");
            }
            // 判断被退票是否存在
            var listQuitRecord = await DbScoped.SugarScope.Queryable<STicketSellRecordEntity>()
                    .InnerJoin<STitcketSellEntity>((c, o) => o.id == dto.sell_id_now && c.s_titcket_sell_id == o.id && o.account_status == IsActivityConstStr.N)
                    .Where(c => c.pay_type == "D")
                    .Select(c => c)
                    .ToListAsync();
            if (null == listQuitRecord || 0 == listQuitRecord.Count)
            {
                return ApiResultDto.ToResultFail(msg: "未找到要退票的票的信息");
            }

            var ctime = DateTime.Now;
            var btime = await CeChengBusinessFunctionHelper.GetBusinessDateByBranchId(_UserTokenInfo.SBranchId);//营业日期
            var outName = await CeChengBusinessFunctionHelper.GetOutNameByOutId(_UserTokenInfo.outletId);

            var flag = await DbScoped.SugarScope.UseTranAsync<int>(async () =>
            {
                string sqlQuery = $@"
                                        select mx.id, mx.ticket_no, mx.s_no, rc.ticket_code
                                        from   s_ticket_sell_record_detail mx
                                               inner join s_ticket_sell_record   rc on rc.id = mx.s_ticket_sell_record_id
                                               inner join s_titcket_sell         ts on ts.id = rc.s_titcket_sell_id
                                               inner join s_titcket_sell         ta on ta.s_branch_id = ts.s_branch_id and ta.quit_sell_no = ts.sell_no
                                               inner join s_ticket_sell_record   rb on rb.s_titcket_sell_id = ta.id
                                        where  ta.id = {dto.sell_id_now.Value}
                                        ;

                                        select rc.ticket_code, ticket_amount= 0 - rc.amount, s_no=si.ticket_item_code
                                        from   s_ticket_sell_record rc 
                                               inner join s_titcket_sell  ts on ts.id = rc.s_titcket_sell_id
                                               inner join s_ticket_set    se on se.s_branch_id = ts.s_branch_id and se.ticket_code = rc.ticket_code
                                               inner join s_ticket_item   si on si.s_ticket_set_id = se.id
                                        where  rc.pay_type = 'D' and ts.id = {dto.sell_id_now.Value}
                                        ;
                                 ";

                var resulQry = await DbScoped.Sugar.Ado.SqlQueryAsync<GetSTicketSellRecordDetailEntity, GetSTicketSellRecordDetailEntity>(sqlQuery);
                if (null == resulQry || null == resulQry.Item1 || null == resulQry.Item2 || 0 == resulQry.Item1.Count || 0 == resulQry.Item2.Count)
                {
                    throw new Exception("套票项目不存在");
                }

                List<int> listQuitDeatilID = new List<int>();

                // 要是有指定要退的票号，就先找出指定票的记录id
                if (null != dto.listTicketNo && 0 < dto.listTicketNo.Count)
                {
                    foreach (string stn in dto.listTicketNo)
                    {
                        foreach (GetSTicketSellRecordDetailEntity mx in resulQry.Item1)
                        {
                            if (mx.ticket_no == stn)
                            {
                                listQuitDeatilID.Add(mx.id);
                                mx.id = 0;
                            }
                        }
                    }
                }

                // 继续找除指定票号以外还需要退的票（明细表里面的项目的ID）
                foreach (GetSTicketSellRecordDetailEntity sz in resulQry.Item2)
                {
                    int iGotIDCount = 0;
                    foreach (GetSTicketSellRecordDetailEntity mx in resulQry.Item1)
                    {
                        if (sz.ticket_code == mx.ticket_code && sz.s_no == mx.s_no)
                        {
                            if (0 == mx.id)
                                iGotIDCount += 1;
                            else
                            {
                                listQuitDeatilID.Add(mx.id);
                                iGotIDCount += 1;
                            }
                            if (sz.ticket_amount.Value == iGotIDCount)
                                break;                        
                        }
                    }
                }

                #region 执行更新;
                // 明细表的票要进行取消
                var listToQuit = await DbScoped.SugarScope.Queryable<STicketSellRecordDetailEntity>().Where(c => listQuitDeatilID.Contains(c.id)).ToListAsync();
                foreach (STicketSellRecordDetailEntity sr in listToQuit)
                {
                    sr.cancel_date = DateTime.Now;
                    sr.Is_used = "C";
                    sr.cancel_user = _UserTokenInfo.UserWorkNo;
                }
                int count = await DbScoped.SugarScope.Updateable<STicketSellRecordDetailEntity>(listToQuit).ExecuteCommandAsync();
                if (0 == count)
                    throw new Exception("票项目状态更新异常");

                // 当前主单表的状态更新
                listQuitSell[0].status = IsActivityConstStr.Y;
                count = await DbScoped.SugarScope.Updateable<STitcketSellEntity>(listQuitSell[0]).ExecuteCommandAsync();
                if (0 == count)
                    throw new Exception("票项目状态更新异常");

                foreach (STicketSellRecordEntity  rc in listQuitRecord)
                {
                    // 被退的票的退票数量字段值更新
                    var tsr = await DbScoped.SugarScope.Queryable<STicketSellRecordEntity>()
                    .Where(c => c.sell_no == listQuitSell[0].quit_sell_no && c.s_branch_id == listQuitSell[0].s_branch_id && c.ticket_code == rc.ticket_code)
                    .ToListAsync();

                    if (null == tsr || 0 == tsr.Count)
                        throw new Exception("被退的票的信息查询异常");

                    tsr[0].refound += -rc.amount;
                    count = await DbScoped.SugarScope.Updateable<STicketSellRecordEntity>(tsr[0]).ExecuteCommandAsync();
                    if (0 == count)
                        throw new Exception("退票数量字段值更新更新异常");

                    // 票设置里，已售卖的票的总数量要更新
                    var tis = await DbScoped.SugarScope.Queryable<TicketSetEntity>()
                    .Where(c => c.s_branch_id == listQuitSell[0].s_branch_id && c.ticket_code == rc.ticket_code)
                    .ToListAsync();

                    if (null == tis || 0 == tis.Count)
                        throw new Exception("门票设置信息查询异常");

                    tis[0].amount_sale += rc.amount;
                    count = await DbScoped.SugarScope.Updateable<TicketSetEntity>(tis[0]).ExecuteCommandAsync();
                    if (0 == count)
                        throw new Exception("退票数量字段值更新更新异常");
                }
                #endregion

                return count;
            });

            return flag.IsSuccess ? ApiResultDto.ToResultSuccess(data: null) : ApiResultDto.ToResultError(msg: flag.ErrorMessage);
        }

    }
}

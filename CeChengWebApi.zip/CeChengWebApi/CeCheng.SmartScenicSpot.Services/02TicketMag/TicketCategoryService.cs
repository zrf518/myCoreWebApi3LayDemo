﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Org.BouncyCastle.Crypto;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 门票类型设置接口实现
    /// </summary>
    public class TicketCategoryService : ITicketCategoryInterface
    {
        /// <summary>
        /// 新增门票类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddTicketCategoryAsync(TicketCategoryDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<TicketCategoryEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.category_code == dto.category_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<TicketCategoryEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑门票类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditTicketCategoryAsync(TicketCategoryDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<TicketCategoryEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.category_code == dto.category_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<TicketCategoryEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<TicketCategoryEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询门票类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<TicketCategorySearchResultDto>>> QueryTicketCategoryAsync(TicketCategorySearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)
            {
                sWhere += " and tc.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and tc.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.category_code))
            {
                sWhere += " and tc.category_code = @category_code";
                listSqlParam.Add(new SugarParameter("@category_code", dto.category_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.category_name))
            {
                sWhere += " and tc.category_name like '%' + @category_name + '%'";
                listSqlParam.Add(new SugarParameter("@category_name", dto.category_name));
            }
            if (null != dto && dto.type_flag.HasValue)
            {
                sWhere += " and tc.type_flag = @type_flag";
                listSqlParam.Add(new SugarParameter("@type_flag", dto.type_flag));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.oper_big_type))
            {
                sWhere += " and tc.oper_big_type = @oper_big_type";
                listSqlParam.Add(new SugarParameter("@oper_big_type", dto.oper_big_type));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_show_ticket))
            {
                sWhere += " and tc.is_show_ticket = @is_show_ticket";
                listSqlParam.Add(new SugarParameter("@is_show_ticket", dto.is_show_ticket));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and tc.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_ticket_category tc
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by tc.id desc) as row_no,
                                           tc.id, tc.category_code, tc.category_name, tc.type_flag, tc.oper_big_type, tc.is_show_ticket,  
                                           tc.memo, tc.is_active, tc.s_branch_id, tc.create_date, tc.create_user, tc.update_date, tc.update_user,
                                           type_flag_name = sdi.dicname
                                    from   s_ticket_category tc
                                           left join s_sys_dictionary_info sdi on sdi.dictype = 1009 and tc.type_flag = sdi.dicid
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<TicketCategorySearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<TicketCategorySearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除门票类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveTicketCategoryAsync(string sUserWorkNo, int id)
        {
            // 查看被删除的门票类在门票设置中是否有使用，有使用的，就不允许删除
            var resQryTestCode = await DbScoped.Sugar.Queryable<TicketSetEntity>()
                .Where(x => id == x.s_ticket_category_id.Value)
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "删除失败：当前门票设置中有使用该门票类，不允许删除");
            }
            string sql = "delete from  s_ticket_category  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除门票类型设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveTicketCategoryAsync(string sUserWorkNo, List<int> ids)
        {
            // 查看被删除的门票类在门票设置中是否有使用，有使用的，就不允许删除
            var resQryTestCode = await DbScoped.Sugar.Queryable<TicketSetEntity>()
                .Where(x => ids.Contains(x.s_ticket_category_id.Value))
                .ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "删除失败：当前门票设置中有使用该门票类，不允许删除");
            }
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_ticket_category  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
    }
}
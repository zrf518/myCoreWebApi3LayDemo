﻿using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using SqlSugar;
using SqlSugar.IOC;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// 门票项目设置接口实现
    /// </summary>
    public class TicketItemService : ITicketItemInterface
    {
        /// <summary>
        /// 新增门票项目设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> AddTicketItemAsync(TicketItemDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<TicketItemEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.s_ticket_set_id == dto.s_ticket_set_id && x.ticket_item_code == dto.ticket_item_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 执行添加
            var result = await DbScoped.Sugar.Insertable<TicketItemEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 编辑门票项目设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> EditTicketItemAsync(TicketItemDto dto)
        {
            // 查看编码是否有重复
            var resQryTestCode = await DbScoped.Sugar.Queryable<TicketItemEntity>()
                .Where(x => x.s_branch_id == dto.s_branch_id && x.id != dto.id && x.s_ticket_set_id == dto.s_ticket_set_id && x.ticket_item_code == dto.ticket_item_code).ToListAsync();
            if (null != resQryTestCode && 0 < resQryTestCode.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "编码重复");
            }

            // 查出原数据
            var resQry = await DbScoped.Sugar.Queryable<TicketItemEntity>().Where(x => x.id == dto.id).SingleAsync();
            if (null == resQry)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "记录id不存在");
            }
            // 保留创建信息
            dto.create_date = resQry.create_date;
            dto.create_user = resQry.create_user;
            dto.s_branch_id = resQry.s_branch_id;

            // 执行更新
            var result = await DbScoped.Sugar.Updateable<TicketItemEntity>(dto).ExecuteCommandAsync();
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 查询门票项目设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultPageNationTDataDto<List<TicketItemSearchResultDto>>> QueryTicketItemAsync(TicketItemSearchParamDto dto)
        {
            #region 查询参数
            string sWhere = "";
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            if (null != dto && dto.s_branch_id.HasValue)//s_ticket_set_id
            {
                sWhere += " and tt.s_branch_id = @s_branch_id";
                listSqlParam.Add(new SugarParameter("@s_branch_id", dto.s_branch_id));
            }
            if (null != dto && dto.id != 0)
            {
                sWhere += " and tt.id = @id";
                listSqlParam.Add(new SugarParameter("@id", dto.id));
            }
            if (null != dto && dto.s_ticket_set_id.HasValue)
            {
                sWhere += " and tt.s_ticket_set_id = @s_ticket_set_id";
                listSqlParam.Add(new SugarParameter("@s_ticket_set_id", dto.s_ticket_set_id));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.ticket_item_code))
            {
                sWhere += " and tt.ticket_item_code = @ticket_item_code";
                listSqlParam.Add(new SugarParameter("@ticket_item_code", dto.ticket_item_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.ticket_item_name))
            {
                sWhere += " and tt.ticket_item_name like '%' + @ticket_item_name + '%'";
                listSqlParam.Add(new SugarParameter("@ticket_item_name", dto.ticket_item_name));
            }
            // 门票信息查询
            if (null != dto && !string.IsNullOrWhiteSpace(dto.ticket_code))
            {
                sWhere += " and ts.ticket_code = @ticket_code";
                listSqlParam.Add(new SugarParameter("@ticket_code", dto.ticket_code));
            }
            if (null != dto && !string.IsNullOrWhiteSpace(dto.ticket_name))
            {
                sWhere += " and ts.ticket_name like '%' + @ticket_name + '%'";
                listSqlParam.Add(new SugarParameter("@ticket_name", dto.ticket_name));
            }
            // 是否启用
            if (null != dto && !string.IsNullOrWhiteSpace(dto.is_active))
            {
                sWhere += " and tt.is_active = @is_active";
                listSqlParam.Add(new SugarParameter("@is_active", dto.is_active));
            }
            #endregion

            #region 查询语句
            // 查询记录数
            string sqlCount = $@"
                                    select iCount = count(*)
                                    from   s_ticket_item tt
                                           left join s_ticket_set ts on ts.id = tt.s_ticket_set_id
                                    where  1=1
                                ";
            // 查询明细
            string sqlQuery = $@"
                                    select row_number() over(order by tt.id desc) as row_no,
                                           tt.id, tt.ticket_item_code, tt.ticket_item_name, tt.quantity, tt.[money], tt.weekday_price, 
                                           tt.weekend_price, tt.holiday_price, tt.s_ticket_set_id, tt.memo, tt.is_active, 
                                           tt.s_branch_id, tt.create_date, tt.create_user, tt.update_date, tt.update_user,
                                           ts.ticket_name, ts.ticket_code
                                    from   s_ticket_item tt
                                           left join s_ticket_set ts on ts.id = tt.s_ticket_set_id
                                    where  1=1
                                ";
            #endregion

            int iCount = await DbScoped.Sugar.Ado.SqlQuerySingleAsync<int>(sqlCount + sWhere, listSqlParam);

            // 开始与结束
            int iStart = (dto.pageIndex - 1) * dto.pageSize + 1;
            int iEnd = dto.pageIndex * dto.pageSize;

            sqlQuery = $@"
                            select  *
                            from   (
                                        {sqlQuery + sWhere}
                                    ) tab
                            where  1=1
                              and  {iStart} <= row_no 
                              and  row_no <= {iEnd}
                              order by row_no 
                        ";

            var result = await DbScoped.Sugar.Ado.SqlQueryAsync<TicketItemSearchResultDto>(sqlQuery, listSqlParam);
            return ApiResultPageNationTDataDto<List<TicketItemSearchResultDto>>.ToResultSuccess(data: result, PageIndex: dto.pageIndex, PageSize: dto.pageSize, TotalRow: iCount);
        }
        /// <summary>
        /// 删除门票项目设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> RemoveTicketItemAsync(string sUserWorkNo, int id)
        {
            string sql = "delete from  s_ticket_item  where id=" + id;
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 批量删除门票项目设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchRemoveTicketItemAsync(string sUserWorkNo, List<int> ids)
        {
            string sWhere = string.Empty;
            foreach (int id in ids)
            {
                if (string.IsNullOrEmpty(sWhere))
                {
                    sWhere = "" + id;
                }
                else
                {
                    sWhere += "," + id;
                }
            }
            string sql = "delete from  s_ticket_item  where id in (" + sWhere + ")";
            var result = await DbScoped.Sugar.Ado.ExecuteCommandAsync(sql);
            if (result > 0)
                return ApiResultDto.ToResultSuccess(data: true);

            return ApiResultDto.ToResultFail(data: false);
        }
        /// <summary>
        /// 新增门票项目设置
        /// </summary>
        /// <returns></returns>
        public async Task<ApiResultDto> BattchAddTicketItemAsync(TicketItemListDtos dtos)
        {
            if (null == dtos || 0 == dtos.listTicketItemDto.Count)
            {
                return ApiResultDto.ToResultFail(data: false, msg: "门票项目设置数据不能为空");
            }

            // 检查输入
            for (int i = 0; i < dtos.listTicketItemDto.Count; i++)
            {
                TicketItemDto dtoTicketItem = dtos.listTicketItemDto[i];
                if (string.IsNullOrEmpty(dtoTicketItem.ticket_item_code)
                    || string.IsNullOrEmpty(dtoTicketItem.ticket_item_name)
                    || false == dtoTicketItem.s_branch_id.HasValue
                    || false == dtoTicketItem.s_ticket_set_id.HasValue
                    || false == dtoTicketItem.quantity.HasValue
                    || false == dtoTicketItem.money.HasValue
                    || false == dtoTicketItem.weekday_price.HasValue
                    || false == dtoTicketItem.weekend_price.HasValue
                    || false == dtoTicketItem.holiday_price.HasValue
                    )
                {
                    return ApiResultDto.ToResultFail(data: false, msg: "第" + (i + 1) + "条门票项目数据信息部完整");
                }
            }

            var flag = await DbScoped.Sugar.UseTranAsync(async () =>
            {
                // 批量新增前先删除原先的
                var resDelOld = await DbScoped.Sugar.Deleteable<TicketItemEntity>()
                    .Where(x => x.s_branch_id == dtos.listTicketItemDto[0].s_branch_id && x.s_ticket_set_id == dtos.listTicketItemDto[0].s_ticket_set_id)
                    .ExecuteCommandAsync();

                // 批量插入新的
                for (int i=0; i< dtos.listTicketItemDto.Count; i++)
                {
                    // 执行添加
                    var result = await DbScoped.Sugar.Insertable<TicketItemEntity>(dtos.listTicketItemDto[i]).ExecuteCommandAsync();
                    if (result < 1)
                        throw new Exception("第" + (i + 1) + "条门票项目设置异常:");
                }
            });

            if (flag.Data)
                return ApiResultDto.ToResultSuccess(data: true);
            else
                throw new Exception(flag.ErrorMessage);
        }

    }
}
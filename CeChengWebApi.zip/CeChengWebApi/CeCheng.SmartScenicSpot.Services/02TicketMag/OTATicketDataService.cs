﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models.Consts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using SqlSugar.IOC;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace CeCheng.SmartScenicSpot.Services
{
    /// <summary>
    /// OTA票务平台数据接口
    /// </summary>
    public class OTATicketDataService : IOTATicketDataInterface
    {

    }
}

﻿using System;

namespace CeCheng.SmartScenicSpot.Webapi
{
    /// <summary>
    /// 
    /// </summary>
    public class CheckSignAttribute:Attribute
    {
    }
}

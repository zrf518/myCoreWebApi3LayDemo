﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CeCheng.SmartScenicSpot.Webapi.Controller //cecheng.webapi.Controller
{
    /// <summary>
    ///05  收银管理 相关模块
    /// </summary>
    [Route("api/cashier/[controller]")]
    [Area("cashier")]
    [ApiController]
    [Authorize]
    public class CashierController:ControllerBase
    {
    }
}

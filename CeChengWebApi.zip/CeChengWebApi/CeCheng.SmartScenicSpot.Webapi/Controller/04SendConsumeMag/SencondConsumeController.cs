﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 04 二次消费 相关模块
    /// </summary>
    [Route("api/sencondcon/[controller]")]
    [Area("sencondcon")]
    [ApiController]
    [Authorize]
    public class SencondConsumeController:ControllerBase
    {
    }
}

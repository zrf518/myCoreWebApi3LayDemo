﻿using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using CeCheng.SmartScenicSpot.Contracts;
using SqlSugar.IOC;
using SqlSugar;
using System.Linq;
using System.Collections.Generic;
using System;
using CeCheng.SmartScenicSpot.Commoms;
using NPOI.POIFS.FileSystem;
using NPOI.SS.Formula.Functions;
using Ticket;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using static ICSharpCode.SharpZipLib.Zip.ExtendedUnixData;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 02 票务管理相关模块  开单销售门票
    /// </summary>
    [Route("api/ticket/[controller]")]
    [Area("ticket")]
    [ApiController]
    [Authorize]
    public class TicketKdSellController : CeChengBaseController
    {
        private readonly ITicketKdSellInterface _ticketKdSellInterface;
        /// <summary>
        /// 
        /// </summary>
        public TicketKdSellController(IHttpContextAccessor httpContextAccessor, ITicketKdSellInterface ticketKdSellInterface) : base(httpContextAccessor)
        {
            _ticketKdSellInterface = ticketKdSellInterface;
        }

        #region 开单 新增主表与记录表

        /// <summary>
        /// 获取开单 订单编号，订单号页面上需要禁止修改
        /// </summary>
        /// <returns></returns>
        [HttpPost("CreateKdTicketSellNo")]
        public async Task<ApiResultDto> CreateKdTicketSellNo() => await _ticketKdSellInterface.CreateKdTicketSellNo();

        /// <summary>
        ///销售门票 --开单新增  主表
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost("AddKdTicket")]
        public async Task<ApiResultDto> AddKdTicket([FromBody] STicketSellAddDto entity)
        {
            if (string.IsNullOrEmpty(entity.sell_no) || entity.s_branch_id == null)
                return ApiResultDto.ToResultFail("订单号,分店id不可以为空");
            //if (entity.ticket_infos != null && entity.ticket_infos.Any())
            //    return ApiResultDto.ToResultFail(msg: "票数据,订单号:sell_no必填");
            if (entity.n_KdType.HasValue && -1 == entity.n_KdType.Value && entity.ticket_infos != null && entity.ticket_infos.Any() && (entity.ticket_infos.Any(c => c.count > 0) || entity.ticket_infos.Any(c => c.price > 0) || entity.ticket_infos.Any(c => c.ticket_code.IsNullOrEmpty()) || entity.ticket_infos.Any(c => c.valid_date == null) || entity.ticket_infos.Any(c => c.print_type != 0 && c.print_type != 1 && c.print_type != 2)))
                return ApiResultDto.ToResultFail("票的相关价格、数量不可以大于0，打印类型数据不可以为其它值");
            else if ((false == entity.n_KdType.HasValue || (entity.n_KdType.HasValue && -1 != entity.n_KdType.Value)) && entity.ticket_infos != null && entity.ticket_infos.Any() && (entity.ticket_infos.Any(c => c.count <= 0) || entity.ticket_infos.Any(c => c.price < 0) || entity.ticket_infos.Any(c => c.ticket_code.IsNullOrEmpty()) || entity.ticket_infos.Any(c => c.valid_date == null) || entity.ticket_infos.Any(c => c.print_type != 0 && c.print_type != 1 && c.print_type != 2)))
                return ApiResultDto.ToResultFail("票的相关价格数量打印类型等数据不可以为零");
            return await _ticketKdSellInterface.AddKdTicket(entity);
        }


        /// <summary>
        ///销售门票 --出票 更新主表状态为出票状态时由触发器来处理写入到detail详情表
        /// </summary>
        /// <param name="dto">dto.id 为开单的主表id</param>
        /// <returns></returns>
        [HttpPost("OutKdTicketToDetail")]
        public async Task<ApiResultDto> OutKdTicketToDetail([FromBody] QueryByIdDto dto)
        {
            if (dto == null || dto.id <= 0)
                return ApiResultDto.ToResultFail("订单id不能为空！");
            return await _ticketKdSellInterface.OutKdTicketToDetail(dto);
        }


        ///// <summary>
        ///// 写入到record表
        ///// </summary>
        ///// <returns></returns>
        //[HttpPost("OutKdTicketAsync")]
        //public async Task<ApiResultDto> OutKdTicketAsync([FromBody] SticketOutDto dto)
        //{
        //    if (dto.ticket_infos == null || !dto.ticket_infos.Any() || dto.sell_no.IsNullOrEmpty())
        //        return ApiResultDto.ToResultFail(msg: "票数据,订单号:sell_no必填");
        //    if (dto.ticket_infos.Any(c => c.count <= 0) || dto.ticket_infos.Any(c => c.price <= 0) || dto.ticket_infos.Any(c => c.ticket_code.IsNullOrEmpty()) || dto.ticket_infos.Any(c => c.valid_date == null))
        //        return ApiResultDto.ToResultFail(msg: "票的price,code,count,valid_date等必填");
        //    return await _ticketKdSellInterface.OutKdTicketAsync(dto);
        //}

        /// <summary>
        /// 根据 开单生成的出票的主键id来移除选择的相关票的信息 
        /// </summary>
        /// <param name="dto">dto.id 出票的主键id,列表中的主键id</param>
        /// <returns></returns>
        [HttpPost("RemoveChoseTicket")]
        public async Task<ApiResultDto> RemoveChoseTicket([FromBody] QueryByIdDto dto)
        {
            if (dto == null || dto.id <= 0)
                return ApiResultDto.ToResultFail("还没有出票的数据直接在页面移除即可！");
            return await _ticketKdSellInterface.RemoveChoseTicket(dto);
        }

        /// <summary>
        ///销售门票 --取消开单 修改主表的状态为取消订单状态
        /// </summary>
        /// <param name="sell_id">为开单的id</param>
        /// <returns></returns>
        [HttpPost("CancelKdTicket")]
        public async Task<ApiResultDto> CancelKdTicket([FromBody] QueryByIdDto sell_id)
        {
            if (sell_id == null || sell_id.id <= 0)
                return ApiResultDto.ToResultFail(msg: "票id必填");
            return await _ticketKdSellInterface.CancelKdTicket(sell_id);
        }

        /// <summary>
        ///销售门票 --售票查询 开单列表 以及未结订单
        /// </summary>
        /// <param name="dto">查询的条件数据 if_all_pay=>  false ：查询全部订单状态； true:未结订单</param>
        /// <returns></returns>
        [HttpPost("QueryKdTicket")]
        public async Task<ApiResultPageNationTDataDto<List<STitcketSellEntity>>> QueryKdTicket([FromBody] STicketSellQueryDto dto)
        {
            if (dto == null)
                return ApiResultPageNationTDataDto<List<STitcketSellEntity>>.ToResultFail(msg: "分店id必填");
            return await _ticketKdSellInterface.QueryKdTicket(dto);
        }

        /// <summary>
        /// 根据选择一个单信息 查询所有的票的信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryKdRecordDetailTicket")]
        public async Task<ApiResultDto<List<GetSTicketSellRecordDetailEntity>>> QueryKdRecordDetailTicket([FromBody] QueryByIdWithPageNationDto dto)
        {
            if (dto == null)
                return ApiResultDto<List<GetSTicketSellRecordDetailEntity>>.ToResultFail(msg: "订单id必填");
            return await _ticketKdSellInterface.QueryKdRecordDetailTicket(dto);
        }
        /// <summary>
        /// 取票、退票时会使用到 根据选择一个订单号 查询所有的票的类型  record信息  根据未结账订单来查询票的相关数据
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryKdRecordTicket")]
        public async Task<ApiResultDto<List<GetSTicketSellRecord>>> QueryKdRecordTicket([FromBody] QueryTicketRecordBySellNo dto)
        {
            if (dto == null)
                return ApiResultDto<List<GetSTicketSellRecord>>.ToResultFail(msg: "订单id必填");
            return await _ticketKdSellInterface.QueryKdRecordTicket(dto);
        }

        /// <summary>
        /// 根据票号，查询对应可退的票号
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryKdRecordTicketByTicketNoToQuit")]
        public async Task<ApiResultDto<GetSTicketSellRecord>> QueryKdRecordTicketByTicketNoToQuit([FromBody] QueryTicketRecordByTicketNo dto)
        {
            if (dto == null || string.IsNullOrEmpty(dto.ticket_no))
                return ApiResultDto<GetSTicketSellRecord>.ToResultFail(msg: "票号必填");
            return await _ticketKdSellInterface.QueryKdRecordTicketByTicketNoToQuit(dto);
        }
        #endregion


        #region 付款 付款update到记录表 触发批量写入详细表
        /// <summary>
        /// 销售门票  --付款写入到记录表
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost("InsertPayTicket")]
        public ApiResultDto InsertPayTicket([FromBody] STicketSellRecordDto entity)
        {
            if (entity.s_titcket_sell_id <= 0 || entity.pay_amount == 0)
                return ApiResultDto.ToResultFail(msg: "s_titcket_sell_id与pay_amount必填");
            if (string.IsNullOrEmpty(entity.ticket_code))
                return ApiResultDto.ToResultFail(msg: "支付类型ticket_code必填！");
            return _ticketKdSellInterface.InsertPayTicket(entity);
        }
        /// <summary>
        /// 结账 -- 改销售表的状态，改成结账状态
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost("JieZhangTicket")]
        public async Task<ApiResultDto> JieZhangTicket([FromBody] QueryByIdDto entity)
        {
            if (entity.id <= 0)
                return ApiResultDto.ToResultFail(msg: "单据id必填");
            return await _ticketKdSellInterface.JieZhangTicket(entity);
        }
        #endregion

        #region 取票
        /// <summary>
        /// 查询前的查询票的列表数据
        /// </summary>
        /// <param name="order">order.id 为下单的订单主键id</param>
        /// <returns></returns>
        [HttpPost("QueryOutTicketInfoAsync")]
        public async Task<ApiResultDto<List<STicketSellRecordDetailEntity>>> QueryOutTicketInfoAsync([FromBody] QueryByIdDto order)
        {
            if (order == null || order.id <= 0)
                return ApiResultDto<List<STicketSellRecordDetailEntity>>.ToResultFail(msg: "请选择要查询的开单id");
            return await _ticketKdSellInterface.QueryOutTicketInfoAsync(order);
        }

        /// <summary>
        /// 销售门票 --取票  更新门票的相关状态时间等 这块的细节待确认
        /// </summary>
        /// <param name="record_detail_id"></param>
        /// <returns></returns>
        [HttpPost("OutTicketAsync")]
        public async Task<ApiResultDto> OutTicketAsync([FromBody] List<int> record_detail_id)
        {
            if (record_detail_id == null || !record_detail_id.Any())
                return ApiResultDto.ToResultFail(msg: "要出票的详情id不可以为空");
            return await _ticketKdSellInterface.OutTicketAsync(record_detail_id);
        }


        #endregion

        /// <summary>
        /// 修改售票查询中的具体一张票的有效期时间接口  暂不适用
        /// </summary>
        /// <returns></returns>
        [HttpPost("UpdateOutTicketValidateTime")]
        [Obsolete("过期")]
        public async Task<ApiResultDto> UpdateOutTicketValidateTime([FromBody] UpdateTicketValidateTimeDto ticketid)
        {
            if (ticketid == null || ticketid.ticketid <= 0 || ticketid.valid_date == null)
                return ApiResultDto.ToResultFail("数据都不可以为空");
            return await _ticketKdSellInterface.UpdateOutTicketValidateTime(ticketid);
        }

        #region 预订单
        /// <summary>
        /// 新增 预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddSTicketsBooking")]
        public async Task<ApiResultDto> AddSTicketsBooking([FromBody] STicketsBookingAddDto dto)
        {
            return await _ticketKdSellInterface.AddSTicketsBooking(dto);
        }
        /// <summary>
        /// 修改 预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditSTicketsBooking")]

        public async Task<ApiResultDto> EditSTicketsBooking([FromBody] STicketsBookingEditDto dto)
        {
            if (dto == null || dto.id <= 0)
                return ApiResultDto.ToResultFail("请检查输入的参数");
            return await _ticketKdSellInterface.EditSTicketsBooking(dto);
        }
        /// <summary>
        /// 删除 预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("RemoveSTicketsBooking")]
        public async Task<ApiResultDto> RemoveSTicketsBooking([FromBody] QueryByIdDto dto)
        {
            return await _ticketKdSellInterface.RemoveSTicketsBooking(dto);
        }

        /// <summary>
        /// 取消 预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("CancelSTicketsBooking")]
        public async Task<ApiResultDto> CancelSTicketsBooking([FromBody] CancelSTicketsBookingParamDto dto)
        {
            if (null == dto || dto.id < 1)
            {
                return ApiResultDto.ToResultFail("预定单的ID信息不能为空");
            }
            return await _ticketKdSellInterface.CancelSTicketsBooking(dto);
        }

        /// <summary>
        /// 分页查询 预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QuerySTicketsBooking")]
        public async Task<ApiResultPageNationTDataDto<List<STicketsBookingPageQueryDto>>> QuerySTicketsBooking([FromBody] STicketsBookingQueryDto dto)
        {
            return await _ticketKdSellInterface.QuerySTicketsBooking(dto);
        }

        /// <summary>
        /// 查询单个预定单的整单信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryOneSTicketsBookingInfo")]
        public async Task<ApiResultDto<STicketsBookingOneQueryDto>> QueryOneSTicketsBookingInfo([FromBody] QueryByIdDto dto)
        {
            if (null == dto || dto.id < 1)
            {
                return ApiResultDto<STicketsBookingOneQueryDto>.ToResultFail("预定单的ID信息不能为空");
            }
            return await _ticketKdSellInterface.QueryOneSTicketsBookingInfo(dto);
        }

        /// <summary>
        /// 新增、编辑保存预订单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("SaveSTicketsBooking")]
        public async Task<ApiResultDto<STicketsBookingDto>> SaveSTicketsBooking([FromBody] STicketsBookingSaveDto dto) 
        {
            if (null == dto || null == dto.dtoTicketsBooking)
            {
                return ApiResultDto<STicketsBookingDto>.ToResultFail("预定单信息不能为空");
            }
            return await _ticketKdSellInterface.SaveSTicketsBooking(dto);
        }
        #endregion







        #region old
        ///// <summary>
        ///// 测试获取订单编号接口 ok
        ///// </summary>
        ///// <param name="s_branch_id">分店id</param>
        ///// <returns></returns>
        //[HttpPost("GetBranchBillNo")]
        //[AllowAnonymous]
        //public async Task<ApiResultDto> GetBranchBillNo([FromBody] int s_branch_id)
        //{
        //    var ps = new SugarParameter[] {
        //        new SugarParameter("@as_branch_id",s_branch_id),
        //        new SugarParameter("@as_identifier","B"),
        //        new SugarParameter("@as_return","" ,isOutput:true)
        //    };
        //    await DbScoped.Sugar.Ado.UseStoredProcedure().GetStringAsync("[dbo].[Usp_get_next_No]", ps);//营业时间
        //    string getbiiNo = ps[2].Value.ToString();

        //    //var branchid = new SugarParameter("@as_branch_id", 1);
        //    //var btype = new SugarParameter("@as_identifier", "B");
        //    //var returnV = new SugarParameter("@as_return", null, isOutput: true);
        //    //var getBllNo = await DbScoped.Sugar.Ado.UseStoredProcedure().GetDataTableAsync("[dbo].[Usp_get_next_No]", branchid, btype, returnV);//营业时间
        //    //string getbiiNoStr = returnV.Value.ToString();

        //    return ApiResultDto.ToResultSuccess(data: getbiiNo);
        //} 
        #endregion


        #region 取票查询
        /// <summary>
        /// 取票查询 根据取票凭证码，查询出对应的票的信息（单据信息、记录信息、票明细信息）
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QuPiaoQuery")]
        public ApiResultDto<QuPiaoQueryResultDto> QuPiaoQuery([FromBody] QuPiaoQueryDto dto)
        {
            if (dto == null
                || string.IsNullOrEmpty(dto.s_code)
                || string.IsNullOrEmpty(dto.ticket_voucher)
                || string.IsNullOrEmpty(dto.sConfirmGetTicket)
                || dto.n_pagesize_record <= 0
                || dto.n_pagesize_detail <= 0
                )
                return ApiResultDto<QuPiaoQueryResultDto>.ToResultFail(msg: "请检查输入的参数");


            #region 登陆者参数信息
            dto.s_branch_id = _UserTokenInfo.SBranchId;
            var ytime = DateTime.Now;
            var btime = CeChengBusinessFunctionHelper.GetBusinessDateByBranchIdByTb(_UserTokenInfo.SBranchId);//营业日期
            var outName = CeChengBusinessFunctionHelper.GetOutNameByOutIdByTb(_UserTokenInfo.outletId);
            #endregion 


            #region 方法内使用的内部公共参数
            // 门票销售单据ID
            int n_ticket_sell_id = 0;
            // SQL查询参数
            List<SugarParameter> listSqlParam = new List<SugarParameter>();
            // 查询结果返回对象
            QuPiaoQueryResultDto dtoQuPiaoQueryResult = new QuPiaoQueryResultDto();
            dtoQuPiaoQueryResult.sNeedConfirmGetTicket = "N";
            #endregion

            #region 查询是否是平台的票
            // 根据平台编码值，获取平台参数信息
            // 判断退票单据是否存在
            var listPayGroup = DbScoped.Sugar.Queryable<SysPayGroupEntity>().
                Where(c => c.IsActive == "Y" && c.s_type == "QZF" && c.code == dto.s_code)
                .ToList();
            if (null == listPayGroup || 0 == listPayGroup.Count)
            {
                return ApiResultDto<QuPiaoQueryResultDto>.ToResultFail(msg: "平台参数值查询异常");
            }
            // 平台名称
            string sPlatformName = listPayGroup[0].name;
            // 从数据库里获取扫码支付平台的对接参数
            string s_group = "default";
            string depart = listPayGroup[0].depart;
            TicketPlatformParamDto dtoTicketPfParam = CeChengBusinessFunctionHelper.GetTicketPlatformParamFormDb(dto.s_branch_id, s_group, depart);
            if (null == dtoTicketPfParam || string.IsNullOrEmpty(dtoTicketPfParam.apiurl))
            {
                //return ApiResultDto<QuPiaoQueryResultDto>.ToResultFail(msg: "平台对接参数值查询异常");
                dtoTicketPfParam = new TicketPlatformParamDto();
            }

            // 是否是景区系统内部的票
            bool isJqSysTicket = true;
            // 票务平台返回的值
            string sResFromTicketPf = string.Empty;
            dtoTicketPfParam.ticket_code = dto.ticket_voucher;
            dtoTicketPfParam.query_type = 1;
            string sJsonDataParam = JsonConvert.SerializeObject(dtoTicketPfParam);

            // 查询是否是平台的票
            TicketApi apiTicket = new TicketApi();
            string sApiReturn = apiTicket.QueryTicketInfo(dto.s_code, sJsonDataParam, ref sResFromTicketPf);
            if (!string.IsNullOrEmpty(sApiReturn)) // 返回空数据的就是景区系统的票，否在就是平台的票
            {
                if (sApiReturn.ToLower().StartsWith("false|"))
                {
                    return ApiResultDto<QuPiaoQueryResultDto>.ToResultFail(msg: "平台票查询失败");
                }
                isJqSysTicket = false;
            }
            #endregion


            #region 本地景区的票，就查本地系统票对应的表单信息；非本地票的，就按需转成本地票
            if (false == isJqSysTicket) // 其它平台的票，需要调用专用接口去查询、生成（普通劵的，只查本地数据库的记录即可）
            {
                dtoQuPiaoQueryResult.sNeedConfirmGetTicket = "Y";
                string sJsonFromTicketPf = sResFromTicketPf.Substring(5);
                JObject jsonInfoTicket = JsonConvert.DeserializeObject<JObject>(sJsonFromTicketPf);
                int n_amount = Int32.Parse(jsonInfoTicket["count"].ToString()); // 包含的票的数量
                decimal price = decimal.Parse(jsonInfoTicket["price"].ToString());
                string ota_menu_no = jsonInfoTicket["tid"].ToString(); // 票的OTA票的编码
                string ota_ticket_name = jsonInfoTicket["title"].ToString(); // 票的OTA票的名称

                string sJsonFromTicketJk = sApiReturn.Substring(5);
                JObject jsonInfoTicketDetail = JsonConvert.DeserializeObject<JObject>(sJsonFromTicketJk);
                string ota_ordername = string.Empty;
                string ota_telephone = string.Empty;
                string ota_order_id = string.Empty;
                if ("OTA" == dto.s_code && null != jsonInfoTicketDetail && null != jsonInfoTicketDetail["data"])
                {
                    ota_ordername = jsonInfoTicketDetail["data"]["ordername"].ToString();
                    ota_telephone = jsonInfoTicketDetail["data"]["ordertel"].ToString();
                    ota_order_id = jsonInfoTicketDetail["data"]["orderid"].ToString();
                }

                // 查门票设置信息
                var resTicketSet = DbScoped.SugarScope.Queryable<TicketSetEntity>()
                    .Where(c => c.s_branch_id == dto.s_branch_id && c.ota_menu_no == ota_menu_no)
                    .ToList();
                if (null == resTicketSet || resTicketSet.Count < 1)
                {
                    // 返回查询失败信息
                    return ApiResultDto<QuPiaoQueryResultDto>.ToResultFail(msg: "该凭证码对应的票类在本地系统中不存在");
                }

                // 从第三方平台接口查询到票的基本信息后，判断是否需要立即取票，
                // 需要的就转成本地票，保存进数据库，然后，核销第三方平台的票，返回转换后的票的信息
                if (dto.sConfirmGetTicket != "Y") // 暂时不需要取票
                {
                    // 返回查询的票信息
                    dtoQuPiaoQueryResult.n_ticket_num = n_amount;
                    dtoQuPiaoQueryResult.s_ticket_name = resTicketSet[0].ticket_name;
                    return ApiResultDto<QuPiaoQueryResultDto>.ToResultSuccess(data: dtoQuPiaoQueryResult);
                }

                #region 转成本地票，保存进数据库
                string sell_no = CeChengBusinessFunctionHelper.GetSysNextNoByTb(NextNumberIdentityEnum.ticket_sell_no);
                var flag = DbScoped.SugarScope.UseTran<int>(() =>
                {
                    // 求出单据总金额信息
                    decimal? n_NewTotalMoney = n_amount * price;

                    // 开单：写主单表
                    var main_entity = new STitcketSellEntity
                    {
                        booking_no = "",//缺少页面原型
                        cancel_date = null,
                        Is_acctont_uecret = "N",
                        Is_ticket_secret = "N",
                        regcard_id = null,//会员卡id ，后续会员支付的才会有 ??
                        memo = null,//当着总票数来使用 entity.memo,
                        order_amount = n_NewTotalMoney,//订单金额 应该是一个总的金额 必填
                        order_date = ytime,// entity.order_date,
                        ota_ordername = ota_ordername,
                        ota_order_id = ota_order_id,
                        ota_telephone = ota_telephone,
                        pay_amount = n_NewTotalMoney,//
                        pay_date = ytime,// entity.pay_date,
                        pay_type = IsActivityConstStr.xf,//默认消费D D:表示还没有支付, 该字段冗余了
                        platform_code = dto.s_code,
                        platform_name = sPlatformName,
                        refound_amount = null,
                        s_ticket_booking_id = null,
                        wechat_Id = null,
                        create_date = ytime,
                        create_user = _UserTokenInfo.UserWorkNo,
                        s_branch_id = _UserTokenInfo.SBranchId,
                        s_business_set_id = _UserTokenInfo.outletId,
                        sell_no = sell_no,//订单号
                        business_date = btime,
                        business_name = outName,
                        status = IsActivityConstStr.N,
                        account_status = IsActivityConstStr.Y,
                        quit_sell_no = ""
                    };
                    var resTicketSell = DbScoped.SugarScope.Insertable<STitcketSellEntity>(main_entity).ExecuteReturnEntity();
                    if (null == resTicketSell || resTicketSell.id < 1)
                    {
                        // 返回查询失败信息
                        throw new Exception("订单信息生成异常");
                    }

                    // 保存门票记录
                    var listRecord = new List<STicketSellRecordEntity>();
                    foreach (var item in resTicketSet)
                    {
                        var recordEntity = new STicketSellRecordEntity
                        {
                            create_date = ytime,
                            create_user = _UserTokenInfo.UserWorkNo,
                            s_branch_id = _UserTokenInfo.SBranchId,
                            outlet_name = outName,//查询
                            s_titcket_sell_id = resTicketSell.id,//必填

                            ticket_code = item.ticket_code,//应该修改为票的id
                            amount = n_amount, //该票类型的总数量
                            price = price,//该票类型的单价

                            business_date = btime, //根据页面传过来的有效期
                            sell_no = resTicketSell.sell_no,
                            ota_ticketname = ota_ticket_name,
                            pay_type = IsActivityConstStr.xf,// 默认D：消费 ； C：付款
                            pay_date = null,//支付时间
                            n_fen = 0, //积分值
                            other_amount = 0,
                            pay_amount = 0,//支付金额
                            valid_date = item.validate_day.HasValue ? ytime.AddDays(item.validate_day.Value) : item.validate_date,//有效期

                            refound = 0,//退票数量
                            print_type = 1,//打印类型: 0每张套票打印一张; 1每张票打印一张; 2每种票打印一张
                            ticket_number = 0,//出票数量  预订相关
                            ticket_amount = item.price,//门票金额  预订相关
                            ticket_voucher = dto.ticket_voucher,
                            out_trade_no = ""
                        };

                        listRecord.Add(recordEntity);
                    }
                    int count = DbScoped.SugarScope.Insertable<STicketSellRecordEntity>(listRecord).ExecuteCommand();
                    if (count < 1)
                    {
                        throw new Exception("门票记录生成异常");
                    }

                    // 修改单据总金额及出票状态信，出票
                    resTicketSell.status = "Y";
                    count = DbScoped.SugarScope.Updateable<STitcketSellEntity>(resTicketSell).ExecuteCommand();
                    if (count < 1)
                    {
                        throw new Exception("出票异常");
                    }

                    n_ticket_sell_id = resTicketSell.id;
                    dtoQuPiaoQueryResult.dtoTitcketSell = resTicketSell;

                    # region  核销平台的票
                    dtoTicketPfParam.ticket_code = dto.ticket_voucher;
                    dtoTicketPfParam.printtype = 1;
                    dtoTicketPfParam.count = n_amount;
                    sJsonDataParam = JsonConvert.SerializeObject(dtoTicketPfParam);
                    sApiReturn = apiTicket.ConsumeTicket(dto.s_code, sJsonDataParam, ref sResFromTicketPf);
                    if (string.IsNullOrEmpty(sApiReturn) || sApiReturn.ToLower().StartsWith("false|"))
                    {
                        throw new Exception("核销平台票失败");
                    }
                    #endregion

                    return count;
                });
                #endregion

                // 平台的票转换不成功就返回
                if (false == flag.IsSuccess) 
                {
                    return ApiResultDto<QuPiaoQueryResultDto>.ToResultFail(msg: "票转换不成功：" + flag.ErrorMessage);
                }
            }
            else // 本地景区系统的票，查出对应的单据
            {
                var resQryCCTicketBill = DbScoped.Sugar.Queryable<STitcketSellEntity>()
                    .InnerJoin<STicketSellRecordEntity>((o, c) => c.s_titcket_sell_id == o.id)
                    .InnerJoin<STicketSellRecordDetailEntity>((o, c, d) => c.id == d.s_ticket_sell_record_id 
                                                                        && d.Is_used != "Y"
                                                                        && d.is_print != "Y"
                                                                        && d.ticket_voucher == dto.ticket_voucher
                                                            )
                    .WhereIF(dto.s_branch_id > 0, (o, c, d) => d.s_branch_id == dto.s_branch_id)
                    .Select(o => o)
                    .ToList();

                if (null == resQryCCTicketBill || 0 == resQryCCTicketBill.Count)
                {
                    return ApiResultDto<QuPiaoQueryResultDto>.ToResultFail(msg: "凭证码查询失败，没查到对应的购票单");
                }

                dtoQuPiaoQueryResult.dtoTitcketSell = resQryCCTicketBill[0];
                n_ticket_sell_id = dtoQuPiaoQueryResult.dtoTitcketSell.id;
            }
            #endregion

            #region 查记录表信息
            #region 记录表的查询参数
            listSqlParam.Clear();
            string sWhereRecord = "";
            if (isJqSysTicket) // 景区票的，需要将凭证码作为查询条件
            {
                sWhereRecord += $@" and  sr.id in  (
										                select id = rd.s_ticket_sell_record_id
										                from   s_ticket_sell_record_detail  rd 
										                where  1=1
                                                          and  isnull(rd.is_print, '') <> 'Y'
										                  and  isnull(rd.is_used, '') <> 'Y'
                                                          and  rd.ticket_voucher = @ticket_voucher 
                                                    )
                                ";
                listSqlParam.Add(new SugarParameter("@ticket_voucher", dto.ticket_voucher));
            }
            #endregion
            #region 记录表的查询语句
            // 查询记录条数
            string sqlCountRecord = $@"
                                        select iCount = count(*)
                                        from   s_ticket_sell_record sr 
                                               left join s_ticket_set ts on ts.ticket_code = sr.ticket_code and ts.s_branch_id = sr.s_branch_id
                                        where  1=1
                                          and  isnull(sr.pay_type, '') = 'D'
                                          and  sr.s_titcket_sell_id = {n_ticket_sell_id}
                                         {sWhereRecord}
                                    ";
            // 查询记录
            string sqlQueryRecord = $@"
                                        select  row_number() over(order by sr.id) as row_no,
                                                sr.id, sr.s_titcket_sell_id, sr.ticket_code, sr.amount, sr.price, sr.refound, sr.n_fen, sr.business_date, 
                                                sr.sell_no, sr.ticket_number, sr.ticket_amount, sr.other_amount, sr.valid_date, sr.ota_ticketname, 
                                                sr.print_type, sr.pay_date, sr.pay_type, sr.pay_amount, sr.outlet_name, sr.create_date, sr.create_user, 
                                                sr.update_date, sr.update_user, sr.s_branch_id, sr.dts_AuthCode, sr.ticket_voucher,
                                                ts.ticket_name
                                        from   s_ticket_sell_record sr 
                                               left join s_ticket_set ts on ts.ticket_code = sr.ticket_code and ts.s_branch_id = sr.s_branch_id
                                        where  1=1
                                          and  isnull(sr.pay_type, '') = 'D'
                                          and  sr.s_titcket_sell_id = {n_ticket_sell_id}
                                          {sWhereRecord}
                                    ";
            #endregion
            #region 记录表的执行查询
            int iCount = DbScoped.Sugar.Ado.SqlQuerySingle<int>(sqlCountRecord, listSqlParam);

            // 开始与结束
            int iStart = 1;
            int iEnd = dto.n_pagesize_detail;

            sqlQueryRecord = $@"
                                select  *
                                from   (
                                            {sqlQueryRecord}
                                       ) tab
                                where  1=1
                                  and  {iStart} <= row_no 
                                  and  row_no <= {iEnd}
                            ";
            dtoQuPiaoQueryResult.listTicketSellRecord = DbScoped.Sugar.Ado.SqlQuery<GetSTicketSellRecord>(sqlQueryRecord, listSqlParam).ToList();
            if (null == dtoQuPiaoQueryResult.listTicketSellRecord || dtoQuPiaoQueryResult.listTicketSellRecord.Count == 0)
            {
                return ApiResultDto<QuPiaoQueryResultDto>.ToResultFail(data: null, msg: "门票记录不存在");
            }
            #endregion
            #region 更新取票的票号字段值
            if (isJqSysTicket) 
            {
                var listObjRecord = DbScoped.Sugar.Queryable<STicketSellRecordEntity>()
                                                .Where(c => c.id == dtoQuPiaoQueryResult.listTicketSellRecord[0].id)
                                                .ToList();
                string sOldVoucher = listObjRecord[0].ticket_voucher;
                if (string.IsNullOrEmpty(listObjRecord[0].ticket_voucher))
                    sOldVoucher = dto.ticket_voucher;
                else
                    sOldVoucher += dto.ticket_voucher;
                listObjRecord[0].ticket_voucher = sOldVoucher;
                DbScoped.Sugar.Updateable<STicketSellRecordEntity>(listObjRecord[0]).ExecuteCommand();
            }
            #endregion
            #endregion


            #region 查明细信息
            int s_ticket_sell_record_id = dtoQuPiaoQueryResult.listTicketSellRecord[0].id;
            #region 明细表的查询参数
            listSqlParam.Clear();
            string sWhereDetail = "";
            if (isJqSysTicket) // 景区票的，需要将凭证码作为查询条件
            {
                sWhereDetail += $@" and  isnull(rd.is_print, '') <> 'Y' and  rd.s_ticket_sell_record_id = @s_ticket_sell_record_id";
                //listSqlParam.Add(new SugarParameter("@ticket_voucher", dto.ticket_voucher));
                listSqlParam.Add(new SugarParameter("@s_ticket_sell_record_id", s_ticket_sell_record_id));
            }
            #endregion
            #region 明细表的查询语句
            // 查询记录条数
            string sqlCountDetail = $@"
                                            select  iCount = count(*)
                                            from    s_ticket_sell_record_detail rd 
                                                    inner join s_ticket_sell_record   sr on rd.s_ticket_sell_record_id = sr.id
                                                    left  join s_ticket_set           ts on ts.ticket_code = sr.ticket_code and ts.s_branch_id = sr.s_branch_id
                                                    left  join s_consume_item         ci on ci.consume_item_no = rd.s_no and ci.s_branch_id = rd.s_branch_id
                                            where   1=1
                                              and   sr.s_titcket_sell_id = {n_ticket_sell_id}
                                              and   isnull(rd.is_used, '') <> 'Y'
                                    ";
            // 查询记录
            string sqlQueryDetail = $@"
                                        select  row_number() over(order by rd.id) as row_no,
										        rd.id, rd.s_ticket_sell_record_id, rd.ticket_orcode, rd.valid_date, rd.Is_used, rd.cancel_date, rd.use_date, 
												rd.ticket_no, rd.ticket_price, rd.wechat_id, rd.member_name, rd.use_account, rd.user_number, rd.cancel_user, 
												rd.price_ticket, rd.ticket_secret, rd.is_print, rd.use_work_no, rd.use_shift, rd.business_date, 
												rd.ticket_main, rd.create_date, rd.create_user, rd.update_date, rd.update_user, rd.s_branch_id, 
												rd.s_AuthCode, rd.s_no, rd.ticket_voucher,
		                                        ticket_name = case when isnull(ci.consume_item_name, '') <> '' then ci.consume_item_name else ts.ticket_name end,
                                                n_ticket_price = case when ci.price is not null then ci.price else ts.price end
                                        from    s_ticket_sell_record_detail rd 
                                                inner join s_ticket_sell_record   sr on rd.s_ticket_sell_record_id = sr.id
                                                left  join s_ticket_set           ts on ts.ticket_code = sr.ticket_code  and ts.s_branch_id = sr.s_branch_id
                                                left  join s_consume_item         ci on ci.consume_item_no = rd.s_no     and ci.s_branch_id = rd.s_branch_id
                                        where  1=1
                                          and  sr.s_titcket_sell_id = {n_ticket_sell_id}
                                          and  isnull(rd.is_used, '') <> 'Y'

                                    ";
            #endregion
            #region 明细表的执行查询
            int iCountDetail = DbScoped.Sugar.Ado.SqlQuerySingle<int>(sqlCountDetail + sWhereDetail, listSqlParam);

            // 开始与结束
            int iStartDetail = 1;
            int iEndDetail = dto.n_pagesize_record;

            sqlQueryDetail = $@"
                                    select  *
                                    from   (
                                                {sqlQueryDetail + sWhereDetail}
                                           ) tab
                                    where  1=1
                                      and  {iStartDetail} <= row_no 
                                      and  row_no <= {iEndDetail}
                               ";
            dtoQuPiaoQueryResult.listTicketSellRecordDetail = DbScoped.Sugar.Ado.SqlQuery<GetSTicketSellRecordDetailEntity>(sqlQueryDetail, listSqlParam).ToList();
            if (null == dtoQuPiaoQueryResult.listTicketSellRecordDetail || dtoQuPiaoQueryResult.listTicketSellRecordDetail.Count == 0)
            {
                return ApiResultDto<QuPiaoQueryResultDto>.ToResultFail(data: null, msg: "门票项目明细不存在");
            }
            #endregion
            #region 更新票的出票状态
            if (isJqSysTicket)
            {
                var listObjDetail = DbScoped.Sugar.Queryable<STicketSellRecordDetailEntity>()
                    .Where(c => c.s_branch_id == dto.s_branch_id && c.s_ticket_sell_record_id == s_ticket_sell_record_id)
                    .ToList();
                foreach (STicketSellRecordDetailEntity rd in listObjDetail)
                {
                    rd.is_print = "Y";
                }
                DbScoped.Sugar.Updateable<STicketSellRecordDetailEntity>(listObjDetail).ExecuteCommand();
            }
            #endregion
            #endregion

            return ApiResultDto<QuPiaoQueryResultDto>.ToResultSuccess(data: dtoQuPiaoQueryResult);
        }
        #endregion


        /// <summary>
        /// 批量修改票的而有效期
        /// </summary>
        /// <returns></returns>
        [HttpPost("BattchUpdateValidDate")]
        public async Task<ApiResultDto> BattchUpdateValidDate([FromBody] BattchUpdateValidDateDto dto)
        {
            if (null == dto || null == dto.listTicketDetailID || 0 == dto.listTicketDetailID.Count || false == dto.new_viladdate.HasValue)
            {
                return ApiResultDto.ToResultFail(msg: "项目ID列表、有效期不能为空");
            }
            return await _ticketKdSellInterface.BattchUpdateValidDate(dto);
        }

        /// <summary>
        /// 执行退票
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        [HttpPost("ExecQuitTicket")]
        public async Task<ApiResultDto> ExecQuitTicket([FromBody] QuitTicketDto entity)
        {
            if (null == entity || entity.sell_id_now.HasValue == false)
                return ApiResultDto.ToResultFail("退单号,分店id不可以为空");
            return await _ticketKdSellInterface.ExecQuitTicket(entity);
        }
    }
}

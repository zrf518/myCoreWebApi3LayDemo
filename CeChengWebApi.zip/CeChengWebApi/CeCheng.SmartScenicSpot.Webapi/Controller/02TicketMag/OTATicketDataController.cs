﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models.Consts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using SqlSugar.IOC;
using System.Threading.Tasks;
using CeCheng.SmartScenicSpot.Models.Dto.TicketMag.OTA;
using Google.Protobuf.WellKnownTypes;
using CeCheng.SmartScenicSpot.Commoms;
using NPOI.SS.Formula.Functions;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 02 票务管理相关模块：OTA票务平台数据接口
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class OTATicketDataController : ControllerBase
    {
        private readonly ILogger<OTATicketDataController> _LogService;
        private readonly IOTATicketDataInterface _OTATicketDataService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;
        // 会员卡数据库连接地址
        private string sCardDBConn = null;
        // 当前登陆这的营业点信息
        private LoginBusinessDataDto loginBusinessDataDto = null;

        private string OTA_ApiUrl = string.Empty;
        private string OTA_CustomerNo = string.Empty;
        private string OTA_Secret = string.Empty;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="OTATicketDataService"></param>
        /// <param name="logService"></param>
        public OTATicketDataController(IOTATicketDataInterface OTATicketDataService, ILogger<OTATicketDataController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _OTATicketDataService = OTATicketDataService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
            sCardDBConn = CardDBConstConn.ConnectionCardDBStr;
            loginBusinessDataDto = new LoginBusinessDataDto();
            loginBusinessDataDto.sOutletNo = "01";
            loginBusinessDataDto.s_set_class = "1";
            loginBusinessDataDto.s_sys_date = DateTime.Now.ToString("yyyy-MM-dd");
        }

        /// <summary>
        /// 查询平台信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryPlatformList")]
        public ApiResultDto QueryPlatformList([FromBody] OTAMerchantDto dto)
        {
            try
            {
                bool bGetParam = GetCustParam();
                if (false == bGetParam)
                {
                    return ApiResultDto.ToResultFail(data: null, msg: "参数查询异常");
                }
                if (null == dto)
                {
                    dto = new OTAMerchantDto();
                }

                string apiFullpath = OTA_ApiUrl + "/Ticket/TicketData/?method=QueryPlatformList";
                string tokenStr = GetOTALoginAuthStr();
                object dataDto = dto;

                string sResCallBack = CeChengHttpClientHelper.PostHost(apiFullpath, tokenStr, dataDto);
                if (!string.IsNullOrEmpty(sResCallBack))
                {
                    JObject jObjBack = JsonConvert.DeserializeObject<JObject>(sResCallBack);
                    if (jObjBack["code"].ToString() == "0")
                    {
                        return ApiResultDto.ToResultSuccess(data: jObjBack);
                    }
                    return ApiResultDto.ToResultFail(data: jObjBack, msg: "接口调用异常：" + jObjBack["message"].ToString());
                }
                return ApiResultDto.ToResultFail(data: null, msg: "接口调用异常，返回数据为空");
            }
            catch (Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=平台信息查询异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "平台信息查询异常");
            }
        }

        /// <summary>
        /// 查询OTA门票设置信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryTicketSet")]
        public ApiResultDto QueryTicketSet([FromBody] OTATicketTypeDto dto)
        {
            try
            {
                bool bGetParam = GetCustParam();
                if (false == bGetParam)
                {
                    return ApiResultDto.ToResultFail(data: null, msg: "参数查询异常");
                }
                if (null == dto)
                {
                    dto = new OTATicketTypeDto();
                }

                string apiFullpath = OTA_ApiUrl + "/Ticket/TicketData/?method=QueryTicketSet";
                string tokenStr = GetOTALoginAuthStr();
                object dataDto = dto;

                string sResCallBack = CeChengHttpClientHelper.PostHost(apiFullpath, tokenStr, dataDto);
                if (!string.IsNullOrEmpty(sResCallBack))
                {
                    JObject jObjBack = JsonConvert.DeserializeObject<JObject>(sResCallBack);
                    if (jObjBack["code"].ToString() == "0")
                    {
                        return ApiResultDto.ToResultSuccess(data: jObjBack);
                    }
                    return ApiResultDto.ToResultFail(data: jObjBack, msg: "接口调用异常：" + jObjBack["message"].ToString());
                }
                return ApiResultDto.ToResultFail(data: null, msg: "接口调用异常，返回数据为空");
            }
            catch (Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询OTA门票设置信息异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "查询OTA门票设置信息异常");
            }
        }

        /// <summary>
        /// 新增OTA门票设置信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("InsertNewTicket")]
        public ApiResultDto InsertNewTicket([FromBody] OTATicketTypeDto dto)
        {
            try
            {
                bool bGetParam = GetCustParam();
                if (false == bGetParam)
                {
                    return ApiResultDto.ToResultFail(data: null, msg: "参数查询异常");
                }
                if (null == dto)
                {
                    dto = new OTATicketTypeDto();
                }
                dto.CustomerNo = OTA_CustomerNo;
                dto.create_user = sUserWorkNo;

                string apiFullpath = OTA_ApiUrl + "/Ticket/TicketData/?method=InsertNewTicket";
                string tokenStr = GetOTALoginAuthStr();
                object dataDto = dto;

                string sResCallBack = CeChengHttpClientHelper.PostHost(apiFullpath, tokenStr, dataDto);
                if (!string.IsNullOrEmpty(sResCallBack))
                {
                    JObject jObjBack = JsonConvert.DeserializeObject<JObject>(sResCallBack);
                    if (jObjBack["code"].ToString() == "0")
                    {
                        return ApiResultDto.ToResultSuccess(data: jObjBack);
                    }
                    return ApiResultDto.ToResultFail(data: jObjBack, msg: "接口调用异常：" + jObjBack["message"].ToString());
                }
                return ApiResultDto.ToResultFail(data: null, msg: "接口调用异常，返回数据为空");
            }
            catch (Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增OTA门票设置信息异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增OTA门票设置信息异常");
            }
        }

        /// <summary>
        /// 编辑OTA门票设置信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("UpdateTicketSet")]
        public ApiResultDto UpdateTicketSet([FromBody] OTATicketTypeDto dto)
        {
            try
            {
                bool bGetParam = GetCustParam();
                if (false == bGetParam)
                {
                    return ApiResultDto.ToResultFail(data: null, msg: "参数查询异常");
                }
                if (null == dto)
                {
                    dto = new OTATicketTypeDto();
                }
                dto.CustomerNo = OTA_CustomerNo;
                dto.Alter_user = sUserWorkNo;

                string apiFullpath = OTA_ApiUrl + "/Ticket/TicketData/?method=UpdateTicketSet";
                string tokenStr = GetOTALoginAuthStr();
                object dataDto = dto;

                string sResCallBack = CeChengHttpClientHelper.PostHost(apiFullpath, tokenStr, dataDto);
                if (!string.IsNullOrEmpty(sResCallBack))
                {
                    JObject jObjBack = JsonConvert.DeserializeObject<JObject>(sResCallBack);
                    if (jObjBack["code"].ToString()  == "0")
                    {
                        return ApiResultDto.ToResultSuccess(data: jObjBack);
                    }
                    return ApiResultDto.ToResultFail(data: jObjBack, msg: "接口调用异常：" + jObjBack["message"].ToString());
                }
                return ApiResultDto.ToResultFail(data: null, msg: "接口调用异常，返回数据为空");
            }
            catch (Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=编辑OTA门票设置信息异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "编辑OTA门票设置信息异常");
            }
        }

        /// <summary>
        /// 查询OTA门票销售明细信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryHisSaleDetail")]
        public ApiResultDto QueryHisSaleDetail([FromBody] HisSaleTicketQueryParamDto dto)
        {
            try
            {
                bool bGetParam = GetCustParam();
                if (false == bGetParam)
                {
                    return ApiResultDto.ToResultFail(data: null, msg: "参数查询异常");
                }
                if (null == dto)
                {
                    dto = new HisSaleTicketQueryParamDto();
                }

                string apiFullpath = OTA_ApiUrl + "/Ticket/TicketData/?method=QueryHisSaleDetail";
                string tokenStr = GetOTALoginAuthStr();
                object dataDto = dto;

                string sResCallBack = CeChengHttpClientHelper.PostHost(apiFullpath, tokenStr, dataDto);
                if (!string.IsNullOrEmpty(sResCallBack))
                {
                    JObject jObjBack = JsonConvert.DeserializeObject<JObject>(sResCallBack);
                    if (jObjBack["code"].ToString() == "0")
                    {
                        return ApiResultDto.ToResultSuccess(data: jObjBack);
                    }
                    return ApiResultDto.ToResultFail(data: jObjBack, msg: "接口调用异常：" + jObjBack["message"].ToString());
                }
                return ApiResultDto.ToResultFail(data: null, msg: "接口调用异常，返回数据为空");
            }
            catch (Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询OTA门票销售明细信息异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "查询OTA门票销售明细信息异常");
            }
        }

        /// <summary>
        /// 查询OTA门票销售汇总信息
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryHisSaleCount")]
        public ApiResultDto QueryHisSaleCount([FromBody] HisSaleTicketQueryParamDto dto)
        {
            try
            {
                bool bGetParam = GetCustParam();
                if (false == bGetParam)
                {
                    return ApiResultDto.ToResultFail(data: null, msg: "参数查询异常");
                }
                if (null == dto)
                {
                    dto = new HisSaleTicketQueryParamDto();
                }

                string apiFullpath = OTA_ApiUrl + "/Ticket/TicketData/?method=QueryHisSaleCount";
                string tokenStr = GetOTALoginAuthStr();
                object dataDto = dto;

                string sResCallBack = CeChengHttpClientHelper.PostHost(apiFullpath, tokenStr, dataDto);
                if (!string.IsNullOrEmpty(sResCallBack))
                {
                    JObject jObjBack = JsonConvert.DeserializeObject<JObject>(sResCallBack);
                    if (jObjBack["code"].ToString() == "0")
                    {
                        return ApiResultDto.ToResultSuccess(data: jObjBack);
                    }
                    return ApiResultDto.ToResultFail(data: jObjBack, msg: "接口调用异常：" + jObjBack["message"].ToString());
                }
                return ApiResultDto.ToResultFail(data: null, msg: "接口调用异常，返回数据为空");
            }
            catch (Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询OTA门票销售汇总信息异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "查询OTA门票销售汇总信息异常");
            }
        }

        /// <summary>
        /// 获取OTA登陆授权字符串
        /// </summary>
        /// <returns></returns>
        private bool GetCustParam()
        {
            // 查看参数配置
            var resQryWxParam = DbScoped.Sugar.Queryable<SysPayParamaterEntity>()
                .Where(x => x.s_branch_id == i_branch_id
                            && (x.Name == "OTA_ApiUrl" || x.Name == "OTA_CustomerNo" || x.Name == "OTA_Secret")
                      )
                .ToList();

            if (null == resQryWxParam || 0 == resQryWxParam.Count)
            {
                return false;
            }

            // 提取参数配置
            foreach (SysPayParamaterEntity wxp in resQryWxParam)
            {
                if (wxp.Name.Trim().ToLower() == "ota_apiurl")
                {
                    OTA_ApiUrl = wxp.Value;
                    if (!string.IsNullOrEmpty(OTA_ApiUrl)) 
                    {
                        if (OTA_ApiUrl.Trim().ToLower().Contains("/cechenguse"))
                        {
                            OTA_ApiUrl = OTA_ApiUrl.Substring(0, OTA_ApiUrl.Trim().ToLower().IndexOf("/cechenguse"));
                        }
                    }
                }
                else if (wxp.Name.Trim().ToLower() == "ota_customerno")
                {
                    OTA_CustomerNo = wxp.Value;
                }
                else if (wxp.Name.Trim().ToLower() == "ota_secret")
                {
                    OTA_Secret = wxp.Value;
                }
            }

            return true;
        }


        /// <summary>
        /// 获取OTA登陆授权字符串
        /// </summary>
        /// <returns></returns>
        private string GetOTALoginAuthStr()
        {
            // 时间戳
            string timesp = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalMilliseconds.ToString();

            // 组织客户信息对象
            JObject jObjCust = new JObject();
            jObjCust["OTA_CustomerNo"] = OTA_CustomerNo;
            jObjCust["OTA_Secret"] = OTA_Secret;
            string sCustInfo = JsonConvert.SerializeObject(jObjCust);

            // 组装加密字符串
            string sAuthStr = $"appid=web&timespan={timesp}&sign={sCustInfo}";
            sAuthStr = CeChengRSASign.RSAEnCrypt(sAuthStr, RSAKeyValueInfo.Pubkey);

            return sAuthStr;
        }
    }
}

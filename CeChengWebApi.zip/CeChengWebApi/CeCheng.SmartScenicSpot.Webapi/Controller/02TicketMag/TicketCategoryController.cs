﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 02 票务管理相关模块：门票类型设置
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class TicketCategoryController : ControllerBase
    {
        private readonly ILogger<TicketCategoryController> _LogService;
        private readonly ITicketCategoryInterface _TicketCategoryService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="TicketCategoryService"></param>
        /// <param name="logService"></param>
        public TicketCategoryController(ITicketCategoryInterface TicketCategoryService, ILogger<TicketCategoryController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _TicketCategoryService = TicketCategoryService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增门票类型设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addTicketCategoryAsync")]
        public async Task<ApiResultDto> AddTicketCategoryAsync([FromBody] TicketCategoryDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.category_code)
                        && !string.IsNullOrEmpty(dto.category_name)
                        && dto.type_flag.HasValue
                        && !string.IsNullOrEmpty(dto.oper_big_type)
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _TicketCategoryService.AddTicketCategoryAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "门票类型编码、名称、操作类别、大大类的数据不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增门票类型设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增门票类型设置异常");
            }
        }

        /// <summary>
        /// 修改门票类型设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editTicketCategoryAsync")]
        public async Task<ApiResultDto> EditTicketCategoryAsync([FromBody] TicketCategoryDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.category_code)
                        && !string.IsNullOrEmpty(dto.category_name)
                        && dto.type_flag.HasValue
                        && !string.IsNullOrEmpty(dto.oper_big_type)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _TicketCategoryService.EditTicketCategoryAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "门票类型编码、名称、操作类别、大大类、是否有效的数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改门票类型设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改门票类型设置异常");
            }
        }

        /// <summary>
        /// 查询门票类型设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryTicketCategoryAsync")]
        public async Task<ApiResultPageNationTDataDto<List<TicketCategorySearchResultDto>>> QueryTicketCategoryAsync([FromBody] TicketCategorySearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new TicketCategorySearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _TicketCategoryService.QueryTicketCategoryAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<TicketCategorySearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询门票类型设置异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<TicketCategorySearchResultDto>>.ToResultFail(msg: "查询门票类型设置异常");
            }
        }

        /// <summary>
        /// 删除门票类型设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeTicketCategoryAsync")]
        public async Task<ApiResultDto> RemoveTicketCategoryAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _TicketCategoryService.RemoveTicketCategoryAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的门票类型设置id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除门票类型设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除门票类型设置异常");
            }
        }
        /// <summary>
        /// 批量删除门票类型设置
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveTicketCategoryAsync")]
        public async Task<ApiResultDto> BattchRemoveTicketCategoryAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _TicketCategoryService.BattchRemoveTicketCategoryAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的门票类型设置id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除门票类型设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除门票类型设置异常");
            }
        }
    }
}



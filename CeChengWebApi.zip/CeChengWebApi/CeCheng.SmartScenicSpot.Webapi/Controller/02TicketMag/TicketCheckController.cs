﻿using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using CeCheng.SmartScenicSpot.Contracts;
using SqlSugar.IOC;
using SqlSugar;
using System.Linq;
using System.Collections.Generic;
using System;
using CeCheng.SmartScenicSpot.Commoms;
using NPOI.POIFS.FileSystem;
using NPOI.SS.Formula.Functions;
using Ticket;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using static ICSharpCode.SharpZipLib.Zip.ExtendedUnixData;


namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 02 票务管理相关模块  开单销售门票
    /// </summary>
    [Route("api/ticket/[controller]")]
    [Area("ticket")]
    [ApiController]
    [Authorize]
    public class TicketCheckController : CeChengBaseController
    {
        private readonly ITicketCheckInterface _ticketCheckInterface;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <param name="ticketCheckInterface"></param>
        public TicketCheckController(IHttpContextAccessor httpContextAccessor, ITicketCheckInterface ticketCheckInterface) : base(httpContextAccessor)
        {
            _ticketCheckInterface = ticketCheckInterface;
        }

        #region 电脑上验票
        /// <summary>
        /// 电脑上验票
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("CheckTicketOnPc")]
        public ApiResultDto<TicketCheckResultDto> CheckTicketOnPc([FromBody] TicketCheckPostParamDto dto)
        {
            if (dto == null
                || string.IsNullOrEmpty(dto.ticket_voucher)
                )
                return ApiResultDto<TicketCheckResultDto>.ToResultFail(msg: "请检查输入的参数：验票凭证码不能为空");


            #region 登陆者参数信息
            dto.s_branch_id = _UserTokenInfo.SBranchId;
            var ytime = DateTime.Now;
            var btime = CeChengBusinessFunctionHelper.GetBusinessDateByBranchIdByTb(_UserTokenInfo.SBranchId);//营业日期
            var outName = CeChengBusinessFunctionHelper.GetOutNameByOutIdByTb(_UserTokenInfo.outletId);
            #endregion


            #region 方法内使用的内部公共参数
            // 是否是景区系统内部的票
            bool isJqSysTicket = true;
            // 门票销售单据ID
            int n_ticket_sell_id = 0;
            // 票务平台返回的值
            string sResFromTicketPf = string.Empty;
            // 票务dll接口返回来的
            string sApiReturn = string.Empty;
            // 票务平台名称
            string sPlatformName = String.Empty;
            // 票务平台对接参数对象
            TicketPlatformParamDto dtoTicketPfParam = null;
            // 票务平台对接参数字符串（对应dtoTicketPfParam转换成字符串后的值）
            string sJsonDataParam = string.Empty;
            // SQL查询参数
            List <SugarParameter> listSqlParam = new List<SugarParameter>();
            // 查询结果返回对象
            TicketCheckResultDto dtoTicketCheckResult = new TicketCheckResultDto();
            // 对应的票项目明细列表
            List<STicketSellRecordDetailEntity> resQryDetails = null;
            // 查询是否是平台的票
            TicketApi apiTicket = new TicketApi();
            #endregion


            #region 查询是否是平台的票
            if (!string.IsNullOrEmpty(dto.s_code))
            {
                // 根据平台编码值，获取平台参数信息
                // 判断退票单据是否存在
                var listPayGroup = DbScoped.Sugar.Queryable<SysPayGroupEntity>().
                    Where(c => c.IsActive == "Y" && c.s_type == "QZF" && c.code == dto.s_code)
                    .ToList();
                if (null == listPayGroup || 0 == listPayGroup.Count)
                {
                    return ApiResultDto<TicketCheckResultDto>.ToResultFail(msg: "平台参数值查询异常");
                }
                sPlatformName = listPayGroup[0].name;
                // 从数据库里获取扫码支付平台的对接参数
                string s_group = "default";
                string depart = listPayGroup[0].depart;
                dtoTicketPfParam = CeChengBusinessFunctionHelper.GetTicketPlatformParamFormDb(dto.s_branch_id, s_group, depart);
                if (null == dtoTicketPfParam || string.IsNullOrEmpty(dtoTicketPfParam.apiurl))
                {
                    //return ApiResultDto<TicketCheckResultDto>.ToResultFail(msg: "平台对接参数值查询异常");
                    dtoTicketPfParam = new TicketPlatformParamDto();
                }

                dtoTicketPfParam.ticket_code = dto.ticket_voucher;
                dtoTicketPfParam.query_type = 1;
                sJsonDataParam = JsonConvert.SerializeObject(dtoTicketPfParam);

                sApiReturn = apiTicket.QueryTicketInfo(dto.s_code, sJsonDataParam, ref sResFromTicketPf);
                if (!string.IsNullOrEmpty(sApiReturn)) // 返回空数据的就是景区系统的票，否在就是平台的票
                {
                    if (sApiReturn.ToLower().StartsWith("false|"))
                    {
                        return ApiResultDto<TicketCheckResultDto>.ToResultFail(msg: "平台票查询失败");
                    }
                    isJqSysTicket = false;
                }
            }
            #endregion


            #region 本地景区的票，就查本地系统票对应的表单信息；非本地票的，就按需转成本地票
            if (false == isJqSysTicket) // 其它平台的票，需要调用专用接口去查询、生成（普通劵的，只查本地数据库的记录即可）
            {
                string sJsonFromTicketPf = sResFromTicketPf.Substring(5);
                JObject jsonInfoTicket = JsonConvert.DeserializeObject<JObject>(sJsonFromTicketPf);
                int n_amount = Int32.Parse(jsonInfoTicket["count"].ToString()); // 包含的票的数量
                decimal price = decimal.Parse(jsonInfoTicket["price"].ToString());
                string ota_menu_no = jsonInfoTicket["tid"].ToString(); // 票的OTA票的编码
                string ota_ticket_name = jsonInfoTicket["title"].ToString(); // 票的OTA票的名称

                string sJsonFromTicketJk = sApiReturn.Substring(5);
                JObject jsonInfoTicketDetail = JsonConvert.DeserializeObject<JObject>(sJsonFromTicketJk);
                string ota_ordername = string.Empty;
                string ota_telephone = string.Empty;
                string ota_order_id = string.Empty;
                if ("OTA" == dto.s_code && null != jsonInfoTicketDetail && null != jsonInfoTicketDetail["data"])
                {
                    ota_ordername = jsonInfoTicketDetail["data"]["ordername"].ToString();
                    ota_telephone = jsonInfoTicketDetail["data"]["ordertel"].ToString();
                    ota_order_id = jsonInfoTicketDetail["data"]["orderid"].ToString();
                }

                // 查门票设置信息
                var resTicketSet = DbScoped.SugarScope.Queryable<TicketSetEntity>()
                    .Where(c => c.s_branch_id == dto.s_branch_id && c.ota_menu_no == ota_menu_no)
                    .ToList();
                if (null == resTicketSet || resTicketSet.Count < 1)
                {
                    // 返回查询失败信息
                    return ApiResultDto<TicketCheckResultDto>.ToResultFail(msg: "该凭证码对应的票类在本地系统中不存在");
                }

                #region 转成本地票，保存进数据库
                string sell_no = CeChengBusinessFunctionHelper.GetSysNextNoByTb(NextNumberIdentityEnum.ticket_sell_no);
                var flag = DbScoped.SugarScope.UseTran<int>(() =>
                {
                    // 求出单据总金额信息
                    decimal? n_NewTotalMoney = n_amount * price;

                    // 开单：写主单表
                    var main_entity = new STitcketSellEntity
                    {
                        booking_no = "",//缺少页面原型
                        cancel_date = null,
                        Is_acctont_uecret = "N",
                        Is_ticket_secret = "N",
                        regcard_id = null,//会员卡id ，后续会员支付的才会有 ??
                        memo = null,//当着总票数来使用 entity.memo,
                        order_amount = n_NewTotalMoney,//订单金额 应该是一个总的金额 必填
                        order_date = ytime,// entity.order_date,
                        ota_ordername = ota_ordername,
                        ota_order_id = ota_order_id,
                        ota_telephone = ota_telephone,
                        pay_amount = n_NewTotalMoney,//
                        pay_date = ytime,// entity.pay_date,
                        pay_type = IsActivityConstStr.xf,//默认消费D D:表示还没有支付, 该字段冗余了
                        platform_code = dto.s_code,
                        platform_name = sPlatformName,
                        refound_amount = null,
                        s_ticket_booking_id = null,
                        wechat_Id = null,
                        create_date = ytime,
                        create_user = _UserTokenInfo.UserWorkNo,
                        s_branch_id = _UserTokenInfo.SBranchId,
                        s_business_set_id = _UserTokenInfo.outletId,
                        sell_no = sell_no,//订单号
                        business_date = btime,
                        business_name = outName,
                        status = IsActivityConstStr.N,
                        account_status = IsActivityConstStr.Y,
                        quit_sell_no = ""
                    };
                    var resTicketSell = DbScoped.SugarScope.Insertable<STitcketSellEntity>(main_entity).ExecuteReturnEntity();
                    if (null == resTicketSell || resTicketSell.id < 1)
                    {
                        // 返回查询失败信息
                        throw new Exception("订单信息生成异常");
                    }

                    // 保存门票记录
                    var listRecord = new List<STicketSellRecordEntity>();
                    foreach (var item in resTicketSet)
                    {
                        var recordEntity = new STicketSellRecordEntity
                        {
                            create_date = ytime,
                            create_user = _UserTokenInfo.UserWorkNo,
                            s_branch_id = _UserTokenInfo.SBranchId,
                            outlet_name = outName,//查询
                            s_titcket_sell_id = resTicketSell.id,//必填

                            ticket_code = item.ticket_code,//应该修改为票的id
                            amount = n_amount, //该票类型的总数量
                            price = price,//该票类型的单价

                            business_date = btime, //根据页面传过来的有效期
                            sell_no = resTicketSell.sell_no,
                            ota_ticketname = ota_ticket_name,
                            pay_type = IsActivityConstStr.xf,// 默认D：消费 ； C：付款
                            pay_date = null,//支付时间
                            n_fen = 0, //积分值
                            other_amount = 0,
                            pay_amount = 0,//支付金额
                            valid_date = item.validate_day.HasValue ? ytime.AddDays(item.validate_day.Value) : item.validate_date,//有效期

                            refound = 0,//退票数量
                            print_type = 1,//打印类型: 0每张套票打印一张; 1每张票打印一张; 2每种票打印一张
                            ticket_number = 0,//出票数量  预订相关
                            ticket_amount = item.price,//门票金额  预订相关
                            ticket_voucher = dto.ticket_voucher,
                            out_trade_no = ""
                        };

                        listRecord.Add(recordEntity);
                    }
                    int count = DbScoped.SugarScope.Insertable<STicketSellRecordEntity>(listRecord).ExecuteCommand();
                    if (count < 1)
                    {
                        throw new Exception("门票记录生成异常");
                    }

                    // 修改单据总金额及出票状态信，出票
                    resTicketSell.status = "Y";
                    count = DbScoped.SugarScope.Updateable<STitcketSellEntity>(resTicketSell).ExecuteCommand();
                    if (count < 1)
                    {
                        throw new Exception("出票异常");
                    }

                    n_ticket_sell_id = resTicketSell.id;

                    # region  核销平台的票
                    dtoTicketPfParam.ticket_code = dto.ticket_voucher;
                    dtoTicketPfParam.printtype = 1;
                    dtoTicketPfParam.count = n_amount;
                    sJsonDataParam = JsonConvert.SerializeObject(dtoTicketPfParam);
                    sApiReturn = apiTicket.ConsumeTicket(dto.s_code, sJsonDataParam, ref sResFromTicketPf);
                    if (string.IsNullOrEmpty(sApiReturn) || sApiReturn.ToLower().StartsWith("false|"))
                    {
                        throw new Exception("核销平台票失败");
                    }
                    #endregion

                    #region  提取核销转换过来的票明细
                    resQryDetails = DbScoped.SugarScope.Queryable<STicketSellRecordDetailEntity>()
                                        .InnerJoin<STicketSellRecordEntity>((d, r) => d.s_ticket_sell_record_id == r.id)
                                        .InnerJoin<STitcketSellEntity>((d, r, s) => r.s_titcket_sell_id == s.id)
                                        .Select((d, r, s) => d)
                                        .ToList();
                    #endregion

                    return count;
                });
                #endregion

                // 平台的票转换不成功就返回
                if (false == flag.IsSuccess)
                {
                    return ApiResultDto<TicketCheckResultDto>.ToResultFail(msg: "票转换不成功：" + flag.ErrorMessage);
                }
                if (null == resQryDetails || 0 == resQryDetails.Count)
                {
                    return ApiResultDto<TicketCheckResultDto>.ToResultFail(msg: "系统异常：出票成功，但是票明细查询失败，请联系管理员处理");
                }
            }
            else // 本地景区系统的票，查出对应的票明细
            {
                resQryDetails = DbScoped.SugarScope.Queryable<STicketSellRecordDetailEntity>()
                                    .Where(c => c.s_branch_id == dto.s_branch_id && c.ticket_main == dto.ticket_voucher && c.Is_used != "Y" && c.Is_used != "C")
                                    .ToList();
                if (null == resQryDetails || 0 == resQryDetails.Count)
                {
                    return ApiResultDto<TicketCheckResultDto>.ToResultFail(msg: "票明细查询失败，没有可用的票");
                }
            }
            #endregion


            #region  批量改状态
            foreach (STicketSellRecordDetailEntity oneDetailCh in resQryDetails)
            {
                oneDetailCh.Is_used = "Y";
                oneDetailCh.user_number = 1;
                oneDetailCh.use_date = DateTime.Now;
                oneDetailCh.use_work_no = _UserTokenInfo.UserWorkNo;
            }
            int iUpdateCount = DbScoped.SugarScope.Updateable<STicketSellRecordDetailEntity>(resQryDetails).ExecuteCommand();
            if (iUpdateCount < 1)
            {
                return ApiResultDto<TicketCheckResultDto>.ToResultFail(msg: "票状态更新失败");
            }
            dtoTicketCheckResult.n_success_check_count = iUpdateCount;
            #endregion


            return ApiResultDto<TicketCheckResultDto>.ToResultSuccess(data: dtoTicketCheckResult);
        }
        #endregion
    }
}

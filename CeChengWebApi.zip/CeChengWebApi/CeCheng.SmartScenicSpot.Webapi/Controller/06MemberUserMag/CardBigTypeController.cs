﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;
using CeCheng.SmartScenicSpot.Models.Consts;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 06 会员管理相关模块：卡大类
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class CardBigTypeController : ControllerBase
    {
        private readonly ILogger<CardBigTypeController> _LogService;
        private readonly ICardBigTypeInterface _CardBigTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;
        // 会员卡数据库连接地址
        private string sCardDBConn = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="CardBigTypeService"></param>
        /// <param name="logService"></param>
        public CardBigTypeController(ICardBigTypeInterface CardBigTypeService, ILogger<CardBigTypeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _CardBigTypeService = CardBigTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
            sCardDBConn = CardDBConstConn.ConnectionCardDBStr;
        }

        /// <summary>
        /// 新增卡大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addCardBigTypeAsync")]
        public async Task<ApiResultDto> AddCardBigTypeAsync([FromBody] CardBigTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.s_no)
                        && !string.IsNullOrEmpty(dto.s_name)
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _CardBigTypeService.AddCardBigTypeAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "卡大类编码、名称数据不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增卡大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增卡大类异常");
            }
        }

        /// <summary>
        /// 修改卡大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editCardBigTypeAsync")]
        public async Task<ApiResultDto> EditCardBigTypeAsync([FromBody] CardBigTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.s_no)
                        && !string.IsNullOrEmpty(dto.s_name)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _CardBigTypeService.EditCardBigTypeAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "卡大类编码、名称、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改卡大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改卡大类异常");
            }
        }

        /// <summary>
        /// 查询卡大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryCardBigTypeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<CardBigTypeSearchResultDto>>> QueryCardBigTypeAsync([FromBody] CardBigTypeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new CardBigTypeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _CardBigTypeService.QueryCardBigTypeAsync(sCardDBConn, dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<CardBigTypeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询卡大类异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<CardBigTypeSearchResultDto>>.ToResultFail(msg: "查询卡大类异常");
            }
        }

        /// <summary>
        /// 删除卡大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeCardBigTypeAsync")]
        public async Task<ApiResultDto> RemoveCardBigTypeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _CardBigTypeService.RemoveCardBigTypeAsync(sCardDBConn, sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的卡大类id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除卡大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除卡大类异常");
            }
        }
        /// <summary>
        /// 批量删除卡大类
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveCardBigTypeAsync")]
        public async Task<ApiResultDto> BattchRemoveCardBigTypeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _CardBigTypeService.BattchRemoveCardBigTypeAsync(sCardDBConn, sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的卡大类id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除卡大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除卡大类异常");
            }
        }
    }
}

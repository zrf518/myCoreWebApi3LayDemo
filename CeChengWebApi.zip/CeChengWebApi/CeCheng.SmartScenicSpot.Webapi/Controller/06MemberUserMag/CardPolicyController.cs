﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;
using CeCheng.SmartScenicSpot.Models.Consts;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 06 会员管理相关模块：优惠政策
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class CardPolicyController : ControllerBase
    {
        private readonly ILogger<CardPolicyController> _LogService;
        private readonly ICardPolicyInterface _CardPolicyService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;
        // 会员卡数据库连接地址
        private string sCardDBConn = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="CardPolicyService"></param>
        /// <param name="logService"></param>
        public CardPolicyController(ICardPolicyInterface CardPolicyService, ILogger<CardPolicyController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _CardPolicyService = CardPolicyService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
            sCardDBConn = CardDBConstConn.ConnectionCardDBStr;
        }

        /// <summary>
        /// 新增优惠政策接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addCardPolicyAsync")]
        public async Task<ApiResultDto> AddCardPolicyAsync([FromBody] CardPolicyDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.s_code)
                        && !string.IsNullOrEmpty(dto.s_describe)
                        && !string.IsNullOrEmpty(dto.cardtype)
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.IsActive = "Y";

                        var reuslt = await _CardPolicyService.AddCardPolicyAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "卡类型编码、优惠政策编码、名称数据不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增优惠政策异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增优惠政策异常");
            }
        }

        /// <summary>
        /// 修改优惠政策接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editCardPolicyAsync")]
        public async Task<ApiResultDto> EditCardPolicyAsync([FromBody] CardPolicyDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.s_code)
                        && !string.IsNullOrEmpty(dto.s_describe)
                        && !string.IsNullOrEmpty(dto.cardtype)
                        && !string.IsNullOrEmpty(dto.IsActive))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _CardPolicyService.EditCardPolicyAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "卡类型编码、优惠政策编码、名称、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改优惠政策异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改优惠政策异常");
            }
        }

        /// <summary>
        /// 查询优惠政策接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryCardPolicyAsync")]
        public async Task<ApiResultPageNationTDataDto<List<CardPolicySearchResultDto>>> QueryCardPolicyAsync([FromBody] CardPolicySearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new CardPolicySearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _CardPolicyService.QueryCardPolicyAsync(sCardDBConn, dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<CardPolicySearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询优惠政策异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<CardPolicySearchResultDto>>.ToResultFail(msg: "查询优惠政策异常");
            }
        }

        /// <summary>
        /// 删除优惠政策接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeCardPolicyAsync")]
        public async Task<ApiResultDto> RemoveCardPolicyAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _CardPolicyService.RemoveCardPolicyAsync(sCardDBConn, sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的优惠政策id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除优惠政策异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除优惠政策异常");
            }
        }
        /// <summary>
        /// 批量删除优惠政策
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveCardPolicyAsync")]
        public async Task<ApiResultDto> BattchRemoveCardPolicyAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _CardPolicyService.BattchRemoveCardPolicyAsync(sCardDBConn, sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的优惠政策id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除优惠政策异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除优惠政策异常");
            }
        }
    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;
using CeCheng.SmartScenicSpot.Models.Consts;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 06 会员管理相关模块：会员卡设置
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class RegcardController : ControllerBase
    {
        private readonly ILogger<RegcardController> _LogService;
        private readonly IRegcardInterface _RegcardService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;
        // 会员卡数据库连接地址
        private string sCardDBConn = null;
        // 当前登陆这的营业点信息
        private LoginBusinessDataDto loginBusinessDataDto = null;


        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="RegcardService"></param>
        /// <param name="logService"></param>
        public RegcardController(IRegcardInterface RegcardService, ILogger<RegcardController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _RegcardService = RegcardService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
            sCardDBConn = CardDBConstConn.ConnectionCardDBStr;
            loginBusinessDataDto = new LoginBusinessDataDto();
            loginBusinessDataDto.sOutletNo = "01";
            loginBusinessDataDto.s_set_class = "1";
            loginBusinessDataDto.s_sys_date = DateTime.Now.ToString("yyyy-MM-dd");
        }

        /// <summary>
        /// 新增会员卡接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addRegcardAsync")]
        public async Task<ApiResultDto> AddRegcardAsync([FromBody] RegcardCreateDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && null != dto.regcardDto
                        && dto.regcardDto.s_member_info_id > 0
                        && !string.IsNullOrEmpty(dto.regcardDto.s_account_no)
                        && !string.IsNullOrEmpty(dto.regcardDto.s_card_no)
                        && !string.IsNullOrEmpty(dto.regcardDto.s_print_no)
                        && !string.IsNullOrEmpty(dto.regcardDto.s_code)
                        && !string.IsNullOrEmpty(dto.regcardDto.s_card_type)
                        && !string.IsNullOrEmpty(dto.regcardDto.PolicyCode)
                        && !string.IsNullOrEmpty(dto.regcardDto.s_sale)
                        && !string.IsNullOrEmpty(dto.regcardDto.s_sec_code)
                        && dto.regcardDto.s_forbin_date.HasValue
                        && dto.regcardDto.n_pay.HasValue 
                        && dto.regcardDto.n_charge.HasValue
                        )
                    {
                        DateTime fktime = DateTime.Now;
                        dto.regcardDto.s_set_date = fktime.ToString("yyyy-MM-dd");
                        dto.regcardDto.s_set_time = fktime.ToString("HH-mm-ss");
                        dto.regcardDto.s_set_work = sUserWorkNo;
                        dto.regcardDto.s_branch_id = i_branch_id;
                        dto.loginBusinessDataDto = loginBusinessDataDto;
                        dto.regcardDto.s_stat = "U";

                        var reuslt = await _RegcardService.AddRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "会员ID、会员卡账号、卡号、卡大小类编码、优惠政策编码、销售员、密码、有效期、付款金额、卡储金额数据不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增会员卡异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增会员卡异常");
            }
        }

        /// <summary>
        /// 修改会员卡接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editRegcardAsync")]
        public async Task<ApiResultDto> EditRegcardAsync([FromBody] RegcardDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        //&& dto.id > 0
                        //&& !string.IsNullOrEmpty(dto.s_no)
                        //&& !string.IsNullOrEmpty(dto.s_name)
                        //&& !string.IsNullOrEmpty(dto.is_active)
                        )
                    {
                        //dto.update_date = DateTime.Now;
                        //dto.update_user = sUserWorkNo;
                        //dto.s_branch_id = i_branch_id;

                        var reuslt = await _RegcardService.EditRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "会员卡编码、名称、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改会员卡异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改会员卡异常");
            }
        }

        /// <summary>
        /// 查询会员卡接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryRegcardAsync")]
        public async Task<ApiResultPageNationTDataDto<List<RegcardSearchResultDto>>> QueryRegcardAsync([FromBody] RegcardSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new RegcardSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _RegcardService.QueryRegcardAsync(sCardDBConn, dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<RegcardSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询会员卡异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<RegcardSearchResultDto>>.ToResultFail(msg: "查询会员卡异常");
            }
        }

        /// <summary>
        /// 会员卡充值接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("chongZhiRegcardAsync")]
        public async Task<ApiResultDto> ChongZhiRegcardAsync([FromBody] RegcardAddMoneyDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && null != dto.regcardDto
                        && dto.regcardDto.idno > 0
                        && !string.IsNullOrEmpty(dto.regcardDto.PolicyCode)
                        && null != dto.listPayMoneysDto
                        && 0 < dto.listPayMoneysDto.Count
                        && dto.regcardDto.n_pay.HasValue
                        )
                    {
                        DateTime fktime = DateTime.Now;
                        dto.regcardDto.s_set_date = fktime.ToString("yyyy-MM-dd");
                        dto.regcardDto.s_set_time = fktime.ToString("HH-mm-ss");
                        dto.regcardDto.s_set_work = sUserWorkNo;
                        dto.regcardDto.s_branch_id = i_branch_id;
                        dto.loginBusinessDataDto = loginBusinessDataDto;

                        var reuslt = await _RegcardService.ChongZhiRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "会员卡ID、优惠政策、充值金额不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=会员卡充值异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "会员卡充值异常");
            }
        }

        /// <summary>
        /// 修改会员卡密码
        /// </summary>
        /// <returns></returns>
        [HttpPost("modifyPwdRegcardAsync")]
        public async Task<ApiResultDto> ModifyPwdRegcardAsync([FromBody] RegcardModifyPwdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.idno > 0
                        && !string.IsNullOrEmpty(dto.sOldPwd)
                        && !string.IsNullOrEmpty(dto.sNewPwd)
                        )
                    {
                        var reuslt = await _RegcardService.ModifyPwdRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被修改的会员卡的id、原密码、新密码数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改会员卡密码异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改会员卡密码异常");
            }
        }

        /// <summary>
        /// 重置会员卡密码
        /// </summary>
        /// <returns></returns>
        [HttpPost("resetPwdRegcardAsync")]
        public async Task<ApiResultDto> ResetPwdRegcardAsync([FromBody] RegcardModifyPwdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.idno > 0)
                    {
                        var reuslt = await _RegcardService.ResetPwdRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被重置的会员卡的id数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=重置会员卡密码异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "重置会员卡密码异常");
            }
        }

        /// <summary>
        /// 会员卡状态修改（挂失、解挂、停用、启用这几个状态设置）
        /// </summary>
        /// <returns></returns>
        [HttpPost("modifyStateRegcardAsync")]
        public async Task<ApiResultDto> ModifyStateRegcardAsync([FromBody] RegcardStateModifyDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.idno > 0
                        && !string.IsNullOrEmpty(dto.s_Op_Mark)
                        )
                    {
                        dto.s_branch_id = i_branch_id;
                        dto.s_set_work = sUserWorkNo;
                        dto.loginBusinessDataDto = loginBusinessDataDto;

                        var reuslt = await _RegcardService.ModifyStateRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被操作的会员卡的id、操作标识数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=会员卡状态修改（挂失、解挂、停用、启用）异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "会员卡状态修改（挂失、解挂、停用、启用）异常");
            }
        }

        /// <summary>
        /// 会员卡取消发卡
        /// </summary>
        /// <returns></returns>
        [HttpPost("cancelRegcardAsync")]
        public async Task<ApiResultDto> CancelRegcardAsync([FromBody] RegcardCancelDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.idno > 0)
                    {
                        dto.s_branch_id = i_branch_id;
                        dto.s_set_work = sUserWorkNo;
                        dto.loginBusinessDataDto = loginBusinessDataDto;

                        var reuslt = await _RegcardService.CancelRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被操作的会员卡的id数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=会员卡取消发卡异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "会员卡取消发卡异常");
            }
        }

        /// <summary>
        /// 会员卡补卡
        /// </summary>
        /// <returns></returns>
        [HttpPost("buKaRegcardAsync")]
        public async Task<ApiResultDto> BuKaRegcardAsync([FromBody] RegcardBuKaDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.idno > 0
                        && !string.IsNullOrEmpty(dto.s_print_no)
                        && !string.IsNullOrEmpty(dto.s_card_no)
                        )
                    {
                        dto.s_branch_id = i_branch_id;
                        dto.s_set_work = sUserWorkNo;
                        dto.loginBusinessDataDto = loginBusinessDataDto;

                        var reuslt = await _RegcardService.BuKaRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "会员卡id、新物理卡号、印刷卡号数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=会员卡补卡异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "会员卡补卡异常");
            }
        }

        /// <summary>
        /// 会员卡回收
        /// </summary>
        /// <returns></returns>
        [HttpPost("huiShouRegcardAsync")]
        public async Task<ApiResultDto> HuiShouRegcardAsync([FromBody] RegcardHuiShouDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.idno > 0)
                    {
                        dto.s_branch_id = i_branch_id;
                        dto.s_set_work = sUserWorkNo;
                        dto.loginBusinessDataDto = loginBusinessDataDto;

                        var reuslt = await _RegcardService.HuiShouRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "会员卡id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=会员卡回收异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "会员卡回收异常");
            }
        }

        /// <summary>
        /// 会员卡退卡
        /// </summary>
        /// <returns></returns>
        [HttpPost("tuiKaRegcardAsync")]
        public async Task<ApiResultDto> TuiKaRegcardAsync([FromBody] RegcardTuiKaDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.idno > 0
                        && dto.n_money_back.HasValue
                        )
                    {
                        dto.s_branch_id = i_branch_id;
                        dto.s_set_work = sUserWorkNo;
                        dto.loginBusinessDataDto = loginBusinessDataDto;

                        var reuslt = await _RegcardService.TuiKaRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "会员卡id、退款金额不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=会员卡退卡异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "会员卡退卡异常");
            }
        }

        /// <summary>
        /// 会员卡转卡
        /// </summary>
        /// <returns></returns>
        [HttpPost("zhuanKaRegcardAsync")]
        public async Task<ApiResultDto> ZhuanKaRegcardAsync([FromBody] RegcardZhuanKaDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.idno_from > 0
                        && dto.idno_to > 0
                        && dto.n_money_out.HasValue
                        && dto.n_fen_out.HasValue
                        )
                    {
                        dto.s_branch_id = i_branch_id;
                        dto.s_set_work = sUserWorkNo;
                        dto.loginBusinessDataDto = loginBusinessDataDto;

                        var reuslt = await _RegcardService.ZhuanKaRegcardAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "转出卡id、转入卡id、转出金额、转出分数不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=会员卡转卡异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "会员卡转卡异常");
            }
        }
    }
}

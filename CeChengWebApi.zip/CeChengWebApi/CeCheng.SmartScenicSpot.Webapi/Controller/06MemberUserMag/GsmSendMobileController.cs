﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;
using System.Runtime.Intrinsics.X86;
using CeCheng.SmartScenicSpot.Models.Consts;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 06 会员管理相关模块：短信发送
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class GsmSendMobileController : ControllerBase
    {
        private readonly ILogger<GsmSendMobileController> _LogService;
        private readonly IGsmSendMobileInterface _GsmSendMobileService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;
        // 会员卡数据库连接地址
        private string sCardDBConn = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="GsmSendMobileService"></param>
        /// <param name="logService"></param>
        public GsmSendMobileController(IGsmSendMobileInterface GsmSendMobileService, ILogger<GsmSendMobileController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _GsmSendMobileService = GsmSendMobileService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
            sCardDBConn = CardDBConstConn.ConnectionCardDBStr;
        }

        /// <summary>
        /// 新增短信发送接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addGsmSendMobileAsync")]
        public async Task<ApiResultDto> AddGsmSendMobileAsync([FromBody] GsmSendMobileBattchSendDto dtos)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    bool bChecked = true;
                    List<GsmSendMobileEntity> listGsmSendMobileEntity = new List<GsmSendMobileEntity>();
                    if (null != dtos && 0 < dtos.s_mobile.Count && !string.IsNullOrEmpty(dtos.s_message))
                    {
                        for (int i = 0; i < dtos.s_mobile.Count; i++)
                        {
                            if (string.IsNullOrEmpty(dtos.s_mobile[i]))
                            {
                                bChecked = false;
                                break;
                            }
                            else
                            {
                                GsmSendMobileEntity objGsmSendMobileEntity = new GsmSendMobileEntity();
                                objGsmSendMobileEntity.s_branch_id = i_branch_id;
                                objGsmSendMobileEntity.s_flag = "N";
                                objGsmSendMobileEntity.n_cnt = 0;
                                objGsmSendMobileEntity.s_send_flag = "N";
                                objGsmSendMobileEntity.create_date = DateTime.Now;
                                objGsmSendMobileEntity.s_mobile = dtos.s_mobile[i];
                                objGsmSendMobileEntity.s_message = dtos.s_message;
                                objGsmSendMobileEntity.s_account_no = dtos.s_account_no[i];
                                listGsmSendMobileEntity.Add(objGsmSendMobileEntity);
                            }
                        }
                    }
                    if (null != dtos && 0 < dtos.s_mobile.Count && !string.IsNullOrEmpty(dtos.s_message) && bChecked)
                    {
                        var reuslt = await _GsmSendMobileService.AddGsmSendMobileAsync(sCardDBConn, listGsmSendMobileEntity);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "短信的手机号、内容不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增短信异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增短信异常");
            }
        }

        /// <summary>
        /// 查询短信发送接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryGsmSendMobileAsync")]
        public async Task<ApiResultPageNationTDataDto<List<GsmSendMobileSearchResultDto>>> QueryGsmSendMobileAsync([FromBody] GsmSendMobileSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new GsmSendMobileSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _GsmSendMobileService.QueryGsmSendMobileAsync(sCardDBConn, dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<GsmSendMobileSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询短信异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<GsmSendMobileSearchResultDto>>.ToResultFail(msg: "查询短信异常");
            }
        }

        /// <summary>
        /// 删除短信发送接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeGsmSendMobileAsync")]
        public async Task<ApiResultDto> RemoveGsmSendMobileAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _GsmSendMobileService.RemoveGsmSendMobileAsync(sCardDBConn, sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的短信id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除短信异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除短信异常");
            }
        }
        /// <summary>
        /// 批量删除短信发送
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveGsmSendMobileAsync")]
        public async Task<ApiResultDto> BattchRemoveGsmSendMobileAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _GsmSendMobileService.BattchRemoveGsmSendMobileAsync(sCardDBConn, sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的短信id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除短信异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除短信异常");
            }
        }
    }
}

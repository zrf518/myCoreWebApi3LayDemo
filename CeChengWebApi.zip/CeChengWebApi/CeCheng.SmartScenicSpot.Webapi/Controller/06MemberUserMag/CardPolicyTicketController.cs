﻿using CeCheng.SmartScenicSpot.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CeCheng.SmartScenicSpot.Models.Consts;
using CeCheng.SmartScenicSpot.Models;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 06 会员管理相关模块：优惠政策与微信劵关联设置
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class CardPolicyTicketController : ControllerBase
    {
        private readonly ILogger<CardPolicyTicketController> _LogService;
        private readonly ICardPolicyTicketInterface _chargeTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;
        // 会员卡数据库连接地址
        private string sCardDBConn = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="chargeTypeService"></param>
        /// <param name="logService"></param>
        /// <param name="httpContextAccessor"></param>
        public CardPolicyTicketController(ICardPolicyTicketInterface chargeTypeService, ILogger<CardPolicyTicketController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _chargeTypeService = chargeTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
            sCardDBConn = CardDBConstConn.ConnectionCardDBStr;
        }

        /// <summary>
        /// 新增优惠政策与微信劵关联设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addCardPolicyTicketAsync")]
        public async Task<ApiResultDto> AddCardPolicyTicketAsync([FromBody] CardPolicyTicketDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.PolicyCode)
                        && !string.IsNullOrEmpty(dto.TypeCode)
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.IsActive = "Y";

                        var reuslt = await _chargeTypeService.AddCardPolicyTicketAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "优惠政策编码、微信劵编码不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增优惠政策与微信劵关联设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增优惠政策与微信劵关联设置异常");
            }
        }

        /// <summary>
        /// 修改优惠政策与微信劵关联设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editCardPolicyTicketAsync")]
        public async Task<ApiResultDto> EditCardPolicyTicketAsync([FromBody] CardPolicyTicketDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.PolicyCode)
                        && !string.IsNullOrEmpty(dto.TypeCode)
                        && !string.IsNullOrEmpty(dto.IsActive))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _chargeTypeService.EditCardPolicyTicketAsync(sCardDBConn, dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "优惠政策编码、微信劵编码、是否有效不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改优惠政策与微信劵关联设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改优惠政策与微信劵关联设置异常");
            }
        }

        /// <summary>
        /// 查询优惠政策与微信劵关联设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryCardPolicyTicketAsync")]
        public async Task<ApiResultPageNationTDataDto<List<CardPolicyTicketSearchResultDto>>> QueryCardPolicyTicketAsync([FromBody] CardPolicyTicketSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new CardPolicyTicketSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;
                    var reuslt = await _chargeTypeService.QueryCardPolicyTicketAsync(sCardDBConn, dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<CardPolicyTicketSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询优惠政策与微信劵关联设置异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<CardPolicyTicketSearchResultDto>>.ToResultFail(msg: "查询优惠政策与微信劵关联设置异常");
            }
        }

        /// <summary>
        /// 删除优惠政策与微信劵关联设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeCardPolicyTicketAsync")]
        public async Task<ApiResultDto> RemoveCardPolicyTicketAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _chargeTypeService.RemoveCardPolicyTicketAsync(sCardDBConn, sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的优惠政策与微信劵关联设置id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除优惠政策与微信劵关联设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除优惠政策与微信劵关联设置异常");
            }
        }
        /// <summary>
        /// 批量删除优惠政策与微信劵关联设置
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveCardPolicyTicketAsync")]
        public async Task<ApiResultDto> BattchRemoveCardPolicyTicketAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _chargeTypeService.BattchRemoveCardPolicyTicketAsync(sCardDBConn, sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的优惠政策与微信劵关联设置id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除优惠政策与微信劵关联设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除优惠政策与微信劵关联设置异常");
            }
        }

    }
}

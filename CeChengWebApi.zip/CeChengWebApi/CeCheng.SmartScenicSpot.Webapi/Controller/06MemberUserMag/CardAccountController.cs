﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;
using CeCheng.SmartScenicSpot.Models.Consts;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 06 会员管理相关模块：会议卡卡务记录
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class CardAccountController : ControllerBase
    {
        private readonly ILogger<CardAccountController> _LogService;
        private readonly ICardAccountInterface _CardAccountService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;
        // 会员卡数据库连接地址
        private string sCardDBConn = null;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="CardAccountService"></param>
        /// <param name="logService"></param>
        public CardAccountController(ICardAccountInterface CardAccountService, ILogger<CardAccountController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _CardAccountService = CardAccountService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
            sCardDBConn = CardDBConstConn.ConnectionCardDBStr;
        }

        /// <summary>
        /// 查询会议卡卡务记录接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryCardAccountAsync")]
        public async Task<ApiResultPageNationTDataDto<List<CardAccountSearchResultDto>>> QueryCardAccountAsync([FromBody] CardAccountSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new CardAccountSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _CardAccountService.QueryCardAccountAsync(sCardDBConn, dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<CardAccountSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询会议卡卡务记录异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<CardAccountSearchResultDto>>.ToResultFail(msg: "查询会议卡卡务记录异常");
            }
        }
    }
}

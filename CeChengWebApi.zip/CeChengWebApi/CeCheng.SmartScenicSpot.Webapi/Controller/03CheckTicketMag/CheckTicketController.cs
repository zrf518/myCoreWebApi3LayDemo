﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 03检票管理 相关模块
    /// </summary>
    [Route("api/checkticket/[controller]")]
    [Area("checkticket")]
    [ApiController]
    [Authorize]
    public class CheckTicketController:ControllerBase
    {
    }
}

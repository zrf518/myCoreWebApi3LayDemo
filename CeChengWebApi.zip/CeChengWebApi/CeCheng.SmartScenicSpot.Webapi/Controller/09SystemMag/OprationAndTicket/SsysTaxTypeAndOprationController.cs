﻿using System;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models.Consts;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using System.Security.Cryptography;
using CeCheng.SmartScenicSpot.Commoms;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块 的发票，操作员相关
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SsysTaxTypeAndOprationController : ControllerBase
    {
        /// <summary>
        /// 发票，操作员的服务接口
        /// </summary>
        private readonly SsysTaxTypeAndOprationInterface _Service;
        private readonly ILogger<SsysTaxTypeAndOprationController> _log;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private UserTokenInfo _userTokenInfo { get; set; }
        /// <summary>
        ///  09 系统管理相关模块 的发票，操作员相关
        /// </summary>
        public SsysTaxTypeAndOprationController(SsysTaxTypeAndOprationInterface service, ILogger<SsysTaxTypeAndOprationController> log, IHttpContextAccessor httpContextAccessor)
        {
            _Service = service;
            _log = log;
            _httpContextAccessor = httpContextAccessor;
            _userTokenInfo = CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
        }

        #region 发票类型设置相关
        /// <summary>
        /// 发票类型设置 新增
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddSsysTaxTypeDto")]
        public async Task<ApiResultDto> AddSsysTaxType([FromBody] AddSsysTaxTypeDto dto)
        {
            try
            {
                if (dto.s_branch_id <= 0)
                    return ApiResultDto.ToResultFail(msg: ValidataConsts.branchid_must_input);
                if (dto.mcard != "Y" && dto.mcard != "N") 
                    return ApiResultDto.ToResultFail(msg: "参数错误，会员卡预收mcard， Y勾选；N不勾选");
                if (ModelState.IsValid)
                {
                    dto.create_date = DateTime.Now;
                    dto.create_user_wno = _userTokenInfo.UserWorkNo;
                    dto.is_active = IsActivityConstStr.Y;
                    dto.s_branch_id = _userTokenInfo.SBranchId;
                    return await _Service.AddSsysTaxType(dto);
                }
                else
                {
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                }
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message} \r\n");
                return ApiResultDto.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        /// <summary>
        /// 发票类型设置 编辑
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditSsysTaxType")]
        public async Task<ApiResultDto> EditSsysTaxType([FromBody] EditSsysTaxTypeDto dto)
        {
            try
            {
                if (dto.s_branch_id <= 0)
                    return ApiResultDto.ToResultFail(msg: ValidataConsts.branchid_must_input);
                if (dto.mcard != "Y" && dto.mcard != "N")
                    return ApiResultDto.ToResultFail(msg: "参数错误，会员卡预收mcard， Y勾选；N不勾选");
                if (ModelState.IsValid)
                {
                    dto.update_date = DateTime.Now;
                    dto.update_user_wno = _userTokenInfo.UserWorkNo;
                    return await _Service.EditSsysTaxType(dto);
                }
                else
                {
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                }
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message} \r\n");
                return ApiResultDto.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        /// <summary>
        /// 发票类型设置 查询
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QuerySsysTaxType")]
        public async Task<ApiResultPageNationTDataDto<List<EditSsysTaxTypeDto>>> QuerySsysTaxType([FromBody] QuerySsysTaxType dto)
        {
            try
            {
                return await _Service.QuerySsysTaxType(dto);
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message} \r\n");
                return ApiResultPageNationTDataDto<List<EditSsysTaxTypeDto>>.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        /// <summary>
        /// 发票类型设置 删除
        /// </summary>
        /// <param name="dto">一个id</param>
        /// <returns></returns>
        [HttpPost("RemoveSsysTaxType")]
        public async Task<ApiResultDto> RemoveSsysTaxType([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (dto.id <= 0)
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                return await _Service.RemoveSsysTaxType(dto.id);
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message} \r\n");
                return ApiResultDto.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        #endregion

        #region 发票大类设置相关
        /// <summary>
        /// 发票大类 新增
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddSsysBigTaxType")]
        public async Task<ApiResultDto> AddSsysBigTaxType([FromBody] AddSsysBigTaxTypeDto dto)
        {
            try
            {
                if (string.IsNullOrEmpty(dto.describe) || string.IsNullOrEmpty(dto.tax_big_type_code) || dto.s_branch_id <= 0)
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                dto.create_date = DateTime.Now;
                dto.create_user_wno = _userTokenInfo.UserWorkNo;
                dto.is_active = IsActivityConstStr.Y;
                dto.s_branch_id = _userTokenInfo.SBranchId;
                return await _Service.AddSsysBigTaxType(dto);
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message} \r\n");
                return ApiResultDto.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        /// <summary>
        ///  发票大类 编辑
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditSsysBigTaxType")]
        public async Task<ApiResultDto> EditSsysBigTaxType([FromBody] EditSsysBigTaxTypeDto dto)
        {
            try
            {
                if (string.IsNullOrEmpty(dto.describe) || string.IsNullOrEmpty(dto.tax_big_type_code) || dto.s_branch_id <= 0)
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);

                dto.update_date = DateTime.Now;
                dto.update_user_wno = _userTokenInfo.UserWorkNo;
                dto.s_branch_id = _userTokenInfo.SBranchId;
                return await _Service.EditSsysBigTaxType(dto);
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message} \r\n");
                return ApiResultDto.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        /// <summary>
        ///  发票大类 删除
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("RemoveSsysBigTaxType")]
        public async Task<ApiResultDto> RemoveSsysBigTaxType([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (dto.id <= 0)
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                return await _Service.RemoveSsysBigTaxType(dto.id);
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message} \r\n");
                return ApiResultDto.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        /// <summary>
        ///  发票大类 查询
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QuerySsysBigTaxType")]
        public async Task<ApiResultPageNationTDataDto<List<EditSsysBigTaxTypeDto>>> QuerySsysBigTaxType([FromBody] QuerySsysBigTaxType dto)
        {
            try
            {
                return await _Service.QuerySsysBigTaxType(dto);
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message} \r\n");
                return ApiResultPageNationTDataDto<List<EditSsysBigTaxTypeDto>>.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        #endregion


        #region 操作员班次相关
        /// <summary>
        /// 操作员班次 新增
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddSsysOperatorShift")]
        public async Task<ApiResultDto> AddSsysOperatorShift([FromBody] AddSsysOperatorShiftDto dto)
        {
            try
            {
                if (dto.shift_no <= 0 || string.IsNullOrEmpty(dto.shift_name) || dto.s_branch_id <= 0)
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                else
                {
                    dto.create_date = DateTime.Now;
                    dto.create_user_wno = _userTokenInfo.UserWorkNo;
                    dto.is_active = IsActivityConstStr.Y;
                    dto.s_branch_id = _userTokenInfo.SBranchId;
                    return await _Service.AddSsysOperatorShift(dto);
                }
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message}\r\n");
                return ApiResultDto.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        /// <summary>
        /// 操作员班次 编辑
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditSsysOperatorShift")]
        public async Task<ApiResultDto> EditSsysOperatorShift([FromBody] EditSsysOperatorShiftDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    dto.update_date = DateTime.Now;
                    dto.update_user_wno = _userTokenInfo.UserWorkNo;
                    dto.s_branch_id = _userTokenInfo.SBranchId;
                    return await _Service.EditSsysOperatorShift(dto);
                }
                else
                {
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                }
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message}\r\n");
                return ApiResultDto.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        /// <summary>
        /// 操作员班次 删除
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("RemoveSsysOperatorShift")]
        public async Task<ApiResultDto> RemoveSsysOperatorShift([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (dto.id <= 0)
                {
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                }
                return await _Service.RemoveSsysOperatorShift(dto.id);
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message}\r\n");
                return ApiResultDto.ToResultError(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        /// <summary>
        /// 操作员班次 查询
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QuerySsysOperatorShift")]
        public async Task<ApiResultPageNationTDataDto<List<EditSsysOperatorShiftDto>>> QuerySsysOperatorShift([FromBody] QuerySsysOpretorShiftDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    return await _Service.QuerySsysOperatorShift(dto);
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<EditSsysOperatorShiftDto>>.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                }
            }
            catch (Exception ex)
            {
                _log.LogError($"=={DateTime.Now}===发生异常==接口{HttpContext.Request.RouteValues["action"]}，原因：{ex.Message}\r\n");
                return ApiResultPageNationTDataDto<List<EditSsysOperatorShiftDto>>.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
            }
        }
        #endregion
    }
}

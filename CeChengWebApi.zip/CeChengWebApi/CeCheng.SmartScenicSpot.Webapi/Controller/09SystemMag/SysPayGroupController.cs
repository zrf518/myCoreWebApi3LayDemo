﻿using CeCheng.SmartScenicSpot.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CeCheng.SmartScenicSpot.Models.Consts;
using CeCheng.SmartScenicSpot.Models;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：支付组
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysPayGroupController : ControllerBase
    {
        private readonly ILogger<SysPayGroupController> _LogService;
        private readonly ISysPayGroupInterface _SysPayGroupService;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="SysPayGroupService"></param>
        /// <param name="httpContextAccessor"></param>
        /// <param name="logService"></param>
        public SysPayGroupController(ISysPayGroupInterface SysPayGroupService, ILogger<SysPayGroupController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _SysPayGroupService = SysPayGroupService;
            _LogService = logService;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增支付组接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addSysPayGroupAsync")]
        public async Task<ApiResultDto> AddSysPayGroupAsync([FromBody] SysPayGroupDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.code)
                        && !string.IsNullOrEmpty(dto.name)
                        && !string.IsNullOrEmpty(dto.s_type)
                          && !string.IsNullOrEmpty(dto.depart)
                        && dto.n_sort > 0)
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.IsActive = "Y";

                        var reuslt = await _SysPayGroupService.AddSysPayGroupAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "支付组编码、名称等数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增支付组异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增支付组异常");
            }
        }

        /// <summary>
        /// 修改支付组接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editSysPayGroupAsync")]
        public async Task<ApiResultDto> EditSysPayGroupAsync([FromBody] SysPayGroupDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.code)
                        && !string.IsNullOrEmpty(dto.name)
                        && !string.IsNullOrEmpty(dto.s_type)
                        && !string.IsNullOrEmpty(dto.depart)
                        && dto.n_sort > 0
                        && !string.IsNullOrEmpty(dto.IsActive))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _SysPayGroupService.EditSysPayGroupAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "支付组id、编码、名称、是否有效等数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改支付组异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改支付组异常");
            }
        }

        /// <summary>
        /// 查询支付组接口我们自己系统定义的支付code
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySysPayGroupAsync")]
        public async Task<ApiResultPageNationTDataDto<List<SysPayGroupDto>>> QuerySysPayGroupAsync([FromBody] SysPayGroupDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SysPayGroupDto();
                    }
                    dto.s_branch_id = i_branch_id;
                    var reuslt = await _SysPayGroupService.QuerySysPayGroupAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SysPayGroupDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询支付组异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SysPayGroupDto>>.ToResultFail(msg: "查询支付组异常");
            }
        }

        /// <summary>
        /// 获取我们支付类型，方便页面绑定下拉 支付操作方式的关系接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("GetPayGroupKvInfo")]
        public async Task<ApiResultDto> GetPayGroupKvInfo() => await _SysPayGroupService.GetPayGroup();

        /// <summary>
        /// 删除支付组接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeSysPayGroupAsync")]
        public async Task<ApiResultDto> RemoveSysPayGroupAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _SysPayGroupService.RemoveSysPayGroupAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的支付组id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除支付组异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除支付组异常");
            }
        }
        /// <summary>
        /// 批量删除支付组
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveSysPayGroupAsync")]
        public async Task<ApiResultDto> BattchRemoveSysPayGroupAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _SysPayGroupService.BattchRemoveSysPayGroupAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的支付组id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除支付组异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除支付组异常");
            }
        }

    }
}


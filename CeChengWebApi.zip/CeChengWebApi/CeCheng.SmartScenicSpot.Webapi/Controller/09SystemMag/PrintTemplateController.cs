﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：打印模板
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class PrintTemplateController : ControllerBase
    {
        private readonly ILogger<PrintTemplateController> _LogService;
        private readonly IPrintTemplateInterface _PrintTemplateService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="PrintTemplateService"></param>
        /// <param name="logService"></param>
        public PrintTemplateController(IPrintTemplateInterface PrintTemplateService, ILogger<PrintTemplateController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _PrintTemplateService = PrintTemplateService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增打印模板接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addPrintTemplateAsync")]
        public async Task<ApiResultDto> AddPrintTemplateAsync([FromBody] PrintTemplateDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.s_template_type_id.HasValue
                        && !string.IsNullOrEmpty(dto.s_template_code)
                        && !string.IsNullOrEmpty(dto.s_template_name))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _PrintTemplateService.AddPrintTemplateAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "打印模板编码、名称、类型id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增打印模板异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增打印模板异常");
            }
        }

        /// <summary>
        /// 修改打印模板接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editPrintTemplateAsync")]
        public async Task<ApiResultDto> EditPrintTemplateAsync([FromBody] PrintTemplateDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && dto.s_template_type_id.HasValue
                        && !string.IsNullOrEmpty(dto.s_template_code)
                        && !string.IsNullOrEmpty(dto.s_template_name)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _PrintTemplateService.EditPrintTemplateAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "打印模板编码、名称、类型id、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改打印模板异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改打印模板异常");
            }
        }

        /// <summary>
        /// 查询打印模板接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryPrintTemplateAsync")]
        public async Task<ApiResultPageNationTDataDto<List<PrintTemplateSearchResultDto>>> QueryPrintTemplateAsync([FromBody] PrintTemplateSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new PrintTemplateSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _PrintTemplateService.QueryPrintTemplateAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<PrintTemplateSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询打印模板异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<PrintTemplateSearchResultDto>>.ToResultFail(msg: "查询打印模板异常");
            }
        }

        /// <summary>
        /// 删除打印模板接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removePrintTemplateAsync")]
        public async Task<ApiResultDto> RemovePrintTemplateAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _PrintTemplateService.RemovePrintTemplateAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的打印模板id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除打印模板异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除打印模板异常");
            }
        }
        /// <summary>
        /// 批量删除打印模板
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemovePrintTemplateAsync")]
        public async Task<ApiResultDto> BattchRemovePrintTemplateAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _PrintTemplateService.BattchRemovePrintTemplateAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的打印模板id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除打印模板异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除打印模板异常");
            }
        }
    }
}

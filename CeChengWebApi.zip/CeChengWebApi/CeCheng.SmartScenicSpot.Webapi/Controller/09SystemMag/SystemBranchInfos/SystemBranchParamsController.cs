﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块  分店系统参数
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SystemBranchParamsController : ControllerBase
    {

        private readonly ISBranchSystemInfosInterface _iSBranchSystemInfosInterface;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="iSBranchSystemInfosInterface"></param>
        public SystemBranchParamsController(ISBranchSystemInfosInterface iSBranchSystemInfosInterface)
        {
            _iSBranchSystemInfosInterface = iSBranchSystemInfosInterface;
        }
        /// <summary>
        /// 新增和编辑  分店系统表 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddSystemBranchInfo")]
        public async Task<ApiResultDto> AddSystemBranchInfo([FromBody] SBranchSystemInfosAddDto dto)
        {
            if (ModelState.IsValid)
                return await _iSBranchSystemInfosInterface.AddSystemBranchInfo(dto);
            else
                return ApiResultDto.ToResultFail();
        }

        /// <summary>
        /// 编辑  分店系统表 修改时id必填
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditSystemBranchInfo")]
        public async Task<ApiResultDto> EditSystemBranchInfo([FromBody] SBranchSystemInfosEditDto dto)
        {
            if (ModelState.IsValid)
                return await _iSBranchSystemInfosInterface.EditSystemBranchInfo(dto);
            else
                return ApiResultDto.ToResultFail();
        }

        /// <summary>
        /// 查询分店系统表
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QuerySystemBranchInfo")]
        public async Task<ApiResultPageNationTDataDto<List<SBranchSystemEntity>>> QuerySystemBranchInfo([FromBody] SBranchSystemInfosQueryDto dto) => await _iSBranchSystemInfosInterface.QuerySystemBranchInfo(dto);
        /// <summary>
        /// 删除系统分店表 目前暂时不提供删除的功能
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("RemoveSystemBranchInfo")]
        public async Task<ApiResultDto> RemoveSystemBranchInfo([FromBody] QueryByIdDto dto)
        {

            //if (dto == null || dto.id <= 0)
            //    return ApiResultDto.ToResultFail();
            //return await _iSBranchSystemInfosInterface.RemoveSystemBranchInfo(dto);
            await Task.CompletedTask;
            return ApiResultDto.ToResultSuccess(msg: "目前暂时不提供删除的功能");
        }

    }
}

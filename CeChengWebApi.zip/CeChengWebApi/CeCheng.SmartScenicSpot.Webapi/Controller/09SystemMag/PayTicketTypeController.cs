﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：条码劵设置
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class PayTicketTypeController : ControllerBase
    {
        private readonly ILogger<PayTicketTypeController> _LogService;
        private readonly IPayTicketTypeInterface _PayTicketTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="PayTicketTypeService"></param>
        /// <param name="logService"></param>
        public PayTicketTypeController(IPayTicketTypeInterface PayTicketTypeService, ILogger<PayTicketTypeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _PayTicketTypeService = PayTicketTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增条码劵设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addPayTicketTypeAsync")]
        public async Task<ApiResultDto> AddPayTicketTypeAsync([FromBody] PayTicketTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.s_code)
                        && !string.IsNullOrEmpty(dto.s_describe)
                        && !string.IsNullOrEmpty(dto.is_cash))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _PayTicketTypeService.AddPayTicketTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "条码劵编码、名称、是否是现金券等字段值不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增条码劵设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增条码劵设置异常");
            }
        }

        /// <summary>
        /// 修改条码劵设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editPayTicketTypeAsync")]
        public async Task<ApiResultDto> EditPayTicketTypeAsync([FromBody] PayTicketTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.s_code)
                        && !string.IsNullOrEmpty(dto.s_describe)
                        && !string.IsNullOrEmpty(dto.is_cash)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _PayTicketTypeService.EditPayTicketTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "条码劵id、编码、名称、是否是现金券等字段值不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改条码劵设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改条码劵设置异常");
            }
        }

        /// <summary>
        /// 查询条码劵设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryPayTicketTypeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<PayTicketTypeSearchResultDto>>> QueryPayTicketTypeAsync([FromBody] PayTicketTypeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new PayTicketTypeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _PayTicketTypeService.QueryPayTicketTypeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<PayTicketTypeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询条码劵设置异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<PayTicketTypeSearchResultDto>>.ToResultFail(msg: "查询条码劵设置异常");
            }
        }

        /// <summary>
        /// 删除条码劵设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removePayTicketTypeAsync")]
        public async Task<ApiResultDto> RemovePayTicketTypeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _PayTicketTypeService.RemovePayTicketTypeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的条码劵设置id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除条码劵设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除条码劵设置异常");
            }
        }
        /// <summary>
        /// 批量删除条码劵设置
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemovePayTicketTypeAsync")]
        public async Task<ApiResultDto> BattchRemovePayTicketTypeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _PayTicketTypeService.BattchRemovePayTicketTypeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的条码劵设置id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除条码劵设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除条码劵设置异常");
            }
        }
    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：分店系统
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class BranchSystemController : ControllerBase
    {
        private readonly ILogger<BranchSystemController> _LogService;
        private readonly IBranchSystemInterface _BranchSystemService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="BranchSystemService"></param>
        /// <param name="logService"></param>
        public BranchSystemController(IBranchSystemInterface BranchSystemService, ILogger<BranchSystemController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _BranchSystemService = BranchSystemService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增分店系统接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addBranchSystemAsync")]
        public async Task<ApiResultDto> AddBranchSystemAsync([FromBody] BranchSystemDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.s_branch_id.HasValue
                        && !string.IsNullOrEmpty(dto.branch_no)
                        && !string.IsNullOrEmpty(dto.branch_name))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.is_active = "Y";

                        var reuslt = await _BranchSystemService.AddBranchSystemAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "分店id、编码、名称不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增分店系统异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增分店系统异常");
            }
        }

        /// <summary>
        /// 修改分店系统接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editBranchSystemAsync")]
        public async Task<ApiResultDto> EditBranchSystemAsync([FromBody] BranchSystemDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && dto.s_branch_id.HasValue
                        && !string.IsNullOrEmpty(dto.branch_no)
                        && !string.IsNullOrEmpty(dto.branch_name)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _BranchSystemService.EditBranchSystemAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "分店id、编码、名称、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改分店系统异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改分店系统异常");
            }
        }

        /// <summary>
        /// 查询分店系统接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryBranchSystemAsync")]
        public async Task<ApiResultPageNationTDataDto<List<BranchSystemSearchResultDto>>> QueryBranchSystemAsync([FromBody] BranchSystemSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new BranchSystemSearchParamDto();
                    }

                    var reuslt = await _BranchSystemService.QueryBranchSystemAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<BranchSystemSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询分店系统异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<BranchSystemSearchResultDto>>.ToResultFail(msg: "查询分店系统异常");
            }
        }

        /// <summary>
        /// 删除分店系统接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeBranchSystemAsync")]
        public async Task<ApiResultDto> RemoveBranchSystemAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _BranchSystemService.RemoveBranchSystemAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的分店系统id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除分店系统异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除分店系统异常");
            }
        }
        /// <summary>
        /// 批量删除分店系统
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveBranchSystemAsync")]
        public async Task<ApiResultDto> BattchRemoveBranchSystemAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _BranchSystemService.BattchRemoveBranchSystemAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的分店系统id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除分店系统异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除分店系统异常");
            }
        }
    }
}


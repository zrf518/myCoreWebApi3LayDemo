﻿using CeCheng.SmartScenicSpot.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CeCheng.SmartScenicSpot.Models.Consts;
using CeCheng.SmartScenicSpot.Models;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：支付参数
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysPayParamaterController : ControllerBase
    {
        private readonly ILogger<SysPayParamaterController> _LogService;
        private readonly ISysPayParamaterInterface _SysPayParamaterService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="SysPayParamaterService"></param>
        /// <param name="logService"></param>
        public SysPayParamaterController(ISysPayParamaterInterface SysPayParamaterService, ILogger<SysPayParamaterController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _SysPayParamaterService = SysPayParamaterService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增支付参数接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addSysPayParamaterAsync")]
        public async Task<ApiResultDto> AddSysPayParamaterAsync([FromBody] SysPayParamaterDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && !string.IsNullOrEmpty(dto.Name)
                        && null != dto.UpdateDate
                        && !string.IsNullOrEmpty(dto.s_group)
                        && !string.IsNullOrEmpty(dto.depart)
                        && !string.IsNullOrEmpty(dto.IsShow))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.IsActive = "Y";

                        var reuslt = await _SysPayParamaterService.AddSysPayParamaterAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "支付参数编码、分组、更新日期等参数信息不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增支付参数异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增支付参数异常");
            }
        }

        /// <summary>
        /// 修改支付参数接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editSysPayParamaterAsync")]
        public async Task<ApiResultDto> EditSysPayParamaterAsync([FromBody] SysPayParamaterDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.Name)
                        && null != dto.UpdateDate
                        && !string.IsNullOrEmpty(dto.IsActive)
                        && !string.IsNullOrEmpty(dto.s_group)
                        && !string.IsNullOrEmpty(dto.depart)
                        && !string.IsNullOrEmpty(dto.IsShow))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _SysPayParamaterService.EditSysPayParamaterAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "支付参数id、编码、分组、更新日期、是否有效等参数信息不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改支付参数异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改支付参数异常");
            }
        }

        /// <summary>
        /// 查询支付参数接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySysPayParamaterAsync")]
        public async Task<ApiResultPageNationTDataDto<List<SysPayParamaterDto>>> QuerySysPayParamaterAsync([FromBody] SysPayParamaterDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SysPayParamaterDto();
                    }
                    dto.s_branch_id = i_branch_id;
                    var reuslt = await _SysPayParamaterService.QuerySysPayParamaterAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SysPayParamaterDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询支付参数异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SysPayParamaterDto>>.ToResultFail(msg: "查询支付参数异常");
            }
        }

        /// <summary>
        /// 删除支付参数接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeSysPayParamaterAsync")]
        public async Task<ApiResultDto> RemoveSysPayParamaterAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _SysPayParamaterService.RemoveSysPayParamaterAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的支付参数id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除支付参数异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除支付参数异常");
            }
        }
        /// <summary>
        /// 批量删除支付参数
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveSysPayParamaterAsync")]
        public async Task<ApiResultDto> BattchRemoveSysPayParamaterAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _SysPayParamaterService.BattchRemoveSysPayParamaterAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的支付参数id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除支付参数异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除支付参数异常");
            }
        }

    }
}

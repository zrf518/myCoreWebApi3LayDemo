﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：出品说明
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysProduceController : ControllerBase
    {
        private readonly ILogger<SysProduceController> _LogService;
        private readonly ISysProduceInterface _SysProduceService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="SysProduceService"></param>
        /// <param name="logService"></param>
        public SysProduceController(ISysProduceInterface SysProduceService, ILogger<SysProduceController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _SysProduceService = SysProduceService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增出品说明接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addSysProduceAsync")]
        public async Task<ApiResultDto> AddSysProduceAsync([FromBody] SysProduceDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && !string.IsNullOrEmpty(dto.produce_code)
                        && !string.IsNullOrEmpty(dto.describe)
                        && dto.s_sys_produce_type_id.HasValue)
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _SysProduceService.AddSysProduceAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "出品大类id、出品说明编码、名称不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增出品说明异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增出品说明异常");
            }
        }

        /// <summary>
        /// 修改出品说明接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editSysProduceAsync")]
        public async Task<ApiResultDto> EditSysProduceAsync([FromBody] SysProduceDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.produce_code)
                        && !string.IsNullOrEmpty(dto.describe)
                        && dto.s_sys_produce_type_id.HasValue
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _SysProduceService.EditSysProduceAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "出品大类id、出品说明编码、名称、是否有效不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改出品说明异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改出品说明异常");
            }
        }

        /// <summary>
        /// 查询出品说明接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySysProduceAsync")]
        public async Task<ApiResultPageNationTDataDto<List<SysProduceSearchResultDto>>> QuerySysProduceAsync([FromBody] SysProduceSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SysProduceSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;
                    var reuslt = await _SysProduceService.QuerySysProduceAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SysProduceSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询出品说明异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SysProduceSearchResultDto>>.ToResultFail(msg: "查询出品说明异常");
            }
        }

        /// <summary>
        /// 删除出品说明接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeSysProduceAsync")]
        public async Task<ApiResultDto> RemoveSysProduceAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _SysProduceService.RemoveSysProduceAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的出品说明id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除出品说明异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除出品说明异常");
            }
        }
        /// <summary>
        /// 批量删除出品说明
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveSysProduceAsync")]
        public async Task<ApiResultDto> BattchRemoveSysProduceAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _SysProduceService.BattchRemoveSysProduceAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的出品说明id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除出品说明异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除出品说明异常");
            }
        }

    }
}

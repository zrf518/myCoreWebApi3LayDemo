﻿using CeCheng.SmartScenicSpot.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CeCheng.SmartScenicSpot.Models.Consts;
using CeCheng.SmartScenicSpot.Models;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：消费大类
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class ChargeTypeController : ControllerBase
    {
        private readonly ILogger<ChargeTypeController> _LogService;
        private readonly IChargeTypeInterface _chargeTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="chargeTypeService"></param>
        /// <param name="logService"></param>
        /// <param name="httpContextAccessor"></param>
        public ChargeTypeController(IChargeTypeInterface chargeTypeService, ILogger<ChargeTypeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _chargeTypeService = chargeTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增消费大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addChargeTypeAsync")]
        public async Task<ApiResultDto> AddChargeTypeAsync([FromBody] ChargeTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && !string.IsNullOrEmpty(dto.type_code) 
                        && !string.IsNullOrEmpty(dto.sale_consume_name)
                        && dto.type.HasValue
                        && dto.sort.HasValue)
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _chargeTypeService.AddChargeTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "消费大类编码、大类名称不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增消费大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增消费大类异常");
            }
        }

        /// <summary>
        /// 修改消费大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editChargeTypeAsync")]
        public async Task<ApiResultDto> EditChargeTypeAsync([FromBody] ChargeTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.type_code)
                        && !string.IsNullOrEmpty(dto.sale_consume_name)
                        && dto.type.HasValue
                        && dto.sort.HasValue
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _chargeTypeService.EditChargeTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "消费大类id、编码、名称、是否有效不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改消费大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改消费大类异常");
            }
        }

        /// <summary>
        /// 查询消费大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryChargeTypeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<ChargeTypeSearchResultDto>>> QueryChargeTypeAsync([FromBody] ChargeTypeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto) 
                    {
                        dto = new ChargeTypeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;
                    var reuslt = await _chargeTypeService.QueryChargeTypeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<ChargeTypeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询消费大类异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<ChargeTypeSearchResultDto>>.ToResultFail(msg: "查询消费大类异常");
            }
        }

        /// <summary>
        /// 删除消费大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeChargeTypeAsync")]
        public async Task<ApiResultDto> RemoveChargeTypeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _chargeTypeService.RemoveChargeTypeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的消费大类id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除消费大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除消费大类异常");
            }
        }
        /// <summary>
        /// 批量删除消费大类
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveChargeTypeAsync")]
        public async Task<ApiResultDto> BattchRemoveChargeTypeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _chargeTypeService.BattchRemoveChargeTypeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的消费大类id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除消费大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除消费大类异常");
            }
        }

    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：闸机类型
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class ZaJiInfoTypeController : ControllerBase
    {
        private readonly ILogger<ZaJiInfoTypeController> _LogService;
        private readonly IZaJiInfoTypeInterface _ZaJiInfoTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="ZaJiInfoTypeService"></param>
        /// <param name="logService"></param>
        public ZaJiInfoTypeController(IZaJiInfoTypeInterface ZaJiInfoTypeService, ILogger<ZaJiInfoTypeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _ZaJiInfoTypeService = ZaJiInfoTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增闸机类型接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addZaJiInfoTypeAsync")]
        public async Task<ApiResultDto> AddZaJiInfoTypeAsync([FromBody] ZaJiInfoTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.i_port.HasValue
                        && !string.IsNullOrEmpty(dto.code)
                        && !string.IsNullOrEmpty(dto.s_type))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _ZaJiInfoTypeService.AddZaJiInfoTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "闸机类型的编号、类型代码、方向值不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增闸机类型异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增闸机类型异常");
            }
        }

        /// <summary>
        /// 修改闸机类型接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editZaJiInfoTypeAsync")]
        public async Task<ApiResultDto> EditZaJiInfoTypeAsync([FromBody] ZaJiInfoTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && dto.i_port.HasValue
                        && !string.IsNullOrEmpty(dto.code)
                        && !string.IsNullOrEmpty(dto.s_type)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _ZaJiInfoTypeService.EditZaJiInfoTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "闸机类型的id、编号、类型代码、方向值不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改闸机类型异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改闸机类型异常");
            }
        }

        /// <summary>
        /// 查询闸机类型接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryZaJiInfoTypeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<ZaJiInfoTypeSearchResultDto>>> QueryZaJiInfoTypeAsync([FromBody] ZaJiInfoTypeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new ZaJiInfoTypeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _ZaJiInfoTypeService.QueryZaJiInfoTypeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<ZaJiInfoTypeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询闸机类型异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<ZaJiInfoTypeSearchResultDto>>.ToResultFail(msg: "查询闸机类型异常");
            }
        }

        /// <summary>
        /// 删除闸机类型接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeZaJiInfoTypeAsync")]
        public async Task<ApiResultDto> RemoveZaJiInfoTypeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _ZaJiInfoTypeService.RemoveZaJiInfoTypeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的闸机类型id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除闸机类型异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除闸机类型异常");
            }
        }
        /// <summary>
        /// 批量删除闸机类型
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveZaJiInfoTypeAsync")]
        public async Task<ApiResultDto> BattchRemoveZaJiInfoTypeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _ZaJiInfoTypeService.BattchRemoveZaJiInfoTypeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的闸机类型id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除闸机类型异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除闸机类型异常");
            }
        }
    }
}

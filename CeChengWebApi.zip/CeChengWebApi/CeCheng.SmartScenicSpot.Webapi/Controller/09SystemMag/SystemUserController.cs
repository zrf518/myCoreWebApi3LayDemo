﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using AutoMapper;
using System;
using CeCheng.SmartScenicSpot.Commoms;
using SqlSugar.IOC;
using System.Collections.Generic;
using SqlSugar;
using System.Linq;
using CeCheng.SmartScenicSpot.Models.Consts;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：用户CURD相关
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SystemUserController : ControllerBase
    {
        private readonly ISysUserInterface _userInterface;
        private readonly IMapper _mapper;
        private readonly ILogger<SystemUserController> _logger;
        private UserTokenInfo _userTokenInfo { get; set; }
        private readonly IHttpContextAccessor _httpContextAccessor;
        /// <summary>
        /// 
        /// </summary>
        public SystemUserController(ILogger<SystemUserController> logger, ISysUserInterface userInterface, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _userInterface = userInterface;
            _mapper = mapper;
            _httpContextAccessor = httpContextAccessor;
            _userTokenInfo = CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
        }

        /// <summary>
        /// 新增用户
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddSysUserAsync")]
        public async Task<ApiResultDto> AddSysUserAsync([FromBody] SysUserDto dto)
        {
            try
            {
                if (string.IsNullOrEmpty(dto.user_work_no) || string.IsNullOrEmpty(dto.user_name) || dto.roleId <= 0 || string.IsNullOrEmpty(dto.password) || dto.s_branch_id <= 0 || dto.s_site_id <= 0)
                    return ApiResultDto.ToResultFail("用户的工号,姓名,角色,分店id,营业点id等必填");
                var userinfo = CeChengTokenHelper.GetTockenUserInfo(HttpContext);
                dto.create_date = DateTime.Now;
                dto.create_user_wno = userinfo.UserWorkNo;
                dto.sys_type = 0;
                dto.is_active = IsActivityConstStr.Y;//由页面来决定
                var entityDto = _mapper.Map<SysUserDto, SysUserEntity>(dto);
                return await _userInterface.AddSysUserAsync(entityDto);
            }
            catch (Exception ex)
            {
                _logger.LogError($"新增用户异常=={DateTime.Now},原因：{ex.Message}");
                return ApiResultDto.ToResultError();
            }
        }

        /// <summary>
        /// 编辑用户
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditSysUserAsync")]
        public async Task<ApiResultDto> EditSysUserAsync([FromBody] EditSysUserDto dto)
        {
            try
            {
                if (string.IsNullOrEmpty(dto.user_work_no) || string.IsNullOrEmpty(dto.user_name) || dto.roleId <= 0 || dto.s_branch_id <= 0 || dto.s_site_id <= 0)
                    return ApiResultDto.ToResultFail(msg: "用户的工号,姓名,角色,分店id,营业点id等必填");
                var userinfo = CeChengTokenHelper.GetTockenUserInfo(HttpContext);
                var obj = _mapper.Map<EditSysUserDto, SysUserEntity>(dto);
                var flag = await _userInterface.EditSysUserAsync(obj);
                return flag;
            }
            catch (Exception ex)
            {
                _logger.LogError($"修改用户异常=={DateTime.Now},原因：{ex.Message}");
                return ApiResultDto.ToResultError();
            }
        }

        /// <summary>
        /// 查询用户
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryUsersAsync")]
        public async Task<ApiResultPageNationTDataDto<List<QueryUserGetListDataDto>>> QuerySysUserAsync([FromBody] QueryUserDto dto)
        {
            try
            {
                var objs = await _userInterface.QuerySysUserAsync(dto.id, dto.UserWorkNo, dto.UserName, dto.Telephone, dto.PageIndex, dto.PageSize);
                int totalCount = objs.Item1;
                var listdata = objs.Item2;
                //var userlist = new List<QueryUserGetListDataDto>();
                //if (listdata != null && listdata.Any())
                //    userlist = _mapper.Map<List<SysUserEntity>, List<QueryUserGetListDataDto>>(listdata);
                return ApiResultPageNationTDataDto<List<QueryUserGetListDataDto>>.ToResultSuccess(data: listdata, PageSize: dto.PageSize, PageIndex: dto.PageIndex, TotalRow: totalCount);
            }
            catch (Exception ex)
            {
                _logger.LogError($"查询用户异常=={DateTime.Now},原因：" + ex.Message);
                return ApiResultPageNationTDataDto<List<QueryUserGetListDataDto>>.ToResultError(data: null, PageSize: dto.PageSize, PageIndex: dto.PageIndex, TotalRow: 0);
            }
        }
        /// <summary>
        /// 软删除用户
        /// </summary>
        /// <param name="dto">一个id</param>
        /// <returns></returns>
        [HttpPost("RemoveUserAsync")]
        public Task<ApiResultDto> RemoveSysUserAsync([FromBody] QueryByIdDto dto)
        {
            return _userInterface.RemoveSysUserAsync(dto.id);
        }

        /// <summary>
        /// 获取登陆者的信息
        /// </summary>
        /// <returns></returns>
        [HttpPost("GetLoginUserInfo")]
        public async Task<ApiResultDto<UserTokenInfo>> GetLoginUserInfo()
        {
            //try
            //{
                var getobj = _userTokenInfo;
                var uinfo = CeChengTokenHelper.GetTockenUserInfo(HttpContext);
                await Task.CompletedTask;
                //var tokenStr = CeChengJwtToken.GetTockenString(base.HttpContext);
                //UserTokenInfo info = await _testService.GetLoginUserInfo(tokenStr);
                return ApiResultDto<UserTokenInfo>.ToResultSuccess(data: uinfo);
            //}
            //catch (Exception ex)
            //{
            //    return ApiResultDto<UserTokenInfo>.ToResultFail(ex.Message);
            //}
        }

        #region  管理员修改用户密码  重置自己的密码
        /// <summary>
        /// 重置自己的密码
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditUserPwdForselfAsync")]
        public async Task<ApiResultDto> EditUserPwdForselfAsync(EditUserPwdByselfDto dto)
        {
            try
            {
                if (string.IsNullOrEmpty(dto.new_password) || string.IsNullOrEmpty(dto.original_password) || string.IsNullOrEmpty(dto.new_password2))
                    return ApiResultDto.ToResultFail(msg: "密码参数必填");
                if (!dto.new_password.Equals(dto.new_password2))
                    return ApiResultDto.ToResultFail(msg: "新密码需要一致");
                return await _userInterface.EditUserPwdForselfAsync(dto);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// 管理员修改用户密码
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditUserPwdByMagAsync")]
        public async Task<ApiResultDto> EditUserPwdByMagAsync(ResertUserPasswordDto dto)
        {
            if (dto.id <= 0)
                return ApiResultDto.ToResultFail(msg: "要修的的用户id必填");
            return await _userInterface.EditUserPwdByMagAsync(dto);
        }
        #endregion
    }
}

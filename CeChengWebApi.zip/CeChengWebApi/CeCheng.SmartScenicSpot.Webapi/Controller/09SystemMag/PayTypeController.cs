﻿using CeCheng.SmartScenicSpot.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CeCheng.SmartScenicSpot.Models.Consts;
using CeCheng.SmartScenicSpot.Models;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：付款方式大类
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class PayTypeController : ControllerBase
    {
        private readonly ILogger<PayTypeController> _LogService;
        private readonly IPayTypeInterface _PayTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="PayTypeService"></param>
        /// <param name="logService"></param>
        public PayTypeController(IPayTypeInterface PayTypeService, ILogger<PayTypeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _PayTypeService = PayTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增付款方式大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addPayTypeAsync")]
        [AllowAnonymous]
        public async Task<ApiResultDto> AddPayTypeAsync([FromBody] PayTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.pay_type_code)
                        && !string.IsNullOrEmpty(dto.pay_type_name)
                        && !string.IsNullOrEmpty(dto.desc)
                        && !string.IsNullOrEmpty(dto.third_party_code)
                        && dto.sort > 0)
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _PayTypeService.AddPayTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "付款方式大类编码、名称、描述等都不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增付款方式大类异常,原因：{ex.Message}");

                return ApiResultDto.ToResultFail(msg: "新增付款方式大类异常");
            }
        }

        /// <summary>
        /// 修改付款方式大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editPayTypeAsync")]
        [AllowAnonymous]
        public async Task<ApiResultDto> EditPayTypeAsync([FromBody] PayTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.pay_type_code)
                        && !string.IsNullOrEmpty(dto.pay_type_name)
                        && !string.IsNullOrEmpty(dto.desc)
                        && !string.IsNullOrEmpty(dto.third_party_code)
                        && dto.sort > 0
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _PayTypeService.EditPayTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "付款方式大类id、编码、名称、描述、是否有效等都不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改付款方式大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改付款方式大类异常");
            }
        }

        /// <summary>
        /// 查询付款方式大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryPayTypeAsync")]
        [AllowAnonymous]
        public async Task<ApiResultPageNationTDataDto<List<PayTypeDto>>> QueryPayTypeAsync([FromBody] PayTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new PayTypeDto();
                    }
                    dto.s_branch_id = i_branch_id;
                    var reuslt = await _PayTypeService.QueryPayTypeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<PayTypeDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询付款方式大类异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<PayTypeDto>>.ToResultFail(msg: "查询付款方式大类异常");
            }
        }

        /// <summary>
        /// 删除付款方式大类接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removePayTypeAsync")]
        [AllowAnonymous]
        public async Task<ApiResultDto> RemovePayTypeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _PayTypeService.RemovePayTypeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的付款方式大类id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除付款方式大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除付款方式大类异常");
            }
        }
        /// <summary>
        /// 批量删除付款方式大类
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemovePayTypeAsync")]
        [AllowAnonymous]
        public async Task<ApiResultDto> BattchRemovePayTypeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _PayTypeService.BattchRemovePayTypeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的付款方式大类id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除付款方式大类异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除付款方式大类异常");
            }
        }

    }
}


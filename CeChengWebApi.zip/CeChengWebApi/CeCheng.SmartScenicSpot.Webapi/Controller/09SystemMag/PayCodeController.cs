﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：付款方式
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class PayCodeController : ControllerBase
    {
        private readonly ILogger<PayCodeController> _LogService;
        private readonly IPayCodeInterface _PayCodeService;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="PayCodeService"></param>
        /// <param name="logService"></param>
        /// <param name="httpContextAccessor"></param>
        public PayCodeController(IPayCodeInterface PayCodeService, ILogger<PayCodeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _PayCodeService = PayCodeService;
            _LogService = logService;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增付款方式接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addPayCodeAsync")]
        public async Task<ApiResultDto> AddPayCodeAsync([FromBody] PayCodeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.pay_code)
                        && !string.IsNullOrEmpty(dto.describe)
                        && dto.exchange.HasValue
                        && !string.IsNullOrEmpty(dto.pay_charge)
                        && !string.IsNullOrEmpty(dto.currency)
                        && !string.IsNullOrEmpty(dto.app_pay_type)
                        && !string.IsNullOrEmpty(dto.point_pay_type)
                        && !string.IsNullOrEmpty(dto.member_card_type)
                        && !string.IsNullOrEmpty(dto.money_count)
                        && !string.IsNullOrEmpty(dto.business_income)
                        && dto.cc_proctype_id != null && dto.cc_proctype_id > 0
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _PayCodeService.AddPayCodeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "付款方式大类ID、付款方式编码、名称、汇率、付小费、币别、(APP支付、 积分支付、 会员卡支付、 财务统计 、 营业收入，操作方式)设置值不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增付款方式异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增付款方式异常");
            }
        }

        /// <summary>
        /// 修改付款方式接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editPayCodeAsync")]
        public async Task<ApiResultDto> EditPayCodeAsync([FromBody] PayCodeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.pay_code)
                        && !string.IsNullOrEmpty(dto.describe)
                        && dto.exchange.HasValue
                        && !string.IsNullOrEmpty(dto.pay_charge)
                        && !string.IsNullOrEmpty(dto.currency)
                        && !string.IsNullOrEmpty(dto.is_active)
                        && !string.IsNullOrEmpty(dto.app_pay_type)
                        && !string.IsNullOrEmpty(dto.point_pay_type)
                        && !string.IsNullOrEmpty(dto.member_card_type)
                        && !string.IsNullOrEmpty(dto.money_count)
                        && !string.IsNullOrEmpty(dto.business_income)
                        && dto.cc_proctype_id != null && dto.cc_proctype_id > 0
                        )
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _PayCodeService.EditPayCodeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "付款方式大类ID、付款方式编码、名称、汇率、付小费、币别、是否有效、(APP支付、 积分支付、 会员卡支付、 财务统计 、 营业收入,操作方式)设置值不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改付款方式异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改付款方式异常");
            }
        }

        /// <summary>
        /// 查询付款方式接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryPayCodeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<PayCodeSearchResultDto>>> QueryPayCodeAsync([FromBody] PayCodeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new PayCodeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _PayCodeService.QueryPayCodeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<PayCodeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询付款方式异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<PayCodeSearchResultDto>>.ToResultFail(msg: "查询付款方式异常");
            }
        }

        /// <summary>
        /// 删除付款方式接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removePayCodeAsync")]
        public async Task<ApiResultDto> RemovePayCodeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _PayCodeService.RemovePayCodeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的付款方式id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除付款方式异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除付款方式异常");
            }
        }
        /// <summary>
        /// 批量删除付款方式
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemovePayCodeAsync")]
        public async Task<ApiResultDto> BattchRemovePayCodeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _PayCodeService.BattchRemovePayCodeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的付款方式id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除付款方式异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除付款方式异常");
            }
        }


        /// <summary>
        /// =====查询获取分店配置的支付类型信息  
        /// </summary>
        /// <param name="dto">allpaycode: true 该分店全部支付数据，false该分店移动支付</param>
        /// <returns></returns>
        [HttpPost("QueryBarnchPayCodeInfos")]
        public async Task<ApiResultDto<List<QueryBranchPayCodeInfosToPage>>> QueryBarnchPayCodeInfos([FromBody] QueryBranchPayCodeInfoDto dto)
        {
            if (dto == null || dto.s_branch_id <= 0)
                return ApiResultDto<List<QueryBranchPayCodeInfosToPage>>.ToResultFail("分店ID必填或者数据格式错误");
            return await _PayCodeService.QueryBarnchPayCodeInfos(dto);
        }

    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;
using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Services;
using Newtonsoft.Json;
using Pay;
using Alipay.AopSdk.Core.Domain;
using Newtonsoft.Json.Linq;
using System.Drawing;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：扫码付款记录
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SMPayLogController : ControllerBase
    {
        private readonly ILogger<SMPayLogController> _LogService;
        private readonly ISMPayLogInterface _SMPayLogService;
        private readonly ISysPayGroupInterface _SysPayGroupInterface;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;
        private string outLetNo = string.Empty;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="SMPayLogService"></param>
        /// <param name="logService"></param>
        public SMPayLogController(ISMPayLogInterface SMPayLogService, ILogger<SMPayLogController> logService, IHttpContextAccessor httpContextAccessor, ISysPayGroupInterface SysPayGroupInterface)
        {
            _SMPayLogService = SMPayLogService;
            _SysPayGroupInterface = SysPayGroupInterface;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
                outLetNo = CeChengBusinessFunctionHelper.GetOutNameByOutIdByTb(_userinfo.outletId);
            }
        }

        /// <summary>
        /// 查询扫码付款记录接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySMPayLogAsync")]
        public async Task<ApiResultPageNationTDataDto<List<SMPayLogSearchResultDto>>> QuerySMPayLogAsync([FromBody] SMPayLogSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SMPayLogSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _SMPayLogService.QuerySMPayLogAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SMPayLogSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询扫码付款记录异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SMPayLogSearchResultDto>>.ToResultFail(msg: "查询扫码付款记录异常");
            }
        }

        /// <summary>
        /// 扫码付款接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("Pay")]
        public ApiResultDto<UserSMPayResultDto> Pay([FromBody] UserSMPayParamDto dto)
        {
            UserSMPayResultDto dtoUserSMPayResult = new UserSMPayResultDto();
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto 
                        || false == dto.Pay_amount.HasValue
                        || string.IsNullOrEmpty(dto.Pay_Code)
                        || string.IsNullOrEmpty(dto.sUserPayQrcode)
                        )
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "付款金额、付款方式编码、付款二维码不能为空");
                    }


                    #region 根据支付方式编码，获取支付组的信息
                    PayCodeDto dtoPayCode = new PayCodeDto();
                    dtoPayCode.pay_code = dto.Pay_Code;
                    dtoPayCode.s_branch_id = i_branch_id;

                    List<ZongHeSysPayGroupDto> listPayGroup = _SysPayGroupInterface.QuerySysPayGroupByPayCode(dtoPayCode);
                    if (null == listPayGroup || 0 == listPayGroup.Count || string.IsNullOrEmpty(listPayGroup[0].depart))
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "找不到对应的支付组信息");
                    }
                    
                    // 从数据库里获取扫码支付平台的对接参数
                    string s_group = string.IsNullOrEmpty(listPayGroup[0].pay_code_group) ? "default" : listPayGroup[0].pay_code_group;
                    string depart = listPayGroup[0].depart;
                    SMPayPlatformParamDto dtoSMPayPfParam = CeChengBusinessFunctionHelper.GetSMPayPlatformParamFormDb(i_branch_id.Value, s_group, depart);
                    #endregion 


                    // 获取策城付款流水号
                    string out_trade_no = CeChengBusinessFunctionHelper.GetSysNextNoByTb(NextNumberIdentityEnum.loc_trade_no);
                    // 当前时间
                    var now_time = DateTime.Now;


                    #region 保存支付日志
                    SMPayLogEntity dtoSMPayLog = new SMPayLogEntity();
                    dtoSMPayLog.s_flag = listPayGroup[0].code;
                    dtoSMPayLog.s_message = "";
                    dtoSMPayLog.s_account_no = dto.s_account_no;
                    dtoSMPayLog.out_trade_no = out_trade_no;
                    dtoSMPayLog.trade_no = out_trade_no;
                    dtoSMPayLog.Pay_workno = sUserWorkNo;
                    dtoSMPayLog.Refund_workno = "";
                    dtoSMPayLog.Pay_amount = dto.Pay_amount;
                    dtoSMPayLog.IsActive = "C";
                    dtoSMPayLog.Create_date = now_time;
                    dtoSMPayLog.Refund_date = null;
                    dtoSMPayLog.cardtype = dto.cardtype;
                    dtoSMPayLog.Phoneno = dto.Phoneno;
                    dtoSMPayLog.s_name = dto.s_name;
                    dtoSMPayLog.WeChatOpenID = dto.WeChatOpenID;
                    dtoSMPayLog.PolicyCode = dto.PolicyCode;
                    dtoSMPayLog.s_type = dto.s_type;
                    dtoSMPayLog.Refund_Amount = 0;
                    dtoSMPayLog.s_group = s_group;
                    dtoSMPayLog.OrderType = dto.OrderType;
                    dtoSMPayLog.Tips_amount = dto.Tips_amount;
                    dtoSMPayLog.Extend = dto.Extend;
                    dtoSMPayLog.PayType = listPayGroup[0].code;
                    dtoSMPayLog.Check_date = now_time;
                    dtoSMPayLog.BuyerID = dto.BuyerID;
                    dtoSMPayLog.BuyerName = dto.BuyerName;
                    dtoSMPayLog.s_OtaOrderno = dto.s_OtaOrderno;
                    dtoSMPayLog.OutletNo = dto.OutletNo;
                    dtoSMPayLog.terminal_code = dto.terminal_code;
                    dtoSMPayLog.istakefood = dto.istakefood;
                    dtoSMPayLog.d_autotime = dto.d_autotime;
                    dtoSMPayLog.n_autonum = dto.n_autonum;
                    dtoSMPayLog.s_branch_id = i_branch_id;
                    dtoSMPayLog.pay_code = dto.Pay_Code;
                    dtoSMPayLog.depart = depart;

                    ApiResultDto resApiResultDtoInsert = _SMPayLogService.AddSMPayLog(dtoSMPayLog);
                    if (resApiResultDtoInsert.Succeed == false)
                    {
                        string sMsg = "";
                        if (!string.IsNullOrEmpty(resApiResultDtoInsert.Msg))
                        {
                            sMsg = "：" + resApiResultDtoInsert.Msg;
                        }
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "支付组信息保存失败" + sMsg);
                    }
                    #endregion


                    #region  拼装付款接口需要的付款参数字符串
                    PayParamJson objPayParamJson = new PayParamJson();
                    // 平台对接参数赋值
                    objPayParamJson.apiurl = dtoSMPayPfParam.apiurl;
                    objPayParamJson.merchant_no = dtoSMPayPfParam.merchant_no;
                    objPayParamJson.terminal_id = dtoSMPayPfParam.terminal_id;
                    objPayParamJson.access_token = dtoSMPayPfParam.access_token;
                    objPayParamJson.sub_mch_id = dtoSMPayPfParam.sub_mch_id;
                    objPayParamJson.sub_mch_key = dtoSMPayPfParam.sub_mch_key;
                    objPayParamJson.appid = dtoSMPayPfParam.appid;
                    objPayParamJson.sub_appid = dtoSMPayPfParam.sub_appid;
                    // 用户交易数据赋值
                    objPayParamJson.out_trade_no = out_trade_no;
                    objPayParamJson.trade_no = out_trade_no;
                    objPayParamJson.fee = "" + (int)(dto.Pay_amount.Value * 100); // 转成分
                    objPayParamJson.goodName = "";
                    objPayParamJson.authCode = dto.sUserPayQrcode;
                    objPayParamJson.pay_time = "";
                    objPayParamJson.total_fee = "0";
                    objPayParamJson.refund_fee = "0";

                    string sJsonDataParamPay = JsonConvert.SerializeObject(objPayParamJson);
                    #endregion

                    // 执行付款
                    string sRetJson = string.Empty;
                    PayApi apiPay = new PayApi();
                    string sResPay = apiPay.Pay(listPayGroup[0].code, sJsonDataParamPay, ref sRetJson);

                    // 构造返回信息
                    dtoUserSMPayResult.sPayResultJson = sRetJson;
                    dtoUserSMPayResult.sPayResultFun = sResPay;
                    dtoUserSMPayResult.out_trade_no = out_trade_no;

                    if (sResPay.ToLower().StartsWith("true|")) // 付款成功
                    {
                        // 更新付款记录表
                        SMPayLogEntity dtoSMPayLogUpdate = (SMPayLogEntity)resApiResultDtoInsert.Data;

                        dtoSMPayLogUpdate.s_message = sRetJson;
                        dtoSMPayLogUpdate.IsActive = "Y";
                        dtoSMPayLogUpdate.Check_date = DateTime.Now;
                        // 支付平台返回来的交易流水号
                        JObject jsonRetPay = (JObject)JsonConvert.DeserializeObject(sRetJson);
                        dtoSMPayLogUpdate.trade_no = jsonRetPay["trade_no"].ToString();

                        ApiResultDto resApiResultDtoUpdate = _SMPayLogService.EditSMPayLog(dtoSMPayLogUpdate);
                        if (resApiResultDtoUpdate.Succeed == false)
                        {
                            throw new Exception($"out_trade_no为{out_trade_no}的表SM_Pay_log记录数据，付款已成功，但是数据更新不成功，返回信息分别是：ref returnjson 值为{sRetJson}，pay()返回{sResPay}");
                        }
                        dtoUserSMPayResult.sPayResultState = "true";
                    }
                    else if (sResPay.ToLower().StartsWith("query|")) // 付款中，需要用户自己另外调用查询接口去查询结果
                    {
                        dtoUserSMPayResult.sPayResultState = "query";
                    }
                    else // 付款失败
                    {
                        dtoUserSMPayResult.sPayResultState = "false";
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "支付接口返回失败");
                    }

                    return ApiResultDto<UserSMPayResultDto>.ToResultSuccess(data: dtoUserSMPayResult);
                }
                else
                {
                    return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "参数验证不通过：ModelState.IsValid值为false");
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=付款异常,原因：{ex.Message}");
                if (ex.Message.ToString().StartsWith("out_trade_no为"))
                {
                    return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "付款异常：" + ex.Message.ToString());
                }
                return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "付款异常");
            }
        }

        /// <summary>
        /// 扫码付款结果查询（在支付平台还没返回结果前可以定时调用此结果去查询，一般是2分钟以内都可以查）
        /// </summary>
        /// <returns></returns>
        [HttpPost("Query")]
        public ApiResultDto<UserSMPayResultDto> Query([FromBody] UserSMPayParamDto dto)
        {
            UserSMPayResultDto dtoUserSMPayResult = new UserSMPayResultDto();
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto || string.IsNullOrEmpty(dto.out_trade_no))
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "策城付款流水号不能为空");
                    }

                    #region 从支付日志里查出原交易数据信息
                    SMPayLogDto dtoSMPayLog = new SMPayLogDto();
                    dtoSMPayLog.out_trade_no = dto.out_trade_no;
                    dtoSMPayLog.s_branch_id = i_branch_id;

                    ApiResultDto resApiResultDtoQry = _SMPayLogService.QuerySMPayLogByOutTradeNo(dtoSMPayLog);
                    if (null == resApiResultDtoQry || resApiResultDtoQry.Succeed == false)
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "付款查询失败，交易记录不存在");
                    }

                    SMPayLogEntity dtoHisSMPayLog = (SMPayLogEntity)resApiResultDtoQry.Data;
                    if (dtoHisSMPayLog.IsActive == "Y") // 数据库里已标识付款成功的，就返回付款成功的信息
                    {
                        dtoUserSMPayResult.sPayResultState = "true";
                        dtoUserSMPayResult.sPayResultJson = dtoHisSMPayLog.s_message;
                        dtoUserSMPayResult.sPayResultFun = "true|...";
                        return ApiResultDto<UserSMPayResultDto>.ToResultSuccess(data: dtoUserSMPayResult);
                    }
                    #endregion

                    #region  根据支付方式编码，获取支付组的信息
                    // 从数据库里获取扫码支付平台的对接参数
                    string s_group = string.IsNullOrEmpty(dtoHisSMPayLog.s_group) || 0 == dtoHisSMPayLog.s_group.Length ? "default" : dtoHisSMPayLog.s_group;
                    string depart = dtoHisSMPayLog.depart;
                    if (string.IsNullOrEmpty(s_group) || string.IsNullOrEmpty(depart))
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "找不到对应的支付组信息");
                    }
                    SMPayPlatformParamDto dtoSMPayPfParam = CeChengBusinessFunctionHelper.GetSMPayPlatformParamFormDb(i_branch_id.Value, s_group, depart);
                    #endregion 

                    #region  拼装付款接口需要的付款参数字符串
                    PayParamJson objPayParamJson = new PayParamJson();
                    // 平台对接参数赋值
                    objPayParamJson.apiurl = dtoSMPayPfParam.apiurl;
                    objPayParamJson.merchant_no = dtoSMPayPfParam.merchant_no;
                    objPayParamJson.terminal_id = dtoSMPayPfParam.terminal_id;
                    objPayParamJson.access_token = dtoSMPayPfParam.access_token;
                    objPayParamJson.sub_mch_id = dtoSMPayPfParam.sub_mch_id;
                    objPayParamJson.sub_mch_key = dtoSMPayPfParam.sub_mch_key;
                    objPayParamJson.appid = dtoSMPayPfParam.appid;
                    objPayParamJson.sub_appid = dtoSMPayPfParam.sub_appid;

                    // 用户交易数据赋值
                    objPayParamJson.out_trade_no = dto.out_trade_no;
                    objPayParamJson.trade_no = "";
                    objPayParamJson.fee = "" + (int)(dtoHisSMPayLog.Pay_amount.Value * 100);
                    objPayParamJson.goodName = "";
                    objPayParamJson.authCode = "";
                    objPayParamJson.pay_time = "";
                    objPayParamJson.total_fee = "0";
                    objPayParamJson.refund_fee = "0";

                    string sJsonDataParamPay = JsonConvert.SerializeObject(objPayParamJson);
                    #endregion

                    // 执行付款
                    string sRetJson = string.Empty;
                    PayApi apiPay = new PayApi();
                    string sResPay = apiPay.Query(dtoHisSMPayLog.s_flag, sJsonDataParamPay, ref sRetJson);

                    // 构造返回信息
                    dtoUserSMPayResult.sPayResultJson = sRetJson;
                    dtoUserSMPayResult.sPayResultFun = sResPay;
                    dtoUserSMPayResult.out_trade_no = dto.out_trade_no;
                    if (sResPay.ToLower().StartsWith("true|")) // 付款成功
                    {
                        // 更新付款记录表
                        dtoHisSMPayLog.s_message = sRetJson;
                        dtoHisSMPayLog.IsActive = "Y";
                        dtoHisSMPayLog.Check_date = DateTime.Now;
                        // 支付平台返回来的交易流水号
                        JObject jsonRetPay = (JObject)JsonConvert.DeserializeObject(sRetJson);
                        dtoHisSMPayLog.trade_no = jsonRetPay["trade_no"].ToString();

                        ApiResultDto resApiResultDtoUpdate = _SMPayLogService.EditSMPayLog(dtoHisSMPayLog);
                        if (resApiResultDtoUpdate.Succeed == false)
                        {
                            throw new Exception($"out_trade_no为{dto.out_trade_no}的表SM_Pay_log记录数据，付款已成功，但是数据更新不成功，返回信息分别是：ref returnjson 值为{sRetJson}，pay()返回{sResPay}");
                        }
                        dtoUserSMPayResult.sPayResultState = "true";
                    }
                    else if (sResPay.ToLower().StartsWith("query|")) // 付款中，需要用户自己另外再继续调用查询接口去查询结果
                    {
                        dtoUserSMPayResult.sPayResultState = "query";
                    }
                    else // 付款失败
                    {
                        dtoUserSMPayResult.sPayResultState = "false";
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "支付接口返回失败");
                    }

                    return ApiResultDto<UserSMPayResultDto>.ToResultSuccess(data: dtoUserSMPayResult);
                }
                else
                {
                    return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "参数验证不通过：ModelState.IsValid值为false");
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=付款查询异常,原因：{ex.Message}");
                if (ex.Message.ToString().StartsWith("out_trade_no为"))
                {
                    return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "付款查询异常：" + ex.Message.ToString());
                }
                return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "付款查询异常");
            }
        }

        /// <summary>
        /// 扫码付款成功后的退款
        /// </summary>
        /// <returns></returns>
        [HttpPost("Refund")]
        public ApiResultDto<UserSMPayResultDto> Refund([FromBody] UserSMPayParamDto dto)
        {
            UserSMPayResultDto dtoUserSMPayResult = new UserSMPayResultDto();
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto || string.IsNullOrEmpty(dto.out_trade_no) || false == dto.Refund_Amount.HasValue)
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "策城付款流水号、退款金额不能为空不能为空");
                    }

                    #region 从支付日志里查出原交易数据信息
                    SMPayLogDto dtoSMPayLog = new SMPayLogDto();
                    dtoSMPayLog.out_trade_no = dto.out_trade_no;
                    dtoSMPayLog.s_branch_id = i_branch_id;

                    // 查出原来的付款记录
                    ApiResultDto resApiResultDtoQry = _SMPayLogService.QuerySMPayLogByOutTradeNo(dtoSMPayLog);
                    if (null == resApiResultDtoQry || resApiResultDtoQry.Succeed == false)
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "退款失败：交易记录不存在");
                    }
                    
                    SMPayLogEntity dtoHisSMPayLog = (SMPayLogEntity)resApiResultDtoQry.Data;
                    if (dtoHisSMPayLog.IsActive != "Y")
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "退款失败：原付款不成功");
                    }
                    // 查出已退款金额，以便判断是否超额
                    decimal nSumRefund = 0;
                    ApiResultDto<List<SMPayLogEntity>> resListRefundQry = _SMPayLogService.QuerySMRefundLogByOutTradeNo(dtoSMPayLog);
                    if (null != resListRefundQry && null != resListRefundQry.Data && 0 < ((List<SMPayLogEntity>)resListRefundQry.Data).Count)
                    {
                        List<SMPayLogEntity> listRefuQry = (List<SMPayLogEntity>)resListRefundQry.Data;
                        foreach (SMPayLogEntity objRf  in listRefuQry)
                        {
                            nSumRefund += objRf.Refund_Amount;
                        }
                    }
                    if ((nSumRefund + dto.Refund_Amount.Value) > dtoHisSMPayLog.Pay_amount.Value)
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "退款失败：可退余额不足");
                    }
                    #endregion

                    #region 保存退款信息
                    decimal nHisPay = dtoHisSMPayLog.Pay_amount.Value;
                    dtoHisSMPayLog.id = 0;
                    dtoHisSMPayLog.Pay_amount = 0;
                    dtoHisSMPayLog.Pay_workno = "";
                    dtoHisSMPayLog.IsActive = "C";
                    dtoHisSMPayLog.Refund_date = DateTime.Now;
                    dtoHisSMPayLog.Refund_Amount = dto.Refund_Amount.Value;
                    dtoHisSMPayLog.Refund_workno = sUserWorkNo;
                    dtoHisSMPayLog.Create_date = DateTime.Now;
                    dtoHisSMPayLog.Check_date = DateTime.Now;
                    dtoHisSMPayLog.OutletNo = outLetNo;

                    ApiResultDto resApiResultDtoInsert = _SMPayLogService.AddSMPayLog(dtoHisSMPayLog);
                    if (resApiResultDtoInsert.Succeed == false)
                    {
                        string sMsg = "";
                        if (!string.IsNullOrEmpty(resApiResultDtoInsert.Msg))
                        {
                            sMsg = "：" + resApiResultDtoInsert.Msg;
                        }
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "退款信息保存失败" + sMsg);
                    }
                    // 更新付款记录表
                    dtoHisSMPayLog = (SMPayLogEntity)resApiResultDtoInsert.Data;
                    #endregion

                    #region 根据支付方式编码，获取支付组的信息
                    // 从数据库里获取扫码支付平台的对接参数
                    string s_group = string.IsNullOrEmpty(dtoHisSMPayLog.s_group) || 0 == dtoHisSMPayLog.s_group.Length ? "default" : dtoHisSMPayLog.s_group;
                    string depart = dtoHisSMPayLog.depart;
                    if (string.IsNullOrEmpty(s_group) || string.IsNullOrEmpty(depart))
                    {
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "找不到对应的支付组信息");
                    }
                    SMPayPlatformParamDto dtoSMPayPfParam = CeChengBusinessFunctionHelper.GetSMPayPlatformParamFormDb(i_branch_id.Value, s_group, depart);
                    #endregion 

                    #region  拼装付款接口需要的付款参数字符串
                    PayParamJson objPayParamJson = new PayParamJson();
                    // 平台对接参数赋值
                    objPayParamJson.apiurl = dtoSMPayPfParam.apiurl;
                    objPayParamJson.merchant_no = dtoSMPayPfParam.merchant_no;
                    objPayParamJson.terminal_id = dtoSMPayPfParam.terminal_id;
                    objPayParamJson.access_token = dtoSMPayPfParam.access_token;
                    objPayParamJson.sub_mch_id = dtoSMPayPfParam.sub_mch_id;
                    objPayParamJson.sub_mch_key = dtoSMPayPfParam.sub_mch_key;
                    objPayParamJson.appid = dtoSMPayPfParam.appid;
                    objPayParamJson.sub_appid = dtoSMPayPfParam.sub_appid;

                    // 用户交易数据赋值
                    objPayParamJson.out_trade_no = dto.out_trade_no;
                    objPayParamJson.trade_no = dtoHisSMPayLog.trade_no;
                    objPayParamJson.fee = "0";
                    objPayParamJson.goodName = "";
                    objPayParamJson.authCode = "";
                    objPayParamJson.pay_time = "";
                    objPayParamJson.total_fee = "" + (int)(nHisPay * 100);
                    objPayParamJson.refund_fee = "" + (int)(dtoHisSMPayLog.Refund_Amount * 100);

                    string sJsonDataParamPay = JsonConvert.SerializeObject(objPayParamJson);
                    #endregion

                    // 执行付款
                    string sRetJson = string.Empty;
                    PayApi apiPay = new PayApi();
                    string sResPay = apiPay.Refund(dtoHisSMPayLog.s_flag, sJsonDataParamPay, ref sRetJson);

                    // 构造返回信息
                    dtoUserSMPayResult.sPayResultJson = sRetJson;
                    dtoUserSMPayResult.sPayResultFun = sResPay;
                    dtoUserSMPayResult.out_trade_no = dto.out_trade_no;

                    if (sResPay.ToLower().StartsWith("true|")) // 退款成功
                    {
                        // 更新付款记录表
                        dtoHisSMPayLog.s_message = sRetJson;
                        dtoHisSMPayLog.IsActive = "Y";

                        ApiResultDto resApiResultDtoUpdate = _SMPayLogService.EditSMPayLog(dtoHisSMPayLog);
                        if (resApiResultDtoUpdate.Succeed == false)
                        {
                            throw new Exception($"out_trade_no为{dto.out_trade_no}的表SM_Pay_log记录数据，退款已成功，但是数据更新不成功，返回信息分别是：ref returnjson 值为{sRetJson}，pay()返回{sResPay}");
                        }
                        dtoUserSMPayResult.sPayResultState = "true";
                    }
                    else // 退款失败
                    {
                        dtoUserSMPayResult.sPayResultState = "false";
                        return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: AppDomain.CurrentDomain.BaseDirectory + "支付接口返回失败");
                    }

                    return ApiResultDto<UserSMPayResultDto>.ToResultSuccess(data: dtoUserSMPayResult);
                }
                else
                {
                    return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "参数验证不通过：ModelState.IsValid值为false");
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=退款异常,原因：{ex.Message}");
                if (ex.Message.ToString().StartsWith("out_trade_no为"))
                { 
                    return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "退款异常：" + ex.Message.ToString());
                }
                return ApiResultDto<UserSMPayResultDto>.ToResultFail(data: dtoUserSMPayResult, msg: "退款异常");
            }
        }
    }
}

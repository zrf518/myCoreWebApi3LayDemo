﻿using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using System.Collections.Generic;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：日志相关
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysLogInfoController : CeChengBaseController
    {
        private readonly ISysUserInterface _sysUserInterface;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <param name="sysUserInterface"></param>
        public SysLogInfoController(IHttpContextAccessor httpContextAccessor, ISysUserInterface sysUserInterface) : base(httpContextAccessor)
        {
            _sysUserInterface = sysUserInterface;
        }

        /// <summary>
        /// 获取日志信息
        /// </summary>
        /// <returns></returns>
        /// <param name="dto"></param>
        [HttpPost("getsyslogs")]
        public async Task<ApiResultPageNationTDataDto<List<SysLogReturnDto>>> GetLogsInfoAsync([FromBody] SysLogInputDto dto)
        {
            if (dto.create_date_start==null||dto.create_date_end==null)
                return ApiResultPageNationTDataDto<List<SysLogReturnDto>>.ToResultFail(msg:"日志的开始与结束日期必填");
            var user = base._UserTokenInfo;
            return await _sysUserInterface.GetLogsInfoAsync(user, dto);
        }
    }
}

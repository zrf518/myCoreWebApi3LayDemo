﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：销售员
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysSalerController : ControllerBase
    {
        private readonly ILogger<SysSalerController> _LogService;
        private readonly ISysSalerInterface _SysSalerService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="SysSalerService"></param>
        /// <param name="logService"></param>
        public SysSalerController(ISysSalerInterface SysSalerService, ILogger<SysSalerController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _SysSalerService = SysSalerService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增销售员接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addSysSalerAsync")]
        public async Task<ApiResultDto> AddSysSalerAsync([FromBody] SysSalerDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.sale_work_no)
                        && !string.IsNullOrEmpty(dto.sale_name))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _SysSalerService.AddSysSalerAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "销售员编号、姓名不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增销售员异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增销售员异常");
            }
        }

        /// <summary>
        /// 修改销售员接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editSysSalerAsync")]
        public async Task<ApiResultDto> EditSysSalerAsync([FromBody] SysSalerDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.sale_work_no)
                        && !string.IsNullOrEmpty(dto.sale_name)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _SysSalerService.EditSysSalerAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "销售员编号、姓名、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改销售员异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改销售员异常");
            }
        }

        /// <summary>
        /// 查询销售员接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySysSalerAsync")]
        public async Task<ApiResultPageNationTDataDto<List<SysSalerSearchResultDto>>> QuerySysSalerAsync([FromBody] SysSalerSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SysSalerSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _SysSalerService.QuerySysSalerAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SysSalerSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询销售员异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SysSalerSearchResultDto>>.ToResultFail(msg: "查询销售员异常");
            }
        }

        /// <summary>
        /// 删除销售员接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeSysSalerAsync")]
        public async Task<ApiResultDto> RemoveSysSalerAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _SysSalerService.RemoveSysSalerAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的销售员id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除销售员异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除销售员异常");
            }
        }
        /// <summary>
        /// 批量删除销售员
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveSysSalerAsync")]
        public async Task<ApiResultDto> BattchRemoveSysSalerAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _SysSalerService.BattchRemoveSysSalerAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的销售员id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除销售员异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除销售员异常");
            }
        }
    }
}


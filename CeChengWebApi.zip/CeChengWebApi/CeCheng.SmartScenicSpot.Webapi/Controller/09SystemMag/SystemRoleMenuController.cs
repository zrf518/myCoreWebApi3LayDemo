﻿using AutoMapper;
using CeCheng.SmartScenicSpot.Commoms;
using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using CeCheng.SmartScenicSpot.Models.Consts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统菜单角色CURD 基础数据相关模块
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SystemRoleMenuController : ControllerBase
    {
        private readonly IMenuRoleInterface _menuInterface;
        private readonly IMapper _mapper;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="menuInterface"></param>
        /// <param name="mapper"></param>
        public SystemRoleMenuController(IMenuRoleInterface menuInterface, IMapper mapper)
        {
            _menuInterface = menuInterface;
            _mapper = mapper;
        }

        #region 菜单相关
        /// <summary>
        /// 新增菜单 或者新增按钮 ，共用接口
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddMenu")]
        public async Task<ApiResultDto> AddMenu([FromBody] AddMenuDto dto)
        {
            try
            {
                if (string.IsNullOrEmpty(dto.menu_name))
                    return ApiResultDto.ToResultFail(msg: "名称必填");
                if (dto.s_branch_id <= 0)
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.TenantIdNoData);
                if (dto.menu_level_type != 1 && dto.menu_level_type != 2 && dto.menu_level_type != 3 && dto.menu_level_type != -1)
                    return ApiResultDto.ToResultFail(msg: "菜单按钮类型下拉必填");
                if (dto.menu_level_type == 1)
                {
                    dto.parent_id = 0;
                    dto.menu_type = "M";
                }
                else if (dto.menu_level_type != 1)
                {
                    if (dto.parent_id <= 0)
                        return ApiResultDto.ToResultFail(msg: "ParentId参数错误，请重新选择赋值");
                    dto.menu_type = dto.menu_level_type == 2 || dto.menu_level_type == 3 ? "C" : "F";
                }
                var editObj = _mapper.Map<AddMenuDto, SsysMenuEntity>(dto);
                bool flag = await _menuInterface.AddMenu(editObj);
                return flag ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            catch (Exception)
            {
                return ApiResultDto.ToResultError();
            }

        }
        /// <summary>
        /// 编辑菜单
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditMenu")]
        public async Task<ApiResultDto> EditMenu([FromBody] EditMenuDto dto)
        {
            try
            {
                if (dto.menu_id <= 0 || string.IsNullOrEmpty(dto.menu_name))
                    return ApiResultDto.ToResultFail(msg: "菜单或按钮id，名称必填");
                if (dto.s_branch_id <= 0)
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.TenantIdNoData);
                if (dto.menu_level_type != 1 && dto.menu_level_type != 2 && dto.menu_level_type != 3 && dto.menu_level_type != -1)
                    return ApiResultDto.ToResultFail(msg: "菜单按钮类型必填");
                if (dto.menu_level_type == 1)
                {
                    dto.parent_id = 0;
                    dto.menu_type = "M";
                }
                else if (dto.menu_level_type != 1)
                {
                    if (dto.parent_id <= 0)
                        return ApiResultDto.ToResultFail(msg: "ParentId参数错误，请重新选择赋值");
                    dto.menu_type = dto.menu_level_type == 2 || dto.menu_level_type == 3 ? "C" : "F";
                }
                var editObj = _mapper.Map<EditMenuDto, SsysMenuEntity>(dto);
                bool flag = await _menuInterface.EditMenu(editObj);
                return flag ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            catch (Exception)
            {
                return ApiResultDto.ToResultError();
            }

        }
        /// <summary>
        /// 删除菜单
        /// </summary>
        /// <param name="dto.MenuId">MenuId 菜单id， true:删除的为一级菜单(子菜单将会被一起删除），false:二级菜单</param>
        /// <returns></returns>
        [HttpPost("RemoveMenu")]
        public async Task<ApiResultDto> RemoveMenu([FromBody] GetRolesDto dto)
        {
            try
            {
                if (dto.menuId <= 0)
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                var flag = await _menuInterface.RemoveMenu(dto.menuId, dto.isParentMenu);
                return flag ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            catch (Exception ex)
            {
                return ApiResultDto.ToResultError(msg: ex.Message);
            }

        }
        /// <summary>
        /// 获取一个平面的查询列表 菜单数据  该接口根据目前页面ui 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("GetMenus")]
        public async Task<ApiResultPageNationTDataDto<List<EditMenuDto>>> GetMenus([FromBody] GetMenuListDataByTenantId dto)
        {
            try
            {
                var _userTokenInfo = CeChengTokenHelper.GetTockenUserInfo(HttpContext);
                int systype = _userTokenInfo.SysType;
                if (dto.s_branch_id <= 0 && systype <= 0)
                    return ApiResultPageNationTDataDto<List<EditMenuDto>>.ToResultFail(msg: ValidataConsts.branchid_must_input);
                var listData = await _menuInterface.GetMenus(dto);
                return listData;
            }
            catch (Exception)
            {
                return ApiResultPageNationTDataDto<List<EditMenuDto>>.ToResultError();
            }

        }
        #endregion

        #region 角色相关
        /// <summary>
        /// 新增角色
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddRole")]
        public async Task<ApiResultDto> AddRole([FromBody] AddRoleDto dto)
        {
            try
            {
                if (string.IsNullOrEmpty(dto.role_name))
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                if (dto.s_branch_id <= 0)
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.TenantIdNoData);
                var editObj = _mapper.Map<AddRoleDto, SsysRolesEntity>(dto);
                bool flag = await _menuInterface.AddRole(editObj);
                return flag ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            catch (Exception ex)
            {
                return ApiResultDto.ToResultError();
            }

        }
        /// <summary>
        /// 编辑角色
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditRole")]
        public async Task<ApiResultDto> EditRole([FromBody] EditRoleDto dto)
        {

            try
            {
                if (dto.id <= 0)
                    return ApiResultDto.ToResultFail(msg: "角色id必填");
                if (dto.s_branch_id <= 0)
                    return ApiResultDto.ToResultFail(msg: ValidataConsts.branchid_must_input);
                var editObj = _mapper.Map<EditRoleDto, SsysRolesEntity>(dto);
                bool flag = await _menuInterface.EditRole(editObj);
                return flag ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            catch (Exception)
            {
                return ApiResultDto.ToResultError();
            }

        }
        /// <summary>
        /// 删除角色
        /// </summary>
        /// <param name="dto.id">角色主键</param>
        /// <returns></returns>
        [HttpPost("RemoveRole")]
        public async Task<ApiResultDto> RemoveRole([FromBody] QueryByIdAndBranchIdDto dto)
        {
            try
            {
                if (dto.id <= 0)//||TenantId<=0 根据主键来删除，可以不用租户id
                    return ApiResultDto.ToResultFail(msg: SuccessFailConstStr.ValidaDataNotFonud);
                var flag = await _menuInterface.RemoveRole(dto.id, dto.s_branch_id);
                return flag ? ApiResultDto.ToResultSuccess() : ApiResultDto.ToResultFail();
            }
            catch (Exception ex)
            {
                return ApiResultDto.ToResultError(msg:ex.Message);
            }

        }
        /// <summary>
        /// 获取一个平面的查询列表 角色数据
        /// </summary>
        /// <param name="dto.queryName">角色名称</param>
        /// <returns></returns>
        [HttpPost("GetRoles")]
        public async Task<ApiResultPageNationTDataDto<List<EditRoleDto>>> GetRoles([FromBody] QueryOneStrDtoWithPageNation dto)
        {
            try
            {
                var listData = await _menuInterface.GetRoles(dto);
                return listData;
            }
            catch (Exception)
            {
                return ApiResultPageNationTDataDto<List<EditRoleDto>>.ToResultError();
            }
        }
        #endregion


        #region 角色菜单关系相关
        ///<summary>
        ///获取角色对应的菜单树形结构的数据
        ///<param name="dto.onlyThisRoleMenusData">true:当前的角色对应的菜单数据；false:全部菜单</param>
        ///</summary>
        ///<returns></returns>
        [HttpPost("GetRoleMenusDatasAsync")]
        public async Task<ApiResultDto<List<RoleMenuRelation>>> GetRoleMenusRelations([FromBody] QueryRomeMeunDto dto)
        {
            try
            {
                if (dto.roleId <= 0 || dto.s_branch_id <= 0)
                    return ApiResultDto<List<RoleMenuRelation>>.ToResultFail("角色id和租户id必填");
                var listData = await _menuInterface.GetRoleMenusRelations(dto.s_branch_id, dto.roleId, dto.onlyThisRoleMenusData);
                return ApiResultDto<List<RoleMenuRelation>>.ToResultSuccess(data: listData);
            }
            catch (Exception)
            {
                return ApiResultDto<List<RoleMenuRelation>>.ToResultError();
            }

        }
        /// <summary>
        /// 新增或编辑角色对应的菜单关系数据 
        /// </summary>
        /// <returns></returns>
        [HttpPost("AddRoleMenus")]
        public async Task<ApiResultDto> AddRoleMenus([FromBody] AddRoleMenuDto dto)
        {
            try
            {
                if (dto.MenuId == null || !dto.MenuId.Any() || dto.s_branch_id <= 0||dto.RoleId<=0)
                    return ApiResultDto.ToResultFail(msg: "菜单id与角色id，分店id必填");
                int totalCount = await _menuInterface.AddRoleMenus(dto);
                return totalCount > 0 ? ApiResultDto.ToResultSuccess(data: totalCount, msg: $"成功绑定角色对应的菜单") : ApiResultDto.ToResultFail();
            }
            catch (Exception)
            {
                return ApiResultDto.ToResultError();
            }
        }

        #endregion
    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;
using CeCheng.SmartScenicSpot.Commoms;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：流水号
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class GetNextNumController : ControllerBase
    {
        private readonly ILogger<GetNextNumController> _LogService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="logService"></param>
        public GetNextNumController(ILogger<GetNextNumController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 获取指定流水号接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("getNextNumAsync")]
        public async Task<ApiResultDto> GetNextNumAsync([FromBody] GetNextNumDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if(null == dto || string.IsNullOrEmpty(dto.sNextNumMark))
                    {
                        return ApiResultDto.ToResultFail(msg: "流水号标识不能为空");
                    }

                    bool isHaveMark = false;
                    NextNumberIdentityEnum objNextMark = NextNumberIdentityEnum.loc_trade_no;
                    if (dto.sNextNumMark == NextNumberIdentityEnum.loc_trade_no.ToString())
                    {
                        objNextMark = NextNumberIdentityEnum.loc_trade_no;
                        isHaveMark = true;
                    }
                    else if (dto.sNextNumMark == NextNumberIdentityEnum.ticket_sell_no.ToString())
                    {
                        objNextMark = NextNumberIdentityEnum.ticket_sell_no;
                        isHaveMark = true;
                    }
                    else if (dto.sNextNumMark == NextNumberIdentityEnum.vir_card_no.ToString())
                    {
                        objNextMark = NextNumberIdentityEnum.vir_card_no;
                        isHaveMark = true;
                    }
                    else if (dto.sNextNumMark == NextNumberIdentityEnum.vir_cardaccount_no.ToString())
                    {
                        objNextMark = NextNumberIdentityEnum.vir_cardaccount_no;
                        isHaveMark = true;
                    }
                    else if (dto.sNextNumMark == NextNumberIdentityEnum.vir_print_no.ToString())
                    {
                        objNextMark = NextNumberIdentityEnum.vir_print_no;
                        isHaveMark = true;
                    }
                    if (isHaveMark == false)
                    {
                        if (null == dto || string.IsNullOrEmpty(dto.sNextNumMark))
                        {
                            return ApiResultDto.ToResultFail(msg: "流水号标识不正确");
                        }
                    }

                    var next_no = await CeChengBusinessFunctionHelper.GetSysNextNo(objNextMark);
                    return ApiResultDto.ToResultSuccess(data: next_no);
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增分店异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增分店异常");
            }
        }

    }
}


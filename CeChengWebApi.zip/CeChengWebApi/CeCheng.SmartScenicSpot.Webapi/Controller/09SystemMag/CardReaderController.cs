﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：读卡器设置
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class CardReaderController : ControllerBase
    {
        private readonly ILogger<CardReaderController> _LogService;
        private readonly ICardReaderInterface _CardReaderService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="CardReaderService"></param>
        /// <param name="logService"></param>
        public CardReaderController(ICardReaderInterface CardReaderService, ILogger<CardReaderController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _CardReaderService = CardReaderService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增读卡器设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addCardReaderAsync")]
        public async Task<ApiResultDto> AddCardReaderAsync([FromBody] CardReaderDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.s_ipaddress.HasValue
                        && (dto.CardReader.HasValue || dto.ReaderType.HasValue))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _CardReaderService.AddCardReaderAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "类型分组id、类型数据不能全部为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增读卡器设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增读卡器设置异常");
            }
        }

        /// <summary>
        /// 修改读卡器设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editCardReaderAsync")]
        public async Task<ApiResultDto> EditCardReaderAsync([FromBody] CardReaderDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && dto.s_ipaddress.HasValue
                        && (dto.CardReader.HasValue || dto.ReaderType.HasValue)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _CardReaderService.EditCardReaderAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "类型分组id、类型数据不能全部为空；是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改读卡器设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改读卡器设置异常");
            }
        }

        /// <summary>
        /// 查询读卡器设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryCardReaderAsync")]
        public async Task<ApiResultPageNationTDataDto<List<CardReaderSearchResultDto>>> QueryCardReaderAsync([FromBody] CardReaderSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new CardReaderSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _CardReaderService.QueryCardReaderAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<CardReaderSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询读卡器设置异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<CardReaderSearchResultDto>>.ToResultFail(msg: "查询读卡器设置异常");
            }
        }

        /// <summary>
        /// 删除读卡器设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeCardReaderAsync")]
        public async Task<ApiResultDto> RemoveCardReaderAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _CardReaderService.RemoveCardReaderAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的读卡器设置id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除读卡器设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除读卡器设置异常");
            }
        }
        /// <summary>
        /// 批量删除读卡器设置
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveCardReaderAsync")]
        public async Task<ApiResultDto> BattchRemoveCardReaderAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _CardReaderService.BattchRemoveCardReaderAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的读卡器设置id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除读卡器设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除读卡器设置异常");
            }
        }
    }
}


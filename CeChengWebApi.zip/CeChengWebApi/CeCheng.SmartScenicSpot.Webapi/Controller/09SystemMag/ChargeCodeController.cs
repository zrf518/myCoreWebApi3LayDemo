﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：消费类别
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class ChargeCodeController : ControllerBase
    {
        private readonly ILogger<ChargeCodeController> _LogService;
        private readonly IChargeCodeInterface _ChargeCodeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id; 

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="ChargeCodeService"></param>
        /// <param name="logService"></param>
        public ChargeCodeController(IChargeCodeInterface ChargeCodeService, ILogger<ChargeCodeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _ChargeCodeService = ChargeCodeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增消费类别接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addChargeCodeAsync")]
        public async Task<ApiResultDto> AddChargeCodeAsync([FromBody] ChargeCodeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.s_charge_type_id.HasValue 
                        && !string.IsNullOrEmpty(dto.charge_code)
                        && !string.IsNullOrEmpty(dto.charge_describe))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _ChargeCodeService.AddChargeCodeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "消费类型编码、名称不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增消费类别异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增消费类别异常");
            }
        }

        /// <summary>
        /// 修改消费类别接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editChargeCodeAsync")]
        public async Task<ApiResultDto> EditChargeCodeAsync([FromBody] ChargeCodeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.charge_code)
                        && !string.IsNullOrEmpty(dto.charge_describe)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _ChargeCodeService.EditChargeCodeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "消费类型id、编码、名称、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改消费类别异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改消费类别异常");
            }
        }

        /// <summary>
        /// 查询消费类别接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryChargeCodeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<ChargeCodeSearchResultDto>>> QueryChargeCodeAsync([FromBody] ChargeCodeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new ChargeCodeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _ChargeCodeService.QueryChargeCodeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<ChargeCodeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询消费类别异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<ChargeCodeSearchResultDto>>.ToResultFail(msg: "查询消费类别异常");
            }
        }

        /// <summary>
        /// 删除消费类别接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeChargeCodeAsync")]
        public async Task<ApiResultDto> RemoveChargeCodeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _ChargeCodeService.RemoveChargeCodeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的消费类别id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除消费类别异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除消费类别异常");
            }
        }
        /// <summary>
        /// 批量删除消费类别
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveChargeCodeAsync")]
        public async Task<ApiResultDto> BattchRemoveChargeCodeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _ChargeCodeService.BattchRemoveChargeCodeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的消费类别id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除消费类别异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除消费类别异常");
            }
        }
    }
}

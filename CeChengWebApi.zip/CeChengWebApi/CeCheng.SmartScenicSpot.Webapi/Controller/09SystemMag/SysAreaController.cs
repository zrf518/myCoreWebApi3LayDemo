﻿using CeCheng.SmartScenicSpot.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CeCheng.SmartScenicSpot.Models;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：行政区域
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysAreaController : ControllerBase
    {
        private readonly ILogger<SysAreaController> _LogService;
        private readonly ISysAreaInterface _SysAreaService;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="SysAreaService"></param>
        /// <param name="logService"></param>
        public SysAreaController(ISysAreaInterface SysAreaService, ILogger<SysAreaController> logService)
        {
            _SysAreaService = SysAreaService;
            _LogService = logService;
        }

        /// <summary>
        /// 查询行政区域接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySysAreaAsync")]
        [Obsolete("该接口不适用，需要3级联动")]
        public async Task<ApiResultPageNationTDataDto<List<SysAreaSearchResultDto>>> QuerySysAreaAsync([FromBody] SysAreaDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SysAreaDto();
                    }
                    var reuslt = await _SysAreaService.QuerySysAreaAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SysAreaSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询行政区域异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SysAreaSearchResultDto>>.ToResultFail(msg: "查询行政区域异常");
            }
        }

        /// <summary>
        /// 初始化省市区数据
        /// </summary>
        /// <returns></returns>
        [HttpPost("InitPCAData")]
        [Obsolete("已经初始化过一次，不需要重复调用该接口")]
        public async Task<ApiResultDto> InitPCAData([FromBody] string guidpwd)
        {
            try
            {
                if ("jason666".Equals(guidpwd))
                    return await _SysAreaService.InitPCAData();
                return ApiResultDto.ToResultFail();
            }
            catch (Exception ex)
            {
                return ApiResultDto.ToResultError(msg: ex.Message);
            }
        }

        /// <summary>
        /// 查询省市区3级联动数据
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryPCAData")]
        public async Task<ApiResultDto<List<SysProvinceCityAreaDataDto>>> QueryPCAData([FromBody] SysProvinceCityAreaDataQueryDto dto)
        {
            try
            {
                return await _SysAreaService.QueryPCAData(dto);
            }
            catch (Exception ex)
            {
                return ApiResultDto<List<SysProvinceCityAreaDataDto>>.ToResultError(msg: ex.Message);
            }
        }
    }
}


﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：营业点
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class OutletsSetupController : ControllerBase
    {
        private readonly ILogger<OutletsSetupController> _LogService;
        private readonly IOutletsSetupInterface _OutletsSetupService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="OutletsSetupService"></param>
        /// <param name="logService"></param>
        public OutletsSetupController(IOutletsSetupInterface OutletsSetupService, ILogger<OutletsSetupController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _OutletsSetupService = OutletsSetupService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增营业点接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addOutletsSetupAsync")]
        public async Task<ApiResultDto> AddOutletsSetupAsync([FromBody] OutletsSetupDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && !string.IsNullOrEmpty(dto.outlet_no)
                        && !string.IsNullOrEmpty(dto.outlet_name))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _OutletsSetupService.AddOutletsSetupAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "营业点编码、名称不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增营业点异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增营业点异常");
            }
        }

        /// <summary>
        /// 修改营业点接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editOutletsSetupAsync")]
        public async Task<ApiResultDto> EditOutletsSetupAsync([FromBody] OutletsSetupDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.outlet_no)
                        && !string.IsNullOrEmpty(dto.outlet_name)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _OutletsSetupService.EditOutletsSetupAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "营业点编码、名称、是否有效不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改营业点异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改营业点异常");
            }
        }

        /// <summary>
        /// 查询营业点接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryOutletsSetupAsync")]
        public async Task<ApiResultPageNationTDataDto<List<OutletsSetupDto>>> QueryOutletsSetupAsync([FromBody] OutletsSetupDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new OutletsSetupDto();
                    }
                    dto.s_branch_id = i_branch_id;
                    var reuslt = await _OutletsSetupService.QueryOutletsSetupAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<OutletsSetupDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询营业点异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<OutletsSetupDto>>.ToResultFail(msg: "查询营业点异常");
            }
        }

        /// <summary>
        /// 匿名查询营业点接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryOutletsSetupAsyncByAnonymous")]
        [AllowAnonymous]
        public async Task<ApiResultPageNationTDataDto<List<OutletsSetupDto>>> QueryOutletsSetupAsyncByAnonymous([FromBody] OutletsSetupDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto || false == dto.s_branch_id.HasValue)
                    {
                        return ApiResultPageNationTDataDto<List<OutletsSetupDto>>.ToResultFail(msg: "分店ID不能为空");
                    }
                    var reuslt = await _OutletsSetupService.QueryOutletsSetupAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<OutletsSetupDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=匿名查询营业点异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<OutletsSetupDto>>.ToResultFail(msg: "匿名查询营业点异常");
            }
        }

        /// <summary>
        /// 删除营业点接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeOutletsSetupAsync")]
        public async Task<ApiResultDto> RemoveOutletsSetupAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _OutletsSetupService.RemoveOutletsSetupAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的营业点id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除营业点异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除营业点异常");
            }
        }
        /// <summary>
        /// 批量删除营业点
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveOutletsSetupAsync")]
        public async Task<ApiResultDto> BattchRemoveOutletsSetupAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _OutletsSetupService.BattchRemoveOutletsSetupAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的营业点id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除营业点异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除营业点异常");
            }
        }

    }
}

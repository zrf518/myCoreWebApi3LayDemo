﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：分店，营业点，操作员班次相关
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SystemBranchController:ControllerBase
    {
        /// <summary>
        /// 
        /// </summary>
        public SystemBranchController()
        {

        }
    }
}

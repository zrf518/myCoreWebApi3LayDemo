﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：消费项目
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class ConsumeItemController : ControllerBase
    {
        private readonly ILogger<ConsumeItemController> _LogService;
        private readonly IConsumeItemInterface _ConsumeItemService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="ConsumeItemService"></param>
        /// <param name="logService"></param>
        public ConsumeItemController(IConsumeItemInterface ConsumeItemService, ILogger<ConsumeItemController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _ConsumeItemService = ConsumeItemService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增消费项目接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addConsumeItemAsync")]
        public async Task<ApiResultDto> AddConsumeItemAsync([FromBody] ConsumeItemDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.s_charge_code_id.HasValue 
                        && !string.IsNullOrEmpty(dto.consume_item_no) 
                        && !string.IsNullOrEmpty(dto.consume_item_name))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _ConsumeItemService.AddConsumeItemAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "消费类型id、消费项目编码、消费项目名称不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增消费项目异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增消费项目异常");
            }
        }

        /// <summary>
        /// 修改消费项目接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editConsumeItemAsync")]
        public async Task<ApiResultDto> EditConsumeItemAsync([FromBody] ConsumeItemDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.id > 0
                        && dto.s_charge_code_id.HasValue
                        && !string.IsNullOrEmpty(dto.consume_item_no)
                        && !string.IsNullOrEmpty(dto.consume_item_name)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _ConsumeItemService.EditConsumeItemAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "消费类型id、消费项目id、编码、消费项目、是否有效名称不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改消费项目异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改消费项目异常");
            }
        }

        /// <summary>
        /// 查询消费项目接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryConsumeItemAsync")]
        public async Task<ApiResultPageNationTDataDto<List<ConsumeItemSearchResultDto>>> QueryConsumeItemAsync([FromBody] ConsumeItemSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new ConsumeItemSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _ConsumeItemService.QueryConsumeItemAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<ConsumeItemSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询消费项目异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<ConsumeItemSearchResultDto>>.ToResultFail(msg: "查询消费项目异常");
            }
        }

        /// <summary>
        /// 删除消费项目接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeConsumeItemAsync")]
        public async Task<ApiResultDto> RemoveConsumeItemAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _ConsumeItemService.RemoveConsumeItemAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的消费项目id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除消费项目异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除消费项目异常");
            }
        }
        /// <summary>
        /// 批量删除消费项目
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveConsumeItemAsync")]
        public async Task<ApiResultDto> BattchRemoveConsumeItemAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _ConsumeItemService.BattchRemoveConsumeItemAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的消费项目id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除消费项目异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除消费项目异常");
            }
        }
    }
}

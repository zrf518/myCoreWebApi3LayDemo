﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NPOI.OpenXmlFormats.Dml;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：餐厅设置，假日设置，部分项目维护接口
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class RestaurantHolidaySpecialMainteController : CeChengBaseController
    {
        private readonly IRestaurantHolidaySpecialMainteInterface _restaurantHolidaySpecialMainteInterface;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <param name="restaurantHolidaySpecialMainteInterface"></param>
        public RestaurantHolidaySpecialMainteController(IHttpContextAccessor httpContextAccessor, IRestaurantHolidaySpecialMainteInterface restaurantHolidaySpecialMainteInterface) : base(httpContextAccessor)
        {
            _restaurantHolidaySpecialMainteInterface = restaurantHolidaySpecialMainteInterface;
        }

        #region 查询餐厅设置 CURD
        /// <summary>
        /// 查询餐厅设置 
        /// </summary>
        /// <returns></returns>
        [HttpPost("QueryResauranData")]
        public async Task<ApiResultPageNationTDataDto<List<SsysRestaurantQueryDto>>> QueryResauranData([FromBody] SsysRestaurantInputDto dto)
        {
            return await _restaurantHolidaySpecialMainteInterface.QueryResauranData(dto);
        }
        /// <summary>
        /// 新增餐厅设置
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddResauranData")]
        public async Task<ApiResultDto> AddResauranData([FromBody] SsysRestaurantAddDto dto)
        {
            return await _restaurantHolidaySpecialMainteInterface.AddResauranData(dto);
        }

        /// <summary>
        /// 编辑餐厅设置
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditResauranData")]
        public async Task<ApiResultDto> EditResauranData([FromBody] SsysRestaurantEditDto dto)
        {
            return await _restaurantHolidaySpecialMainteInterface.EditResauranData(dto);
        }
        /// <summary>
        /// 删除餐厅设置
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost("RemoveResauranData")]
        public async Task<ApiResultDto> RemoveResauranData([FromBody] QueryByIdDto id)
        {
            return await _restaurantHolidaySpecialMainteInterface.RemoveResauranData(id);
        }
        #endregion

        #region 假日设置
        /// <summary>
        /// 新增假日
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost("AddHoliday")]
        public async Task<ApiResultDto> AddHoliday([FromBody] SsyssHoliDayAddDto id)
        {
            return await _restaurantHolidaySpecialMainteInterface.AddHoliday(id);
        }
        /// <summary>
        /// 修改假日
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("EditHoliday")]
        public async Task<ApiResultDto> EditHoliday([FromBody] SsyssHoliDayEditDto dto)
        {
            return await _restaurantHolidaySpecialMainteInterface.EditHoliday(dto);
        }
        /// <summary>
        /// 删除假日
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost("RemoveHoliday")]
        public async Task<ApiResultDto> RemoveHoliday([FromBody] QueryByIdDto id)
        {
            return await _restaurantHolidaySpecialMainteInterface.RemoveHoliday(id);
        }
        /// <summary>
        /// 查询假日
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryHoliday")]
        public async Task<ApiResultPageNationTDataDto<List<SsyssHoliDayEntity>>> QueryHoliday([FromBody] SsyssHoliDayQueryInputDto dto) => await _restaurantHolidaySpecialMainteInterface.QueryHoliday(dto);

        #endregion


        #region 时段优惠设置
        /// <summary>
        /// 新增 时段优惠设置
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("AddTimeDiscount")]
        public async Task<ApiResultDto> AddTimeDiscount([FromBody] SayDiscTypeDto dto)
        {
            if (!string.IsNullOrEmpty(dto.s_type))
            {
                if (!"A".Equals(dto.s_type) && !"B".Equals(dto.s_type))
                    return ApiResultDto.ToResultFail(msg: "s_type只能为：A按日期 或者 B按星期");
            }
            if (dto.IsHour != 1 && dto.IsHour != 2)
                return ApiResultDto.ToResultFail(msg: "IsHour 1按消费时长; 2按入场离场时间");
            return await _restaurantHolidaySpecialMainteInterface.AddTimeDiscount(dto);
        }
        /// <summary>
        /// 编辑 时段优惠设置
        /// </summary>
        /// <param name="dto"></param>
        [HttpPost("EditTimeDiscount")]
        public async Task<ApiResultDto> EditTimeDiscount([FromBody] SayDiscTypeDto dto)
        {
            if (dto.id <= 0)
                return ApiResultDto.ToResultFail(msg: "id不能为空");
            if (!string.IsNullOrEmpty(dto.s_type))
            {
                if (!"A".Equals(dto.s_type) && !"B".Equals(dto.s_type))
                    return ApiResultDto.ToResultFail(msg: "s_type只能为：A按日期 或者 B按星期");
            }
            if (dto.IsHour != 1 && dto.IsHour != 2)
                return ApiResultDto.ToResultFail(msg: "IsHour 1按消费时长; 2按入场离场时间");
            return await _restaurantHolidaySpecialMainteInterface.EditTimeDiscount(dto);
        }
        /// <summary>
        /// 删除 时段优惠设置
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("RemoveTimeDiscount")]
        public async Task<ApiResultDto> RemoveTimeDiscount([FromBody] QueryByIdDto dto) => await _restaurantHolidaySpecialMainteInterface.RemoveTimeDiscount(dto);
        /// <summary>
        /// 查询 时段优惠设置
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("QueryTimeDiscount")]
        public async Task<ApiResultPageNationTDataDto<List<SayDiscTypeDto>>> QueryTimeDiscount([FromBody] TimeDisCountInputQuery dto) => await _restaurantHolidaySpecialMainteInterface.QueryTimeDiscount(dto);

        #endregion

        #region Week营销管理，周末设置
        /// <summary>
        /// 周末设置 新增
        /// </summary>
        /// <returns></returns>
        [HttpPost("WeekSetAdd")]
        public async Task<ApiResultDto> WeekSetAdd([FromBody] SysWeekSetAddDto obj) => await _restaurantHolidaySpecialMainteInterface.WeekSetAdd(obj);

        /// <summary>
        /// 周末设置 修改
        /// </summary>
        /// <returns></returns>
        [HttpPost("WeekSetEdit")]
        public async Task<ApiResultDto> WeekSetEdit([FromBody] SysWeekSetEditDto obj) => await _restaurantHolidaySpecialMainteInterface.WeekSetEdit(obj);
        /// <summary>
        /// 周末设置 查询
        /// </summary>
        /// <returns></returns>
        [HttpPost("WeekSetQuery")]
        public async Task<ApiResultPageNationTDataDto<List<SysWeekSetEntity>>> WeekSetQuery(BasePageDto dto) => await _restaurantHolidaySpecialMainteInterface.WeekSetQuery(dto);
        /// <summary>
        /// 周末设置 删除
        /// </summary>
        /// <returns></returns>
        [HttpPost("WeekSetRemove")]
        public async Task<ApiResultDto> WeekSetRemove([FromBody] QueryByIdDto obj) => await _restaurantHolidaySpecialMainteInterface.WeekSetRemove(obj);
        #endregion

    }
}

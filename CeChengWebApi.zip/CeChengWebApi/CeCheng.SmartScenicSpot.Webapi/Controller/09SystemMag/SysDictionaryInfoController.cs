﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：字典信息
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysDictionaryInfoController : ControllerBase
    {
        private readonly ILogger<SysDictionaryInfoController> _LogService;
        private readonly ISysDictionaryInfoInterface _SysDictionaryInfoService;

        /// <summary>
        /// 构造方法
        /// </summary>
        /// <param name="SysDictionaryInfoService"></param>
        /// <param name="logService"></param>
        public SysDictionaryInfoController(ISysDictionaryInfoInterface SysDictionaryInfoService, ILogger<SysDictionaryInfoController> logService)
        {
            _SysDictionaryInfoService = SysDictionaryInfoService;
            _LogService = logService;
        }

        /// <summary>
        /// 查询字典信息接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySysDictionaryInfo")]
        public async Task<ApiResultPageNationTDataDto<List<SysDictionaryInfoDto>>> QuerySysDictionaryInfo([FromBody] SysDictionaryInfoDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SysDictionaryInfoDto();
                    }
                    var reuslt = await _SysDictionaryInfoService.QuerySysDictionaryInfoAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SysDictionaryInfoDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询字典信息异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SysDictionaryInfoDto>>.ToResultFail(msg: "查询字典信息异常");
            }
        }
    }
}

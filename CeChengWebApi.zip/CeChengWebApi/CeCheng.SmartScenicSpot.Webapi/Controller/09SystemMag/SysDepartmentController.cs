﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：部门
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysDepartmentController : ControllerBase
    {
        private readonly ILogger<SysDepartmentController> _LogService;
        private readonly ISysDepartmentInterface _SysDepartmentService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="SysDepartmentService"></param>
        /// <param name="logService"></param>
        public SysDepartmentController(ISysDepartmentInterface SysDepartmentService, ILogger<SysDepartmentController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _SysDepartmentService = SysDepartmentService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增部门接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addSysDepartmentAsync")]
        [AllowAnonymous]
        public async Task<ApiResultDto> AddSysDepartmentAsync([FromBody] SysDepartmentDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.s_sys_department_type_id.HasValue
                        && !string.IsNullOrEmpty(dto.dept_no) 
                        && !string.IsNullOrEmpty(dto.dept_name))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _SysDepartmentService.AddSysDepartmentAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "部门编码、名称、部门类别ID不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增部门异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增部门异常");
            }
        }

        /// <summary>
        /// 修改部门接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editSysDepartmentAsync")]
        [AllowAnonymous]
        public async Task<ApiResultDto> EditSysDepartmentAsync([FromBody] SysDepartmentDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto 
                        && dto.id > 0
                        && dto.s_sys_department_type_id.HasValue
                        && !string.IsNullOrEmpty(dto.dept_no)
                        && !string.IsNullOrEmpty(dto.dept_name)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _SysDepartmentService.EditSysDepartmentAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "部门编码、名称、部门类别id、是否有效不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改部门异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改部门异常");
            }
        }

        /// <summary>
        /// 查询部门接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySysDepartmentAsync")]
        [AllowAnonymous]
        public async Task<ApiResultPageNationTDataDto<List<SysDepartmentSearchResultDto>>> QuerySysDepartmentAsync([FromBody] SysDepartmentSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SysDepartmentSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _SysDepartmentService.QuerySysDepartmentAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SysDepartmentSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询部门异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SysDepartmentSearchResultDto>>.ToResultFail(msg: "查询部门异常");
            }
        }

        /// <summary>
        /// 删除部门接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeSysDepartmentAsync")]
        [AllowAnonymous]
        public async Task<ApiResultDto> RemoveSysDepartmentAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _SysDepartmentService.RemoveSysDepartmentAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的部门id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除部门异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除部门异常");
            }
        }
        /// <summary>
        /// 批量删除部门
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveSysDepartmentAsync")]
        [AllowAnonymous]
        public async Task<ApiResultDto> BattchRemoveSysDepartmentAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _SysDepartmentService.BattchRemoveSysDepartmentAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的部门id列表数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除部门异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除部门异常");
            }
        }
    }
}

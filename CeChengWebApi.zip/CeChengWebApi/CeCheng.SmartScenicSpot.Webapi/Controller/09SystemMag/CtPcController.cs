﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：读卡器类型分组
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class CtPcController : ControllerBase
    {
        private readonly ILogger<CtPcController> _LogService;
        private readonly ICtPcInterface _CtPcService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="CtPcService"></param>
        /// <param name="logService"></param>
        public CtPcController(ICtPcInterface CtPcService, ILogger<CtPcController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _CtPcService = CtPcService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增读卡器类型分组接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addCtPcAsync")]
        public async Task<ApiResultDto> AddCtPcAsync([FromBody] CtPcDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.s_ipaddress)
                        && !string.IsNullOrEmpty(dto.s_group))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _CtPcService.AddCtPcAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "读卡器类型分组的类型、组别代码不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增读卡器类型分组异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增读卡器类型分组异常");
            }
        }

        /// <summary>
        /// 修改读卡器类型分组接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editCtPcAsync")]
        public async Task<ApiResultDto> EditCtPcAsync([FromBody] CtPcDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.s_ipaddress)
                        && !string.IsNullOrEmpty(dto.s_group)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _CtPcService.EditCtPcAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "读卡器类型分组的类型、组别代码、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改读卡器类型分组异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改读卡器类型分组异常");
            }
        }

        /// <summary>
        /// 查询读卡器类型分组接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryCtPcAsync")]
        public async Task<ApiResultPageNationTDataDto<List<CtPcSearchResultDto>>> QueryCtPcAsync([FromBody] CtPcSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new CtPcSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _CtPcService.QueryCtPcAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<CtPcSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询读卡器类型分组异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<CtPcSearchResultDto>>.ToResultFail(msg: "查询读卡器类型分组异常");
            }
        }

        /// <summary>
        /// 删除读卡器类型分组接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeCtPcAsync")]
        public async Task<ApiResultDto> RemoveCtPcAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _CtPcService.RemoveCtPcAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的读卡器类型分组id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除读卡器类型分组异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除读卡器类型分组异常");
            }
        }
        /// <summary>
        /// 批量删除读卡器类型分组
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveCtPcAsync")]
        public async Task<ApiResultDto> BattchRemoveCtPcAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _CtPcService.BattchRemoveCtPcAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的读卡器类型分组id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除读卡器类型分组异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除读卡器类型分组异常");
            }
        }
    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 09 系统管理相关模块：套餐明细
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysCombDetailController : ControllerBase
    {
        private readonly ILogger<SysCombDetailController> _LogService;
        private readonly ISysCombDetailInterface _SysCombDetailService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="SysCombDetailService"></param>
        /// <param name="logService"></param>
        public SysCombDetailController(ISysCombDetailInterface SysCombDetailService, ILogger<SysCombDetailController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _SysCombDetailService = SysCombDetailService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增套餐明细接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addSysCombDetailAsync")]
        public async Task<ApiResultDto> AddSysCombDetailAsync([FromBody] SysCombDetailDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.s_sys_comb_id.HasValue
                        && !string.IsNullOrEmpty(dto.comb_detail_code)
                        && !string.IsNullOrEmpty(dto.comb_detail_type))
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _SysCombDetailService.AddSysCombDetailAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "消费维护id、套餐明细编码、名称不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增套餐明细异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增套餐明细异常");
            }
        }

        /// <summary>
        /// 修改套餐明细接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editSysCombDetailAsync")]
        public async Task<ApiResultDto> EditSysCombDetailAsync([FromBody] SysCombDetailDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && dto.s_sys_comb_id.HasValue
                        && !string.IsNullOrEmpty(dto.comb_detail_code)
                        && !string.IsNullOrEmpty(dto.comb_detail_type)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _SysCombDetailService.EditSysCombDetailAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "消费维护id、套餐明细编码、名称、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改套餐明细异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改套餐明细异常");
            }
        }

        /// <summary>
        /// 查询套餐明细接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySysCombDetailAsync")]
        public async Task<ApiResultPageNationTDataDto<List<SysCombDetailSearchResultDto>>> QuerySysCombDetailAsync([FromBody] SysCombDetailSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SysCombDetailSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _SysCombDetailService.QuerySysCombDetailAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SysCombDetailSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询套餐明细异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SysCombDetailSearchResultDto>>.ToResultFail(msg: "查询套餐明细异常");
            }
        }

        /// <summary>
        /// 删除套餐明细接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeSysCombDetailAsync")]
        public async Task<ApiResultDto> RemoveSysCombDetailAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _SysCombDetailService.RemoveSysCombDetailAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的套餐明细id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除套餐明细异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除套餐明细异常");
            }
        }
        /// <summary>
        /// 批量删除套餐明细
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveSysCombDetailAsync")]
        public async Task<ApiResultDto> BattchRemoveSysCombDetailAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _SysCombDetailService.BattchRemoveSysCombDetailAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的套餐明细id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除套餐明细异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除套餐明细异常");
            }
        }
    }
}

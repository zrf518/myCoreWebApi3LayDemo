﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 08 前台接待 相关模块
    /// </summary>
    [Route("api/reception/[controller]")]
    [Area("reception")]
    [ApiController]
    [Authorize]
    public class ReceptionistController:ControllerBase
    {
    }
}

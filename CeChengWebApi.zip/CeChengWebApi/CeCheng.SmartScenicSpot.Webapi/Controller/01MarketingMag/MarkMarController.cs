﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using CeCheng.SmartScenicSpot.Models.Dto.MarketingMag;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using CeCheng.SmartScenicSpot.Models.Consts;
using Microsoft.AspNetCore.Authorization;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 01 营销管理相关模块，太多相关业务可以多个Controller, 但是对于的命名空间 ,Area名称路由前缀尽量统一 一致（9个文件夹模块类似）
    /// </summary>
    [Route("api/mark/[controller]")]
    [Area("mark")]
    [ApiController]
    [Authorize]
    public class MarkMarController : ControllerBase
    {
      
    }

}

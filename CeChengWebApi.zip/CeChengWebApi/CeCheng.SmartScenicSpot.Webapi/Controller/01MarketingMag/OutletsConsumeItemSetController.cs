﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 01 营销管理相关模块：营业点售卖项目设置
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class OutletsConsumeItemSetController : ControllerBase
    {
        private readonly ILogger<OutletsConsumeItemSetController> _LogService;
        private readonly IOutletsConsumeItemSetInterface _OutletsConsumeItemSetService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="OutletsConsumeItemSetService"></param>
        /// <param name="logService"></param>
        public OutletsConsumeItemSetController(IOutletsConsumeItemSetInterface OutletsConsumeItemSetService, ILogger<OutletsConsumeItemSetController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _OutletsConsumeItemSetService = OutletsConsumeItemSetService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增营业点售卖项目设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addOutletsConsumeItemSetAsync")]
        public async Task<ApiResultDto> AddOutletsConsumeItemSetAsync([FromBody] OutletsConsumeItemSetDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.outlets_setup_id.HasValue
                        && dto.s_consume_item_id.HasValue
                        && dto.n_type.HasValue
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _OutletsConsumeItemSetService.AddOutletsConsumeItemSetAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "营业点ID、消费项目ID、消费项目类型标识不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增营业点售卖项目设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增营业点售卖项目设置异常");
            }
        }

        /// <summary>
        /// 修改营业点售卖项目设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editOutletsConsumeItemSetAsync")]
        public async Task<ApiResultDto> EditOutletsConsumeItemSetAsync([FromBody] OutletsConsumeItemSetDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && dto.outlets_setup_id.HasValue
                        && dto.s_consume_item_id.HasValue
                        && dto.n_type.HasValue
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user_wno = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _OutletsConsumeItemSetService.EditOutletsConsumeItemSetAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "营业点ID、消费项目ID、消费项目类型标识、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改营业点售卖项目设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改营业点售卖项目设置异常");
            }
        }

        /// <summary>
        /// 查询营业点售卖项目设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryOutletsConsumeItemSetAsync")]
        public async Task<ApiResultPageNationTDataDto<List<OutletsConsumeItemSetSearchResultDto>>> QueryOutletsConsumeItemSetAsync([FromBody] OutletsConsumeItemSetSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new OutletsConsumeItemSetSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _OutletsConsumeItemSetService.QueryOutletsConsumeItemSetAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<OutletsConsumeItemSetSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询营业点售卖项目设置异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<OutletsConsumeItemSetSearchResultDto>>.ToResultFail(msg: "查询营业点售卖项目设置异常");
            }
        }

        /// <summary>
        /// 删除营业点售卖项目设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeOutletsConsumeItemSetAsync")]
        public async Task<ApiResultDto> RemoveOutletsConsumeItemSetAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _OutletsConsumeItemSetService.RemoveOutletsConsumeItemSetAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的营业点售卖项目设置id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除营业点售卖项目设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除营业点售卖项目设置异常");
            }
        }
        /// <summary>
        /// 批量删除营业点售卖项目设置
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveOutletsConsumeItemSetAsync")]
        public async Task<ApiResultDto> BattchRemoveOutletsConsumeItemSetAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _OutletsConsumeItemSetService.BattchRemoveOutletsConsumeItemSetAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的营业点售卖项目设置id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除营业点售卖项目设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除营业点售卖项目设置异常");
            }
        }
    }
}



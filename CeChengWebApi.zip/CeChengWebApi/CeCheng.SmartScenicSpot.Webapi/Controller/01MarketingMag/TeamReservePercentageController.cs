﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 01 营销管理相关模块：团体预定提成
    /// </summary>
    [Route("api/system/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class TeamReservePercentageController : ControllerBase
    {
        private readonly ILogger<TeamReservePercentageController> _LogService;
        private readonly ITeamReservePercentageInterface _TeamReservePercentageService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="TeamReservePercentageService"></param>
        /// <param name="logService"></param>
        public TeamReservePercentageController(ITeamReservePercentageInterface TeamReservePercentageService, ILogger<TeamReservePercentageController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _TeamReservePercentageService = TeamReservePercentageService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增团体预定提成接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addTeamReservePercentageAsync")]
        public async Task<ApiResultDto> AddTeamReservePercentageAsync([FromBody] TeamReservePercentageDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.percentage_type.HasValue
                        && dto.percentage.HasValue
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _TeamReservePercentageService.AddTeamReservePercentageAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "提成类型及提成标准值不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增团体预定提成异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增团体预定提成异常");
            }
        }

        /// <summary>
        /// 修改团体预定提成接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editTeamReservePercentageAsync")]
        public async Task<ApiResultDto> EditTeamReservePercentageAsync([FromBody] TeamReservePercentageDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && dto.percentage_type.HasValue
                        && dto.percentage.HasValue
                        && !string.IsNullOrEmpty(dto.is_active)
                        )
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _TeamReservePercentageService.EditTeamReservePercentageAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "提成记录ID、提成类型及提成标准值、是否启用字段值不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改团体预定提成异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改团体预定提成异常");
            }
        }

        /// <summary>
        /// 查询团体预定提成接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryTeamReservePercentageAsync")]
        public async Task<ApiResultPageNationTDataDto<List<TeamReservePercentageSearchResultDto>>> QueryTeamReservePercentageAsync([FromBody] TeamReservePercentageSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new TeamReservePercentageSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _TeamReservePercentageService.QueryTeamReservePercentageAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<TeamReservePercentageSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询团体预定提成异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<TeamReservePercentageSearchResultDto>>.ToResultFail(msg: "查询团体预定提成异常");
            }
        }

        /// <summary>
        /// 删除团体预定提成接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeTeamReservePercentageAsync")]
        public async Task<ApiResultDto> RemoveTeamReservePercentageAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _TeamReservePercentageService.RemoveTeamReservePercentageAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的团体预定提成id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除团体预定提成异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除团体预定提成异常");
            }
        }
        /// <summary>
        /// 批量删除团体预定提成
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveTeamReservePercentageAsync")]
        public async Task<ApiResultDto> BattchRemoveTeamReservePercentageAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _TeamReservePercentageService.BattchRemoveTeamReservePercentageAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的团体预定提成id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除团体预定提成异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除团体预定提成异常");
            }
        }
    }
}

﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 01 营销管理相关模块：客类设置
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class SysCustTypeController : ControllerBase
    {
        private readonly ILogger<SysCustTypeController> _LogService;
        private readonly ISysCustTypeInterface _SysCustTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="SysCustTypeService"></param>
        /// <param name="logService"></param>
        public SysCustTypeController(ISysCustTypeInterface SysCustTypeService, ILogger<SysCustTypeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _SysCustTypeService = SysCustTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增客类设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addSysCustTypeAsync")]
        public async Task<ApiResultDto> AddSysCustTypeAsync([FromBody] SysCustTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.cust_code)
                        && !string.IsNullOrEmpty(dto.cust_name)
                        && !string.IsNullOrEmpty(dto.cust_pym)
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _SysCustTypeService.AddSysCustTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "客类设置的客类代码、客类名称、拼音码数据不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增客类设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增客类设置异常");
            }
        }

        /// <summary>
        /// 修改客类设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editSysCustTypeAsync")]
        public async Task<ApiResultDto> EditSysCustTypeAsync([FromBody] SysCustTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.cust_code)
                        && !string.IsNullOrEmpty(dto.cust_name)
                        && !string.IsNullOrEmpty(dto.cust_pym)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _SysCustTypeService.EditSysCustTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "客类设置的客类代码、客类名称、拼音码、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改客类设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改客类设置异常");
            }
        }

        /// <summary>
        /// 查询客类设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("querySysCustTypeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<SysCustTypeSearchResultDto>>> QuerySysCustTypeAsync([FromBody] SysCustTypeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new SysCustTypeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _SysCustTypeService.QuerySysCustTypeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<SysCustTypeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询客类设置异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<SysCustTypeSearchResultDto>>.ToResultFail(msg: "查询客类设置异常");
            }
        }

        /// <summary>
        /// 删除客类设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeSysCustTypeAsync")]
        public async Task<ApiResultDto> RemoveSysCustTypeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _SysCustTypeService.RemoveSysCustTypeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的客类设置id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除客类设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除客类设置异常");
            }
        }
        /// <summary>
        /// 批量删除客类设置
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveSysCustTypeAsync")]
        public async Task<ApiResultDto> BattchRemoveSysCustTypeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _SysCustTypeService.BattchRemoveSysCustTypeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的客类设置id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除客类设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除客类设置异常");
            }
        }
    }
}



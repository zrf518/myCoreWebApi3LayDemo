﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 01 营销管理相关模块：协议类型维护设置
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class AgreementTypeController : ControllerBase
    {
        private readonly ILogger<AgreementTypeController> _LogService;
        private readonly IAgreementTypeInterface _AgreementTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="AgreementTypeService"></param>
        /// <param name="logService"></param>
        public AgreementTypeController(IAgreementTypeInterface AgreementTypeService, ILogger<AgreementTypeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _AgreementTypeService = AgreementTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增协议类型维护设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addAgreementTypeAsync")]
        public async Task<ApiResultDto> AddAgreementTypeAsync([FromBody] AgreementTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.agreement_type_no)
                        && !string.IsNullOrEmpty(dto.agreement_type_name)
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _AgreementTypeService.AddAgreementTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "协议类型代码、名称数据不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增协议类型维护设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增协议类型维护设置异常");
            }
        }

        /// <summary>
        /// 修改协议类型维护设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editAgreementTypeAsync")]
        public async Task<ApiResultDto> EditAgreementTypeAsync([FromBody] AgreementTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.agreement_type_no)
                        && !string.IsNullOrEmpty(dto.agreement_type_name)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _AgreementTypeService.EditAgreementTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "协议类型代码、名称、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改协议类型维护设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改协议类型维护设置异常");
            }
        }

        /// <summary>
        /// 查询协议类型维护设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryAgreementTypeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<AgreementTypeSearchResultDto>>> QueryAgreementTypeAsync([FromBody] AgreementTypeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new AgreementTypeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _AgreementTypeService.QueryAgreementTypeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<AgreementTypeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询协议类型维护设置异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<AgreementTypeSearchResultDto>>.ToResultFail(msg: "查询协议类型维护设置异常");
            }
        }

        /// <summary>
        /// 删除协议类型维护设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeAgreementTypeAsync")]
        public async Task<ApiResultDto> RemoveAgreementTypeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _AgreementTypeService.RemoveAgreementTypeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的协议类型维护设置id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除协议类型维护设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除协议类型维护设置异常");
            }
        }
        /// <summary>
        /// 批量删除协议类型维护设置
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveAgreementTypeAsync")]
        public async Task<ApiResultDto> BattchRemoveAgreementTypeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _AgreementTypeService.BattchRemoveAgreementTypeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的协议类型维护设置id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除协议类型维护设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除协议类型维护设置异常");
            }
        }
    }
}



﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 01 营销管理相关模块：团体类型维护设置
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class TeamTypeController : ControllerBase
    {
        private readonly ILogger<TeamTypeController> _LogService;
        private readonly ITeamTypeInterface _TeamTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="TeamTypeService"></param>
        /// <param name="logService"></param>
        public TeamTypeController(ITeamTypeInterface TeamTypeService, ILogger<TeamTypeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _TeamTypeService = TeamTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增团体类型维护设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addTeamTypeAsync")]
        public async Task<ApiResultDto> AddTeamTypeAsync([FromBody] TeamTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.team_no)
                        && !string.IsNullOrEmpty(dto.tean_name)
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _TeamTypeService.AddTeamTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "团体类型代码、名称数据不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增团体类型维护设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增团体类型维护设置异常");
            }
        }

        /// <summary>
        /// 修改团体类型维护设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editTeamTypeAsync")]
        public async Task<ApiResultDto> EditTeamTypeAsync([FromBody] TeamTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.team_no)
                        && !string.IsNullOrEmpty(dto.tean_name)
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _TeamTypeService.EditTeamTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "团体类型代码、名称、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改团体类型维护设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改团体类型维护设置异常");
            }
        }

        /// <summary>
        /// 查询团体类型维护设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryTeamTypeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<TeamTypeSearchResultDto>>> QueryTeamTypeAsync([FromBody] TeamTypeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new TeamTypeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _TeamTypeService.QueryTeamTypeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<TeamTypeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询团体类型维护设置异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<TeamTypeSearchResultDto>>.ToResultFail(msg: "查询团体类型维护设置异常");
            }
        }

        /// <summary>
        /// 删除团体类型维护设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeTeamTypeAsync")]
        public async Task<ApiResultDto> RemoveTeamTypeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _TeamTypeService.RemoveTeamTypeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的团体类型维护设置id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除团体类型维护设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除团体类型维护设置异常");
            }
        }
        /// <summary>
        /// 批量删除团体类型维护设置
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveTeamTypeAsync")]
        public async Task<ApiResultDto> BattchRemoveTeamTypeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _TeamTypeService.BattchRemoveTeamTypeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的团体类型维护设置id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除团体类型维护设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除团体类型维护设置异常");
            }
        }
    }
}



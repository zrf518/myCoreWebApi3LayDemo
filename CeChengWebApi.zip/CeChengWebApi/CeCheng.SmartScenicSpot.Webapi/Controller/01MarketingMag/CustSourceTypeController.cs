﻿using CeCheng.SmartScenicSpot.Contracts;
using CeCheng.SmartScenicSpot.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using NPOI.SS.Formula.Functions;
using Microsoft.AspNetCore.Http;

namespace CeCheng.SmartScenicSpot.Webapi.Controller
{
    /// <summary>
    /// 01 营销管理相关模块：客源类型设置
    /// </summary>
    [Route("api/MemberUser/[controller]")]
    [Area("system")]
    [ApiController]
    [Authorize]
    public class CustSourceTypeController : ControllerBase
    {
        private readonly ILogger<CustSourceTypeController> _LogService;
        private readonly ICustSourceTypeInterface _CustSourceTypeService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        // 当前用户信息，匿名的时候为空
        private UserTokenInfo _userinfo { get; set; }
        // 当前用户账号，匿名的时候为空
        private string sUserWorkNo = string.Empty;
        // 当前用户登陆的分店id
        private int? i_branch_id;

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="CustSourceTypeService"></param>
        /// <param name="logService"></param>
        public CustSourceTypeController(ICustSourceTypeInterface CustSourceTypeService, ILogger<CustSourceTypeController> logService, IHttpContextAccessor httpContextAccessor)
        {
            _CustSourceTypeService = CustSourceTypeService;
            _LogService = logService;
            _httpContextAccessor = httpContextAccessor;
            _userinfo = CeCheng.SmartScenicSpot.Commoms.CeChengTokenHelper.GetTockenUserInfo(_httpContextAccessor.HttpContext);
            if (null != _userinfo)
            {
                i_branch_id = _userinfo.SBranchId;
                sUserWorkNo = _userinfo.UserWorkNo;
            }
        }

        /// <summary>
        /// 新增客源类型设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("addCustSourceTypeAsync")]
        public async Task<ApiResultDto> AddCustSourceTypeAsync([FromBody] CustSourceTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && !string.IsNullOrEmpty(dto.cust_source_code)
                        && !string.IsNullOrEmpty(dto.cust_source_desc)
                        && dto.cust_source_type.HasValue
                        )
                    {
                        dto.create_date = DateTime.Now;
                        dto.create_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;
                        dto.is_active = "Y";

                        var reuslt = await _CustSourceTypeService.AddCustSourceTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "客源类型设置的客源代码、客源描述、客源类型数据不能都为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=新增客源类型设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "新增客源类型设置异常");
            }
        }

        /// <summary>
        /// 修改客源类型设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("editCustSourceTypeAsync")]
        public async Task<ApiResultDto> EditCustSourceTypeAsync([FromBody] CustSourceTypeDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto
                        && dto.id > 0
                        && !string.IsNullOrEmpty(dto.cust_source_code)
                        && !string.IsNullOrEmpty(dto.cust_source_desc)
                        && dto.cust_source_type.HasValue
                        && !string.IsNullOrEmpty(dto.is_active))
                    {
                        dto.update_date = DateTime.Now;
                        dto.update_user = sUserWorkNo;
                        dto.s_branch_id = i_branch_id;

                        var reuslt = await _CustSourceTypeService.EditCustSourceTypeAsync(dto);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "客源类型设置的客源代码、客源描述、客源类型、是否有效数据不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=修改客源类型设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "修改客源类型设置异常");
            }
        }

        /// <summary>
        /// 查询客源类型设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("queryCustSourceTypeAsync")]
        public async Task<ApiResultPageNationTDataDto<List<CustSourceTypeSearchResultDto>>> QueryCustSourceTypeAsync([FromBody] CustSourceTypeSearchParamDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (null == dto)
                    {
                        dto = new CustSourceTypeSearchParamDto();
                    }
                    dto.s_branch_id = i_branch_id;

                    var reuslt = await _CustSourceTypeService.QueryCustSourceTypeAsync(dto);
                    return reuslt;
                }
                else
                {
                    return ApiResultPageNationTDataDto<List<CustSourceTypeSearchResultDto>>.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=查询客源类型设置异常,原因：{ex.Message}");
                return ApiResultPageNationTDataDto<List<CustSourceTypeSearchResultDto>>.ToResultFail(msg: "查询客源类型设置异常");
            }
        }

        /// <summary>
        /// 删除客源类型设置接口
        /// </summary>
        /// <returns></returns>
        [HttpPost("removeCustSourceTypeAsync")]
        public async Task<ApiResultDto> RemoveCustSourceTypeAsync([FromBody] QueryByIdDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && dto.id > 0)
                    {
                        var reuslt = await _CustSourceTypeService.RemoveCustSourceTypeAsync(sUserWorkNo, dto.id);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的客源类型设置id不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=删除客源类型设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "删除客源类型设置异常");
            }
        }
        /// <summary>
        /// 批量删除客源类型设置
        /// </summary>
        /// <returns></returns>
        [HttpPost("battchRemoveCustSourceTypeAsync")]
        public async Task<ApiResultDto> BattchRemoveCustSourceTypeAsync([FromBody] QueryByListIdsDto dto)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (string.IsNullOrEmpty(sUserWorkNo))
                    {
                        return ApiResultDto.ToResultFail(msg: "操作人账号信息不能为空");
                    }
                    if (null != dto && null != dto.ids && dto.ids.Count > 0)
                    {
                        var reuslt = await _CustSourceTypeService.BattchRemoveCustSourceTypeAsync(sUserWorkNo, dto.ids);
                        return reuslt;
                    }
                    else
                    {
                        return ApiResultDto.ToResultFail(msg: "被删除的客源类型设置id列表不能为空");
                    }
                }
                else
                {
                    return ApiResultDto.ToResultFail();
                }
            }
            catch (System.Exception ex)
            {
                _LogService.LogError($"=={DateTime.Now}=批量删除客源类型设置异常,原因：{ex.Message}");
                return ApiResultDto.ToResultFail(msg: "批量删除客源类型设置异常");
            }
        }
    }
}


